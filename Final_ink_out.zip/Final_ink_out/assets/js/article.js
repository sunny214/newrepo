//this is carusel code
  $(document).ready(function() {
    
 
 
      $('.article_parent').hide();
   
      $('.img-article').click(function(){
        
        //menu-item class name start
        $('.mobile-menuItems').hide();
        //menu-item class name end

           $('.article_parent').show();
           console.log('text');
            $('.background_color').click(function(){
             
            $('.article_parent').hide();
            });
           $(window).on('keyup',function(e){

             // console.log('window');
            if(e.which == 37){                
                    // console.log(e.which,'::::if',$('.lSSlideOuter').find('.lSPrev'));
                    $('.lSSlideOuter').find('.lSPrev').trigger('click');
                     console.log('left');
            }
            else if(e.which ==39){
                    // console.log(e.which,'::::else',$('.lSSlideOuter').find('.lSNext'));
                    $('.lSSlideOuter').find('.lSNext').trigger('click');
                     console.log('right');
            }
           });
    });
   $('.popUp-close, .background_color').click(function(){
         $('.article_parent').hide();

         //menu-item class name start 
         $('.mobile-menuItems').show();
          //menu-item class name end           
   });

  
     //pop-up code ends here
});