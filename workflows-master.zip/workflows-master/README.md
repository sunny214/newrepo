# WorkFlows Course

This project is an example of workflow management for a lynda.com course.
