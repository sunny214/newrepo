  $(document).ready(function() {
    
 $('#image-gallery').lightSlider({
                gallery:true,
                item:1,
                thumbItem:9,
                slideMargin: 0,
                speed:500,
                auto:true,
                loop:true,
                onSliderLoad: function() {
                    $('#image-gallery').removeClass('cS-hidden');
                }  
            });
 setTimeout(function(){
      $('.article_parent').hide();
  },50)
   $('.img-article').click(function(){
           $('.article_parent').show();
console.log('text');
           $(window).on('keyup',function(e){

             // console.log('window');
            if(e.which == 37){                
                    // console.log(e.which,'::::if',$('.lSSlideOuter').find('.lSPrev'));
                    $('.lSSlideOuter').find('.lSPrev').trigger('click');
                     console.log('left');
            }
            else if(e.which ==39){
                    // console.log(e.which,'::::else',$('.lSSlideOuter').find('.lSNext'));
                    $('.lSSlideOuter').find('.lSNext').trigger('click');
                     console.log('right');
            }
           });
    });
     $('.popUp-close').click(function(){
           $('.article_parent').hide();
            $(window).off('keyup');
     });
     //pop-up code ends here
   });