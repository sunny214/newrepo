 $(document).ready(function() {

     /*var ink_heading = $('.ink_heading_bdr h1 a');
      $('.main_header .container-fluid:eq(1) .nav ').before('<h2 class="nav_head">' + ink_heading + '</h2>');
      $('.nav_head').css("display", "none");*/

     // var left_t=$(".index .left_text")
//      var _headingArray =[{"name":"A $1 trillion milestone","by":"By Christopher Duray","href":"./A_1_trillion_milestone.html"},
//      {"name":"Dimon heads to D.C., taking on new roles this year","by":"By Kevin Sylvester","href":"./Dimon_heads_to_D.C.html"},
//      {"name":"New mantra for Global Investment Management in 2017: 'Let's Solve It'","by":"By Cameron Martin","href":"./New_Mantra_for_Global_Investment.html"},
//      {"name":"Ink Business Preferred card offers triple rewards points, signing bonus","by":"By Christopher Duray","href":"./Ink_Business_Preferred.html"},
//      {"name":"Father's legacy inspires sales manager to help small businesses grow","by":"By Christopher Duray","href":"./Fathers_Legacy.html"},
//      {"name":"Distinguished Engineers: 'renaissance people'","by":"By Christopher Duray","href":"./Distinguished_Engineer.html"}
//      ];
//      _headingArray.push( $(".page-heading").parent());
//      $(".page-heading").parent().each(function(key,val){
// console.log(val);

// })
// $(".page-heading").on('click',function(e){

//     var $target= $(e.target);
//     var trgtElm = $target.parents(".listing_help").find(".page-heading").text();
//     localStorage.setItem("selectedhead",trgtElm);
    
//     console.log("17::",trgtElm,trgtElm);

// });

// $(document).on("click",".viewList",function(e){
//     var setItem = $(e.target).text();
//     console.log("item",$(this),$(e.target))
//     localStorage.setItem("selectedhead",setItem);
   
// })

// var ulTag = '<ul id="more_view" class="list"></ul>';

// $(".tag-two").append(ulTag);
// var liTag = "";
// $.each(_headingArray, function(key, val){
    
// if(val && val.name) {
//     console.log("info",val,val.name);
//     liTag +='<li class="viewList"><a href='+val.href+'><h1>'+val.name+'</h1></a><p class="authorDent">'+val.by+'</p></li>';
// }
// });
//     $("#more_view").append(liTag);



// var selectedItem = localStorage.getItem("selectedhead");
// console.log("ifo-data-set",selectedItem);
// var inTime = 0;
//     var int1 = setInterval(function() {
//         inTime++;
//         if(selectedItem) {
//         var showingTag = $(".heading_data").find("h1").text();
//         console.log("showingTAg",showingTag);
//        if(showingTag && showingTag.length > 0) {
//         clearInterval(int1);
//          $.each($("#more_view").find("li"), function(key,val){
//             if($(val).find("h1").text() == showingTag ) {
//                 $(val).remove();
//                 console.log("info-data",val.name,showingTag);
//             } else if(val.name) {
//                 $(val).show();
//                 console.log("info-data-else",val.name,showingTag);

//             }
//         });
//      } else if(inTime == 10) {
//         clearInterval(int1);
//      }
//     }
//     },500)
  


     $('.print').click(function() {
         window.print();
     });

     $(window).scroll(function() {
         //console.log($(this).scrollTop());

         if ($(this).scrollTop() >= 42) {
             $('.main_header').addClass("sticky");
             //$('.ink_heading_bdr').css("display","block");
             $('.nav_head').css("display", "block");
             $('.ink_small').show();



         } else {
             $('.main_header').removeClass("sticky");
             //$('.ink_heading_bdr').removeClass("sticky");
             $('.nav_head').css("display", "none");
             $('.ink_small').hide();
             $('.mobile-border-top').addClass('visible-xs');
         }

         if ($(document).width() <= 991 && $(document).width() >= 767) {
             if ($(this).scrollTop() >= 42) {

                 $('.mobile-container').removeClass("container");

             } else {

                 $('.mobile-container').addClass("container");

             }
         }



         if ($(document).width() <= 767) {
             if ($(window).scrollTop() >= 19) {
                 $('.main_header').addClass("sticky");
                 $('.mobile-border-top').removeClass('visible-xs').css('display', 'none');
                 $('.ink_heading_bdr').css("display", "block");
                 $('.ink_logo_small').css({ "position": "fixed", "top": "0", "left": "11%" });

             } else {
                 $('.main_header').removeClass("sticky");
             }
         }



     });

     //$('.article_parent').css("display","none");

     //pop-up code start
     //    $('#image-gallery').lightSlider({
     //                 gallery:true,
     //                 item:1,
     //                 thumbItem:9,
     //                 slideMargin: 0,
     //                 speed:500,
     //                 auto:true,
     //                 loop:true,
     //                 onSliderLoad: function() {
     //                     $('#image-gallery').removeClass('cS-hidden');
     //                 }  
     //             });
     //  setTimeout(function(){
     //       $('.article_parent').hide();
     //   },50)
     //    $('.img-article').click(function(){
     //            $('.article_parent').show();
     // console.log('text');
     //            $(window).on('keyup',function(e){

     //              // console.log('window');
     //             if(e.which == 37){                
     //                     // console.log(e.which,'::::if',$('.lSSlideOuter').find('.lSPrev'));
     //                     $('.lSSlideOuter').find('.lSPrev').trigger('click');
     //                      console.log('left');
     //             }
     //             else if(e.which ==39){
     //                     // console.log(e.which,'::::else',$('.lSSlideOuter').find('.lSNext'));
     //                     $('.lSSlideOuter').find('.lSNext').trigger('click');
     //                      console.log('right');
     //             }
     //            });
     //     });
     //      $('.popUp-close').click(function(){
     //            $('.article_parent').hide();
     //             $(window).off('keyup');
     //      });
     //      //pop-up code ends here
     var hamburger = false;
     $('.mobile_hambargar').click(function() {

         if (hamburger == false) {
             $('.mobile-menuItems').addClass('active');
             $('.mobile-border').css({ "width": "94%", "left": "47px" });
             hamburger = true;
         } else {
             $('.mobile-menuItems').removeClass('active');
             $('.mobile-border').css({ "width": "100%", "left": "0px" });
             hamburger = false;
         }

     })

     var els = document.querySelectorAll('.outlook'),
         i;
     for (i = 0; i < els.length; ++i) {
         els[i].href +="?body=" + window.location.href; // Adds current URL
     }


 });
