  $(document).ready(function() {
    
 
 
      $('.article_parent').hide();
   
   $('.img-article').click(function(){
           $('.article_parent').show();
console.log('text');
           $(window).on('keyup',function(e){

             // console.log('window');
            if(e.which == 37){                
                    // console.log(e.which,'::::if',$('.lSSlideOuter').find('.lSPrev'));
                    $('.lSSlideOuter').find('.lSPrev').trigger('click');
                     console.log('left');
            }
            else if(e.which ==39){
                    // console.log(e.which,'::::else',$('.lSSlideOuter').find('.lSNext'));
                    $('.lSSlideOuter').find('.lSNext').trigger('click');
                     console.log('right');
            }
           });
    });
     $('.popUp-close').click(function(){
           $('.article_parent').hide();            
     });
     //pop-up code ends here
   });