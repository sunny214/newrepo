/*! Distribution 41.3 */
  $(function() {
            var activeRowID, nextRowID, prevRowID, chapterID;
            var pageMoveDirection = "";


            $(".sharing").removeClass("scrollWith");
            //NAVIGATION
            // open navigation
		    $('#nav-icon').click(function(){
		        $("body").toggleClass('nav-open');
		        $(this).toggleClass('open');
		    });

            //close navigation
            $('.navigation-overlay .flex-container').click(function(){
                $("body").toggleClass('nav-open');
                $('#nav-icon').toggleClass('open');
            });

            $('.nav-down').click(function(){
                //arrows to move you down content or to the next page.
                if(this.rangeTimeOut) {
                    clearTimeout(this.rangeTimeOut);
                }
                this.rangeTimeOut = setTimeout(function() {


                    checkContentRead();
                    pageMoveDirection = "down";
                    var movedNextPage = processMovement(pageMoveDirection);
                    var pageHeight =  $( window ).height();
                    //console.log(movedNextPage);
                    if ( movedNextPage === false){
                        $(".mainbody.active").animate({
                          scrollTop: $(".mainbody.active").scrollTop() + pageHeight
                        }, 1000, "easeOutQuad");
                    }
                    
                    pageMoveDirection = "";
                   

                }, 50);    

                return false;

                // if(this.rangeTimeOut) {
                //     clearTimeout(this.rangeTimeOut);
                // }
                // this.rangeTimeOut = setTimeout(function() {
                //     smoothScrollTo($( "#" + nextRowID));
                // }, 500);   


                // return false;
            });


            $('.nav-up').click(function(){
                //arrows to move you up content or to the prev page.
                if(this.rangeTimeOut) {
                    clearTimeout(this.rangeTimeOut);
                }
                this.rangeTimeOut = setTimeout(function() {
                    checkContentRead();
                    pageMoveDirection = "up";
                    var movedNextPage = processMovement(pageMoveDirection);
                    var pageHeight =  $( window ).height();
                    if ( movedNextPage === false){
                        $(".mainbody.active").animate({
                          scrollTop: $(".mainbody.active").scrollTop() - pageHeight
                        }, 1000, "easeOutQuad");
                    }
                    pageMoveDirection = "";
                   

                }, 50);    

                return false;
            });


            //object to keep track of all files to be loaded in Desktop and OG info
            var CRPages = {
                'p1':{
                    'filename': 'cr-2015-overview.htm',
                    'ogtitle': 'Corporate Responsibility 2015',
                    'chaptertitle': 'Corporate Responsibility 2015',
                    'twittershare': 'Giving more people the opportunity to climb the economic ladder and create more widely shared prosperity',
                    'index': 1
                },
                'p2':{
                    'filename': 'cr-2015-scher-letter.htm',
                    'ogtitle': 'Peter Scher on Economic Growth',
                    'chaptertitle': 'Peter Scher on Economic Growth',
                    'twittershare': 'There is no more urgent challenge than the need to create more inclusive economic growth',
                    'index': 2
                },
                'p3':{
                    'filename': 'cr-2015-detroit.htm',
                    'ogtitle': 'Why Detroit Matters',
                    'chaptertitle': 'Detroit',
                    'twittershare': "Why Detroit Matters - What Motor City's turnaround can teach us about creating opportunity",
                    'index': 3
                },
                'p4':{
                    'filename': 'cr-2015-invested-detroit.htm',
                    'ogtitle': 'Invested in Detroit',
                    'chaptertitle': 'Detroit',
                    'twittershare': "Invested in Detroit - How JPMorgan Chase's $100 mil 5-year pledge is supporting Detroit's recovery",
                    'index': 4
                },
                'p5':{
                    'filename': 'cr-2015-parcels.htm',
                    'ogtitle': 'A Story of Parcels',
                    'chaptertitle': 'Detroit',
                    'twittershare': "A Story of Parcels - Arming the public with actionable information to improve their communities",
                    'index': 5
                },
                'p6':{
                    'filename': 'cr-2015-detroit-service.htm',
                    'ogtitle': 'Detroit Service Corps',
                    'chaptertitle': 'Detroit',
                    'twittershare': "Detroit Service Corps - Putting the expertise of JPMorgan Chase employees to work in Detroit",
                    'index': 6
                },
                'p7':{
                    'filename': 'cr-2015-big-data.htm',
                    'ogtitle': 'Big Data',
                    'chaptertitle': 'Big Data',
                    'twittershare': 'Data hold the power to drive economic progress in ways that create more broadly shared prosperity',
                    'index': 7
                },
                'p8':{
                    'filename': 'cr-2015-global-prosperity.htm',
                    'ogtitle': 'Global Prosperity',
                    'chaptertitle': 'Big Data',
                    'twittershare': 'Data hold the formidable power to drive economic progress in ways that create more broadly shared prosperity',
                    'index': 8
                },
                'p9':{
                    'filename': 'cr-2015-weathering-volatility.htm',
                    'ogtitle': 'Weathering Volatility',
                    'chaptertitle': 'Big Data',
                    'twittershare': 'Big Data - For the majority of U.S. households, monthly income and consumption fluctuate greatly',
                    'index': 9
                },
                'p10':{
                    'filename': 'cr-2015-financial-solutions.htm',
                    'ogtitle': 'Financial Solutions',
                    'chaptertitle': 'Financial Solutions',
                    'twittershare': 'Tackling financial instability one App at a time',
                    'index': 10
                },
                'p11':{
                    'filename': 'cr-2015-fsl-winners.htm',
                    'ogtitle': 'Financial Solutions Lab Winners',
                    'chaptertitle': 'Financial Solutions',
                    'twittershare': 'Financial Solutions Lab Winners - Using apps to tackle the pervasive problem of managing household cash flow',
                    'index': 11
                },
                'p12':{
                    'filename': 'cr-2015-lendstreet.htm',
                    'ogtitle': 'Lendstreet',
                    'chaptertitle': 'Financial Solutions',
                    'twittershare': 'Lendstreet - Empowering customers with a clear path toward economic opportunity',
                    'index': 12
                },
                'p13':{
                    'filename': 'cr-2015-workforce.htm',
                    'ogtitle': 'Workforce',
                    'chaptertitle': 'Workforce',
                    'twittershare': 'Sparking Mobility - Creating greater economic opportunity for people around the world',
                    'index': 13
                },
                'p14':{
                    'filename': 'cr-2015-nsaw.htm',
                    'ogtitle': 'New Skills at Work',
                    'chaptertitle': 'Workforce',
                    'twittershare': 'New Skills at Work - using data to strengthen the most effective workforce training programs around the world',
                    'index': 14
                },
                'p16':{
                    'filename': 'cr-2015-youth-skills.htm',
                    'ogtitle': 'Youth Skills',
                    'chaptertitle': 'Youth Skills',
                    'twittershare': 'Addressing the youth skills crisis  so they can be career-ready and succeed in well-paying jobs',
                    'index': 16
                },
                'p17':{
                    'filename': 'cr-2015-latin-america.htm',
                    'ogtitle': 'Latin America',
                    'chaptertitle': 'Latin America',
                    'twittershare': 'Creating opportunity in Latin America',
                    'index': 17
                },
                'p18':{
                    'filename': 'cr-2015-small-business.htm',
                    'ogtitle': 'Small Business',
                    'chaptertitle': 'Small Business',
                    'twittershare': 'Powering economic opportunity one small business at a time',
                    'index': 18
                },
                'p19':{
                    'filename': 'cr-2015-darrows.htm',
                    'ogtitle': 'Uncle Darrow\'s',
                    'chaptertitle': 'Small Business',
                    'twittershare': 'Uncle Darrow’s: Bringing a Taste of the Bayou to Los Angeles',
                    'index': 19
                },
                'p20':{
                    'filename': 'cr-2015-global-cities.htm',
                    'ogtitle': 'Global Cities',
                    'chaptertitle': 'Global Cities',
                    'twittershare': 'How to build global cities that are engines of inclusion instead of displacement',
                    'index': 20
                },
                'p21':{
                    'filename': 'cr-2015-big-picture.htm',
                    'ogtitle': 'The Big Picture',
                    'chaptertitle': 'The Big Picture',
                    'twittershare': 'We ask leaders what one policy would create the most opportunity for our youth. See their answers',
                    'index': 21
                },
                'p22':{
                    'filename': 'cr-2015-art-leadership.htm',
                    'ogtitle': 'The Art of Leadership',
                    'chaptertitle': 'The Art of Leadership',
                    'twittershare': 'Learn about The Fellowship Initiative providing leadership development to young men of color',
                    'index': 22
                },
                'p23':{
                    'filename': 'cr-2015-ampersand.htm',
                    'ogtitle': 'JPMorgan Chase & Co.',
                    'chaptertitle': 'JPMorgan Chase & Co.',
                    'twittershare': 'Learn how financial services firm JPMorgan Chase & Co. is commited to giving back to our communities',
                    'index': 23
                }
            };


            function loadPage(idNum){
            //Used to load the content for a specific page id
                //console.log("loadPage" +idNum );
                if ($(".mainbody.active").length){
                    var loadRowID = "p" + String(Number(idNum));
                    if ($('#'+loadRowID).length === 0 && CRPages[loadRowID] !== undefined){
                        //console.log(loadRowID);
                       //console.log("$( #" + nextRowID +").load("+CRPages[nextRowID].filename + " .cr-wrapper)");
                       $( ".cr-wrapper.loading."+loadRowID).load(CRPages[loadRowID].filename + " .cr-wrapper", function() {
                          var cnt = $(this).find(".cr-wrapper").contents();
                          $(this).find(".cr-wrapper").replaceWith(cnt);
                          $(this).removeClass('loading');
                          $('html, body').scrollTop($("#p"+activeRowID).offset().top);
                       });
                    }
                }             
            }


            function smoothScrollTo($target){
                //Function to process the scroll animation
                if ($target.length) {
                    $(".mainbody.active").removeClass("active");
                    $target.addClass("active pause");
                    $(".makefixed").removeClass("fixed");

                    $("html").bind('wheel.pauseMovement', function(){
                        return false;
                    });

                    $(".scroll-btn").fadeOut();

                    $('html,body').animate({
                      scrollTop: $target.offset().top
                    }, 1000, "easeOutQuad", 
                        function() {
                            $(".scroll-btn").fadeIn("slow");
                            initializeActivePage();
                            
                            $("html").unbind( ".pauseMovement" );
                        }

                    );
                  
                    setTimeout(function(){
                        $(".mainbody.active").removeClass("pause");
                    }, 1500, "easeOutQuad");
                }
            }





            function initializeActivePage(){
                //Function to set up page after it becomes active.
                //give the mainbody focus for keyboard controls.
                $(".mainbody.active").focus();
                //if there's an image that is supposed to be fixed, giv eit the fixed class
                if ($(".mainbody.active .makefixed").length !== 0){
                    $(".mainbody.active .makefixed").addClass("fixed");
                }
                
                //set the IDs for the current active page, prev page, and next page                
                activeRowID = Number($(".mainbody.active").attr('id').substring(1));
                prevRowID = "p" + String(Number(activeRowID) - 1);
                nextRowID = "p" + String(Number(activeRowID) + 1);
                
                chapterID = $(".mainbody.active").parent().attr('data-chapter');

                if (activeRowID === 1){
                    $(".mouse").fadeIn('slow');
                    $(".nav-up").fadeOut(100);                    
                    $(".nav-down").fadeIn('slow');
                } else if (activeRowID === 23){
                    $(".mouse").fadeIn('slow');
                    $(".nav-up").fadeIn('slow');                
                    $(".nav-down").fadeOut(100);     
                } else {
                    $(".mouse").fadeOut(100);
                    $(".nav-up").fadeIn('slow');
                    $(".nav-down").fadeIn('slow');
                }
                //console.log(chapterID);
                $(".sharing").removeClass("scrollWith");
                //Update the URL to show the active page's filename                
                if (CRPages[chapterID] !== undefined){
                    history.replaceState(null, null, CRPages[chapterID].filename);
                    var $sharingElements = $(".sharing, .share-only, .sharing-tab");
                    $sharingElements.attr("data-url", window.location.href);
                    $("meta[property='og:title']").attr('content', CRPages[chapterID].ogtitle + " | JPMorgan Chase & Co.");
                    $("title").text(CRPages[chapterID].ogtitle + " | JPMorgan Chase & Co.");
                    var descriptText = CRPages[chapterID].twittershare;
                    descriptText = descriptText.replace(/#/g, "%23");
                    descriptText = descriptText.replace(/ /g, "+");
                    descriptText = descriptText.replace(/(\|| ,)/g, "%7C");
                    descriptText = descriptText.replace(/&/g, "%26");
                    $(".twitter").attr("data-text", descriptText);
                    //console.log($(".page-title").text() + ": " + CRPages[chapterID].ogtitle);
                    if ($(".page-title").text() !== CRPages[chapterID].chaptertitle){
                        $(".page-title").addClass('change');
                        createShareLinks($sharingElements);
                        setTimeout(function() {
                            $(".page-title").text(CRPages[chapterID].chaptertitle);
                           $(".page-title").removeClass('change');
                        }, 250);   
                    }
                }

              


                var CRPagesKeys = Object.keys(CRPages);
                var CurrentIndex = CRPagesKeys.indexOf("p" + String(Number(activeRowID)));
                var PrevIndex = CurrentIndex - 1;
                var prevChapterID = CRPagesKeys[PrevIndex];

                //console.log("prevChapterID: " + prevChapterID);

                //Load prev page if it hasn't been loaded yet
                if(CRPages[prevChapterID] !== undefined){
                    loadPage(CRPages[prevChapterID].index);
                }

                //Load next page if it hasn't been loaded yet
                if(CRPages["p"+String(activeRowID + 1)] !== undefined){
                    loadPage(activeRowID+1);
                }

                //console.log("$('html, body').scrollTop(" + $('#p'+activeRowID).offset().top + ")");
                //$('html, body').scrollTop($("#p"+activeRowID).offset().top);
                
                //Check to see if this page is scrollable, add classes to show what parts have been read.
                checkContentRead();
            }




            function processMovement(moveDirection){
                //console.log("processMovement");
                 checkContentRead();
                if(!$(".mainbody.active").hasClass("pause") && !$("body").hasClass('nav-open')){

                   
                    if(moveDirection === "up" && $(".mainbody.active").hasClass("readStart")  &&  prevRowID !== "p0")
                    {
                        //UP
                        //console.log("up to " + prevRowID);
                        smoothScrollTo($( "#" + prevRowID));
                        $(".mainbody.active").scrollTop($(".mainbody.active").prop('scrollHeight'));
                        return true;
                    }
                    else if(moveDirection === "down" && $(".mainbody.active").hasClass("readEnd"))
                    {
                        //DOWN
                        //console.log("down to " + nextRowID);
                        smoothScrollTo($( "#" +nextRowID));

                        return true;
                    } else {
                        return false;
                    }
                } else {
                    return false;
                }
            }

            function checkContentRead(){

                // if ($(".mainbody.active .content-section").length === 0){
                //      $(".mainbody.active").addClass("readStart readEnd");
                // } else {

                    var totalContentHeight = $(".mainbody.active").prop('scrollHeight');
                    var totalContentRead = $(".mainbody.active").scrollTop() + $(".mainbody.active").outerHeight();

                    //console.log($(".mainbody.active").prop('scrollHeight') + " " + $(".mainbody.active").scrollTop() + " " + $(".mainbody.active").outerHeight());
                    //console.log($(".mainbody.active").attr('id') + "totalContentHeight: " + totalContentHeight + "   totalContentRead: " + totalContentRead);
                    if (totalContentHeight === totalContentRead){
                        //setTimeout(function(){
                            $(".mainbody.active").addClass("readEnd");
                        //}, 200);
                    } else {
                       $(".mainbody.active").removeClass("readEnd"); 
                    }


                    if ($(".mainbody.active").scrollTop() === 0){
                        //setTimeout(function(){
                            $(".mainbody.active").addClass("readStart");
                        //}, 200);
                    } else {
                       $(".mainbody.active").removeClass("readStart"); 
                    }

                    // if ($(".mainbody.active").scrollTop() !== 0 && totalContentHeight !== totalContentRead){
                    //     $(".mainbody.active").addClass("readMid");
                    // } else {
                    //     $(".mainbody.active").removeClass("readMid");
                    // }
                // }

            }
 


            //If Desktop
            if ($('html').hasClass('desktop')){

                //Mouse Wheel Binding
                $(window).bind('wheel', function(e){
                    //Check to see if this page is scrollable, add classes to show what parts have been read.
                    checkContentRead();
                    if (pageMoveDirection === ""){
                        //console.log("pageMoveDirection " + pageMoveDirection);
                        if(e.originalEvent.deltaY > 0){
                            pageMoveDirection = "down";
                        }
                        else if(e.originalEvent.deltaY < 0){
                            pageMoveDirection = "up";
                        } 
                        processMovement(pageMoveDirection);
                    } else {
                        //console.log("already set" + pageMoveDirection);
                    }
                    if(this.rangeTimeOut) {
                        clearTimeout(this.rangeTimeOut);
                    }
                    this.rangeTimeOut = setTimeout(function() {
                        pageMoveDirection = "";
                       
                    }, 40);   
                });

                //Keyboard Bindings
                $(document).keydown(function(e) {
                   var code = (e.keyCode ? e.keyCode : e.which);
                    if (code === 40) {
                        pageMoveDirection = "down";
                        //return false;
                    } else if (code === 38) {
                        pageMoveDirection = "up";
                        //return false;
                    }

                    processMovement(pageMoveDirection);

                    if(this.rangeTimeOut) {
                        clearTimeout(this.rangeTimeOut);
                    }
                    this.rangeTimeOut = setTimeout(function() {
                        pageMoveDirection = "";
                    }, 10);   
                });

                 $(window).load(function() {
                 // executes when complete page is fully loaded, including all frames, objects and images
                     setTimeout(function() {
                         var gotoID = $(".mainbody.active").attr('id').substring(1);
                         //console.log("loading " + gotoID);
                         $('html, body').scrollTop($("#p"+gotoID).offset().top);
                          $(".sharing").removeClass("scrollWith");
                      }, 0);
                });

            } else {
                //Else Mobile
                $('scroll-btn').hide();
            }//End If Desktop



            //Resize Binding
            $( window ).resize(function() {
                //make sure you're still on your page after a resize
                //important because much of contentent is sized based on viewport size.
                if(this.rangeTimeOut) {
                    clearTimeout(this.rangeTimeOut);
                }
                this.rangeTimeOut = setTimeout(function() {
                    $('html, body').animate({
                        scrollTop: parseInt($(".mainbody.active").offset().top)
                    }, 100);
                    checkContentRead();
                }, 50);

            });




            function startUp() {
                //startup function when page is first loaded.

                $(".sharing").removeClass("scrollWith");



                if ($('html').hasClass('desktop')){
                    //set the active page based on the current URL
                    var currentPage = document.location.pathname.match(/[^\/]+$/)[0];
                    activeRowID = 0;

                    $(".cr-wrapper").addClass("originalwrapper");

                    $.each(CRPages, function (id) {
                        //loop through all the pages until you find the page that has the same filename as your current URL
                         

                        //console.log(id);
                        if (this.filename === currentPage) {
                            $("#"+id).addClass("active");
                            $(".cr-wrapper.originalwrapper").attr('data-chapter', id);
                            activeRowID = Number(id.substring(1));
                        } else if(activeRowID === 0){
                            //creates placeholders for all other "chapters"
                            $(".originalwrapper").before("<div  class='cr-wrapper loading " + id + "' data-chapter='" + id + "'></div>");  
                        } 
                        else if(activeRowID) {
                            //creates placeholders for all other "chapters"
                            //$("#p"+activeRowID).parent().after("<div  class='cr-wrapper loading " + id + "'></div>");  
                            $("body").append("<div  class='cr-wrapper loading " + id + "' data-chapter='" + id + "'></div>");  
                        }
                    });
            
                    initializeActivePage();
                }
                //console.log(CRPages["p"+String(activeRowID-1)]);


                //$("body").append("<div  class='cr-wrapper loading'></div>");   
                // setTimeout(function() {
                //     //console.log("$('html, body').scrollTop(" + $('#p'+activeRowID).offset().top + ")");
                //     $('html, body').scrollTop($("#p"+activeRowID).offset().top);

                // }, 500);
            
            }

            //Now let's run the startup function
            startUp();



            /*Function for creating sharing links on the pages. This is coded for Facebook, twitter, linkedIn and GooglePlus.
            This is done by setting the value for the links on the page on load. In general, values specified in the HTML overide the passed parameters.
                The parameters are:
            $target: The jQuery element to set links for.
            urlVar: [Optional] A string paramter for a variable to add to the URL. Can be used for sharing a specific video or subsection.
                Overwritten in the HTML by 'data-url' in the '.sharing' div. If not value is provided, the URL in the addressbar is used.
            title: [Optional] A string to use as a title in the shared text. Currently only used for Twitter.
                Overwritten in the HTML by a 'data-text' value in the HTML of the Twitter link. This can include a hashtag (#) or a via @ User
                for Twitter.
            */
            function createShareLinks($target, urlVar, title, via, summary){

                //linkURL is the url of the link to go to.
                var linkURL;
                //If there is a value in the HTML, use that.
                if ( $target.attr("data-url") ){
                    linkURL = $target.attr("data-url");
                }
                else{
                    //If there is not a value provided, use the page location. Remove any variables from the URL. If a variable is needed, use data-url or urlVar paramter.
                    var windowLocaitonHref = window.location.href;
                    if (windowLocaitonHref.indexOf("?mod=") > 0){
                        linkURL = windowLocaitonHref.substring(0, windowLocaitonHref.indexOf("?mod="));
                    }
                    else if(windowLocaitonHref.indexOf("?ilv=") > 0){
                        linkURL = windowLocaitonHref.substring(0, windowLocaitonHref.indexOf("?ilv="));
                    }
                    else{
                        linkURL = window.location.href;
                    }
                }

                //If a 'data-video-id' is provided, add it to the URL. This is for inline videos, to know which video to go to.
                if ($target.attr("data-video-id")){
                    linkURL = linkURL + "?ilv=" + $target.attr("data-video-id");
                }
                //Add the urlVar if provided.
                else if (urlVar){
                    linkURL = linkURL + urlVar;
                }

                //Encode the URL.
                var encodedURL = encodeURI(linkURL);

                //Get a handle on the twitter link. Get the descriptText from the 'data-text' value or title paramter.
                var $twitter = $($target.find(".twitter"));
                var descriptText="";
                if ($twitter.attr("data-text")){
                    descriptText = $twitter.attr("data-text");
                }
                else if(summary){
                    descriptText = summary;
                }

                //if summary is not set use og:title as summary for mail link
                if(!title){
                    title = encodeURIComponent($("meta[property='og:title']").attr('content'));
                }

                /*Necessary string replacements for the Twitter description. This replaces certain special
                characters that cause errors in the Twitter description.*/
                descriptText = descriptText.replace(/#/g, "%23");
                descriptText = descriptText.replace(/ /g, "+");
                descriptText = descriptText.replace(/(\|| ,)/g, "%7C");
                descriptText = descriptText.replace(/&/g, "%26");

                /*Set the "via" property. If no "data-via" is set in the HTML it checks for a passed
                value. If that is not there it will not be included.
                The words "via" and the @ symbol are added automatically by Twitter.
                */
                var twitterVia="";
                if ($twitter.attr("data-via")){
                    twitterVia = $twitter.attr("data-via");
                    twitterVia = "&via=" + twitterVia;
                }
                else if (via){
                    twitterVia = "&via=" + via;
                }

                var $linkedIn = $target.find(".linkedIn");
                /*Get the linkedIn Summary from the HTML*/
                var linkedInSummary = "";
                if ($linkedIn.attr("data-text")){
                    linkedInSummary = $linkedIn.attr("data-text");
                }
                else if(summary){
                    linkedInSummary = summary;
                }

                /*Replacements for some special characters in the linkedIn text. Special characters
                caused some text to be misinterpreted.*/
                linkedInSummary = linkedInSummary.replace(/#/g, "%23");
                linkedInSummary = linkedInSummary.replace(/&/g, "%26");

                //Get the OG description tag text to use in the mail share.
                var mailText;
                if ($("head meta[property='og:description']").attr("content")){
                    mailText = $("head meta[property='og:description']").attr("content");
                }
                //If the OG desription tag is not available, use the linked in text.
                else if (linkedInSummary) {
                    mailText = linkedInSummary;
                }
                //If the neither the LinkedIn summary nor the OG description is present, use the summary.
                else if (summary){
                    mailText = summary;
                }
                //If none of the above are available, don't use anything. This is needed so the link still works.
                else{
                    mailText = "";
                }

                //The text must be properly encoded.
                mailText = mailText.replace(/#/g, "%23");
                //mailText = mailText.replace(/ /g, "+");
                mailText = mailText.replace(/(\|| ,)/g, "%7C");
                mailText = mailText.replace(/&/g, "%26");

                //Get a handle on the links.
                var $facebook = $target.find(".facebook");
                var $googlePlus = $target.find(".googlePlus");
                var $mail = $target.find(".mail");

                //Set the links for each button.
                $facebook.attr("href", "https://www.facebook.com/sharer/sharer.php?u=" + encodedURL);

                //The Twitter Via will only display if one was provided, otherwise it is an empty string.
                $twitter.attr("href", "https://twitter.com/intent/tweet?text=" + descriptText + "+" + encodedURL + twitterVia);

                $linkedIn.attr("href", "https://www.linkedin.com/shareArticle?mini=true&url=" + encodedURL + "&summary=" + linkedInSummary);

                $googlePlus.attr("href", "https://plus.google.com/share?url=" + encodedURL);

                //Make the email link with subject and body. The %0A is an encoded line break.
                $mail.attr('href','mailto:?subject='+title+'&body='+ mailText + "%0A" + encodedURL);
            }



        });




$(".sharing").removeClass("scrollWith");        