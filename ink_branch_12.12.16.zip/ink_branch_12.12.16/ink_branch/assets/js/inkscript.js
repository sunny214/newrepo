 $(document).ready(function() {
    
    /*var ink_heading = $('.ink_heading_bdr h1 a');
     $('.main_header .container-fluid:eq(1) .nav ').before('<h2 class="nav_head">' + ink_heading + '</h2>');
     $('.nav_head').css("display", "none");*/

     // var left_t=$(".index .left_text")

     
        
     $(window).scroll(function() {
         // console.log($(this).scrollTop());
         if ($(this).scrollTop() >= 27) {
             $('.main_header').addClass("sticky");
             $('.nav_head').css("display", "block");
             $('.ink_small').show();

         } else {
             $('.main_header').removeClass("sticky");
             $('.nav_head').css("display", "none");
             $('.ink_small').hide();
         }

         // if($(window).scrollTop()>=left_t.offset().top+left_t.height()-30){
         //    $('.ink_logo_small').show();
         // }else{
         //     $('.ink_logo_small').hide();
         // }

    
         
     });
     //$('.article_parent').css("display","none");
     
   //pop-up code start
//    $('#image-gallery').lightSlider({
//                 gallery:true,
//                 item:1,
//                 thumbItem:9,
//                 slideMargin: 0,
//                 speed:500,
//                 auto:true,
//                 loop:true,
//                 onSliderLoad: function() {
//                     $('#image-gallery').removeClass('cS-hidden');
//                 }  
//             });
//  setTimeout(function(){
//       $('.article_parent').hide();
//   },50)
//    $('.img-article').click(function(){
//            $('.article_parent').show();
// console.log('text');
//            $(window).on('keyup',function(e){

//              // console.log('window');
//             if(e.which == 37){                
//                     // console.log(e.which,'::::if',$('.lSSlideOuter').find('.lSPrev'));
//                     $('.lSSlideOuter').find('.lSPrev').trigger('click');
//                      console.log('left');
//             }
//             else if(e.which ==39){
//                     // console.log(e.which,'::::else',$('.lSSlideOuter').find('.lSNext'));
//                     $('.lSSlideOuter').find('.lSNext').trigger('click');
//                      console.log('right');
//             }
//            });
//     });
//      $('.popUp-close').click(function(){
//            $('.article_parent').hide();
//             $(window).off('keyup');
//      });
//      //pop-up code ends here
       var hamburger=false;
     $('.mobile_hambargar').click(function(){
        
        if(hamburger==false){
            $('.mobile-menuItems').addClass('active');
            hamburger=true;
        }else{
             $('.mobile-menuItems').removeClass('active');
            hamburger=false;
        }

     })

 });
