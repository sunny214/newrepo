'use strict';

var _invokeQueueNum = 62,
      requiresNum = 4,
      CheckExistConstruct = function(obj) {
        return function () {
          var checkExist = setInterval(function() {
             if (obj) {
                clearInterval(checkExist);
             }
          }, 100);
        };
      };

function checkObject(obj) {

    var checkExist = setInterval(function() {
       if (obj) {
          clearInterval(checkExist);
          obj.should.exist();
       }
    }, 100); // check every 100ms    
}

function ObjectReady(obj, callback) {

    var checkExist = setInterval(function() {
       if (obj) {
          clearInterval(checkExist);
          callback(obj);
       }
    }, 100); // check every 100ms      

}


describe('DOM Sanity Check', function() {

  beforeEach(function(){
    var beforeDomCk = new CheckExistConstruct(document.getElementsByTagName('main'));
    beforeDomCk();
  });


  it('Main element should be loaded.', function() {
    checkObject(document.getElementsByTagName('main'));
  });

  it('Main element should have role attribute "main".', function() {
    new ObjectReady(document.getElementsByTagName('main'), function(result) {
      result[0].getAttribute('role').should.equal('main');
    });
  });

});

describe('Angular Sanity Check', function() {

  beforeEach(function(){
    var beforeAngularCk = new CheckExistConstruct(window.angular);
    beforeAngularCk();
  });


  it('Angular should be loaded.', function() {
    checkObject(window.angular);
  });    

  it('_invokeQueue should equal ' + _invokeQueueNum + ' corresponding to the number of angular dependencies.', function() {
    angular.module('jpmorganApp')._invokeQueue.length.should.equal(_invokeQueueNum);
  });  

  it('requires should equal ' + requiresNum + ' corresponding to the number of angular modules.', function() {
    angular.module('jpmorganApp').requires.length.should.equal(requiresNum);
  });  

});

describe('jQuery Sanity Check', function() {

  beforeEach(function(){
    var beforejQueryCk = new CheckExistConstruct(window.jQuery);
    beforejQueryCk();
  });  

  it('jQuery should be loaded.', function() {
    checkObject(window.jQuery);
  });    

});

describe('Library Sanity Check', function() {

  beforeEach(function(){
    var beforeLibCk = new CheckExistConstruct(window.videojs);
    beforeLibCk();
  });    

  it('videojs should be loaded.', function() {
    checkObject(window.videojs);
  });    

  it('momentJS should be loaded.', function() {
    checkObject(window.moment);
  });    

  it('Lodash should be loaded.', function() {
    checkObject(window._);
  });    

  it('owlCarousel should be loaded.', function() {
    checkObject(window.jQuery().owlCarousel);
  });   

  it('TypedJS should be loaded.', function() {
    checkObject(window.jQuery().typed);
  });     

  it('nanoScroller should be loaded.', function() {
    checkObject(window.jQuery().nanoScroller);
  });       

});