# JPMorgan Chase Careers

```
   ____
  / ___|   __ _   _ __    ___    ___   _ __   ___
 | |      / _` | | '__|  / _ \  / _ \ | '__| / __|
 | |___  | (_| | | |    |  __/ |  __/ | |    \__ \
  \____|  \__,_| |_|     \___|  \___| |_|    |___/

```


## Prerequisites 
- NodeJS
- Bower
- Grunt

## Get up and running
1. `npm install -g grunt-cli bower`
2. `bower install`
3. `npm install`
4. `grunt` To run developnment environment. To run without karma tests `grunt dev:nokarma`
5. `grunt build` To build application. To build without karma tests `grunt build:nokarma`

## Notes
- grunt-php will start a php server.
- karma requires php in the executable PATH to test php files.
- If you need to add a new Angular dependency (eg Directive, Factory, Service, Provider, Module) you will need to update `test/sanity.spec.js` _invokeQueueNum and requiresNum. Error output will provide details on what needs updating.
- BrowserSync refreshes the browser when watched files are saved. For more information https://fettblog.eu/php-browsersync-grunt-gulp/
- If grunt is not installed run `npm install -g grunt-cli`.
- To develop `grunt dev` in root of folder, grunt will create `careers.css`, `modules.js` and `script.js` with map files for easier debugging, automatically recompile css and javascript, start local php dev server and open homepage in default browser.
- To compile `grunt build` in root of folder, grunt will replace the `careers.css`, `modules.js` and `script.js`. 
- Vendor file is not compiled currently. To add vendor build uncomment the code blocks in Gruntfile.js that start with "Vendor Build".


## Create Branches for Modules
- For each module that you wish to modify, create a new branch, naming it according to the module, e.g. `Hero Module` or `Advice-Event Promo`

## Bower Dependencies for vendor.js
- JQuery v2.1.4
- JQuery-UI v1.11.2
- Angular v1.4.1
- Angular-animate v1.4.1
- Angular-sanitize v1.4.7
- JQuery Easing v1.3.1
- JQuery BttrLazyLoading v1.0.8
- Owlcarousel v1.3.2
- Lodash v2.4.2
- Angular-google-maps v2.1.6
- Typed.js v1.1.1
- Moment v2.10.3
- Nanoscroller v0.8.7