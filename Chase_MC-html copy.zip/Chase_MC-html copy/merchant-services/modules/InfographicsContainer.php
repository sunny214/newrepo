<section class="infographicsContainerModule module-padding-medium-both">
<div class="container">
  <div id="profiles-intro" class="row">
    <div class="col-xs-12 col-sm-10 col-sm-offset-1 text-center">
      <h2 id="intro__title" class="beta module-title">Operations Teams</h2>
    </div>
  </div>
</div>
<div class="container colnoleftpadding-xs colnorightpadding-xs">
  <div class="row">
    <div class="col-xs-12 padding-reset">
      <div class="mcarousel">
        <div id="whyus-impact-carousel__container" data-carousel="" data-resolution="{{$root.deviceResolution}}" data-carousel-mobile="true" data-carousel-tablet="true" data-carousel-desktop="true" data-navigation="true" class="module no-overflow no-module-padding carousel hover-button text-center why-us-carousel carousel-control-color-red"><div id="whyus-impact__img-container" class="col-xs-12 padding-reset">
          <div class="item">
            <figure>
              <img class="lazy img-responsive visible-lg-inline visible-md-inline visible-sm-inline visible-xs-block" data-bttrlazyloading-xs-src="/assets/images/dm21-infographic-fpo.gif" data-bttrlazyloading-sm-src="/assets/images/dm21-infographic-fpo.gif" alt="Global Cities Initiative" />
            </figure>        
          </div>
        </div>
        <div id="whyus-impact__img-container" class="col-xs-12 padding-reset">
          <div class="item">
            <figure>
              <img class="lazy img-responsive visible-lg-inline visible-md-inline visible-sm-inline visible-xs-block" data-bttrlazyloading-xs-src="/assets/images/dm21-infographic-fpo.gif" data-bttrlazyloading-sm-src="/assets/images/dm21-infographic-fpo.gif" alt="Tech For Social Good" />
            </figure>
          </div>
        </div>
        <div id="whyus-impact__img-container" class="col-xs-12 padding-reset">
          <div class="item">
            <figure data-ng-init="showVideo[1] = false;">
              <div id="profile_video__wrapper" class="carousel-video-wrapper">
                <div class="video-containing-block">
                  <div class="video-inner-wrapper">
                    <video data-video-id="4949216608001"
                      data-account="1139173452001"
                      data-player="a6771937-047d-4f5f-88e6-a697b37b5456"
                      data-embed="default"
                      class="video-js"
                      controls
                    style="width: 100%; height: 100%; position: absolute; top: 0px; bottom: 0px; right: 0px; left: 0px;"></video>
                  </div>
                </div>
              </div>
              </div>
              </div>         
            </figure>
          </div>
        </div>
      </div>
    </div>
  </div>
  <div class="row">
    <div class="col-xs-12 col-sm-8 col-sm-offset-2">
      <article class="txt-block-btn">
        <p id="txt-block-btn__desc" class="margin-top-sm text-xs-left col-xs-12">Our Operations teams manage and process our clients&#8217; business. We develop innovative and secure services and solutions that meet our clients&#8217; end-to-end needs. Our work leads to increased productivity and efficiencies for our clients and the firm.</p>
      </article>
    </div>
  </div>
  </section>