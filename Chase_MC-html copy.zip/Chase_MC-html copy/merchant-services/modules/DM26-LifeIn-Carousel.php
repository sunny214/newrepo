<section id="life-in-grid" data-tabs="" class="module asset-grid tabs no-bottom-module-margin module-padding-large-x bg-white">
  <div class="container">
    <div class="row">
      <div class="col-xs-12 col-md-8 col-md-push-2">
        <div id="life-in-intro"><article class="title-desc">
          <h2 id="intro__title" class="title-desc__title {{extraclass}}">Life in New York</h2>
        </article>
      </div>
    </div>
  </div>
</div>
<div class="container-fluid tabs-wrapper no-bg">
  <div class="row">
    <div class="col-xs-12 text-center text-xs-left">
      <a href="#" class="visible-xs tabs-header">&nbsp;</a>
      <ul id="tabs-container" class="tabs">
        <li id="asset-grid-item" class=" active"><a id="asset-grid-item__a" href="#out-about" data-url="assets/ajax/LifeInCarouselSlides/11111" class=" firstItem active">Out &amp; about</a></li>
        <li id="asset-grid-item"><a id="asset-grid-item__a" href="#lifestyle" data-url="assets/ajax/LifeInCarouselSlides/22222">Lifestyle</a></li>
        <li id="asset-grid-item"><a id="asset-grid-item__a" href="#famous-for" data-url="assets/ajax/LifeInCarouselSlides/33333">Famous for</a></li>
        <li id="asset-grid-item"><a id="asset-grid-item__a" href="#food-drink" data-url="assets/ajax/LifeInCarouselSlides/44444">Food &amp; drink</a></li>
        <li id="asset-grid-item"><a id="asset-grid-item__a" href="#travel" data-url="assets/ajax/LifeInCarouselSlides/55555">Travel</a></li>
      </ul>
    </div>
  </div>
</div>
<!-- <div class="grid-contents inline-data-tab-grid-contents" data-animation="fadeIn" data-dynamic-html="gridContentHtml"></div> -->
<div id="" class="grid-contents inline-data-tab-grid-contents" data-animation="fadeIn" data-dynamic-html="gridContentHtml"></div>
</section>