<footer class="footer">
      <div class="footer">
        <div class="feature-container">
          <div class="footer__module-footer">
            <div class="footer__module-footer__section">
              <div class="footer__module-footer__section--disclaimer"></div>
              <div class="footer__module-footer__section__followus footer-divider">
                <span class="footer__module-footer__section__followus--text">Follow us:</span>
                <ul class="footer__module-footer__section__followus--links">
                  <li class="footer__module-footer__section__followus--link">
                    <a class="icon-facebook chaseanalytics-opt-exlnk" data-pt-name="fm_share_fb" href="https://www.facebook.com/chase" target="_blank"><span class="accessible-text">Link to Facebook</span> <span class="accessible-text">(Opens Overlay)</span></a>
                  </li>
                  <li class="footer__module-footer__section__followus--link">
                    <a class="icon-instagram chaseanalytics-opt-exlnk" data-pt-name="fm_share_instagram" href="https://instagram.com/chase" target="_blank"><span class="accessible-text">Link to Instagram</span> <span class="accessible-text">(Opens Overlay)</span></a>
                  </li>
                  <li class="footer__module-footer__section__followus--link">
                    <a class="icon-twitter chaseanalytics-opt-exlnk" data-pt-name="fm_share_twitter" href="https://twitter.com/Chase" target="_blank"><span class="accessible-text">Link to Twitter</span> <span class="accessible-text">(Opens Overlay)</span></a>
                  </li>
                  <li class="footer__module-footer__section__followus--link">
                    <a class="icon-youtube chaseanalytics-opt-exlnk" data-pt-name="fm_share_youtube" href="https://www.youtube.com/chase" target="_blank"><span class="accessible-text">Link to YouTube</span> <span class="accessible-text">(Opens Overlay)</span></a>
                  </li>
                  <li class="footer__module-footer__section__followus--link">
                    <a class="icon-linkedin chaseanalytics-opt-exlnk" data-pt-name="fm_share_linkedin" href="https://www.linkedin.com/company/chase?trk=company_logo" target="_blank"><span class="accessible-text">Link to LinkedIn</span> <span class="accessible-text">(Opens Overlay)</span></a>
                  </li>
                  <li class="footer__module-footer__section__followus--link">
                    <a class="icon-pinterest chaseanalytics-opt-exlnk" data-pt-name="fm_share_pinterest" href="https://www.pinterest.com/chase/" target="_blank"><span class="accessible-text">Link to Pinterest</span> <span class="accessible-text">(Opens Overlay)</span></a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
        <div class="feature-container">
          <div class="footer__module-footer">
            <div class="footer__module-footer__section">
              <div class="footer__module-footer__section--footer">
                <div class="footer__module-footer__section--footer-link__text link-disclaimer">
                  <p>This site is intended for media use only.</p>
                  <p>&ldquo;Chase,&rdquo; &ldquo;JPMorgan,&rdquo; &ldquo;JPMorgan Chase,&rdquo; the JPMorgan Chase logo and the Octagon Symbol are trademarks of JPMorgan Chase &amp; Co.&nbsp;</p>
                  <script>
                  $(document).ready(function() {
                  $(".footer__module-footer__section--footer-links li:last a").addClass("choices-logo");
                  $(".footer__module-footer__section--footer-links").append('<li class="footer__module-footer__section--footer-link"><span>Member FDIC<\/span><\/li> <li class="footer__module-footer__section--footer-link"><span class="footer__module-footer__section--footer-link__text"><span class="footer__module-footer__section--footer-link__icon equal-housing-img"><\/span>Equal Housing Lender<\/span><\/li>');
                  $('.footer__module-footer__section--footer-links a').each(function() {
                  var footerPTname = $(this).text().toLowerCase().split('(')[0].replace(/\s+/g, '_').substring(0, 27);
                  $(this).attr('data-pt-name', 'fm_' + footerPTname);
                  });
                  });
                  </script>
                </div>
                <ul class="footer__module-footer__section--footer-links">
                  <li class="footer__module-footer__section--footer-link">
                    <a class="chaseanalytics-track-link" data-pt-name="fm_privacy" href='https://www.chase.com/digital/resources/privacy-security' target='_blank'>Privacy</a>
                  </li>
                  <li class="footer__module-footer__section--footer-link">
                    <a class="chaseanalytics-track-link" data-pt-name="fm_privacy" href='https://www.chase.com/digital/resources/privacy-security' target='_blank'>Security</a>
                  </li>
                  <li class="footer__module-footer__section--footer-link">
                    <a class="chaseanalytics-track-link" data-pt-name="fm_privacy" href='https://www.chase.com/digital/resources/terms-of-use' target='_blank'>Terms of use</a>
                  </li>
                  <li class="footer__module-footer__section--footer-link">
                    <a class="chaseanalytics-track-link" data-pt-name="fm_privacy" href='https://www.chase.com/digital/resources/accessibility' target='_blank'>Our commitment to accessibility</a>
                  </li>
                  <li class="footer__module-footer__section--footer-link">
                    <a class="chaseanalytics-track-link" data-pt-name="fm_privacy" href='https://www.chase.com/mortgage/mortgage-assistance' target='_blank'>Help for homeowners</a>
                  </li>
                  <li class="footer__module-footer__section--footer-link">
                    <a class="chaseanalytics-track-link" data-pt-name="fm_privacy" href='https://www.chase.com/resources/sitemap' target='_blank'>Site map</a>
                  </li>
                  <li class="footer__module-footer__section--footer-link">
                    <a class="chaseanalytics-track-link" data-pt-name="fm_privacy" href='http://www.aboutads.info/choices/' target='_blank'>AdChoices</a>
                  </li>
                </ul>
                <div class="footer__module-footer__section--footer-link__text copyright">
                  <p></p>
                  <p style="text-align: center;">&copy; 2016 JPMorgan Chase &amp; Co.</p>
                  <p></p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
    
 <div class="sidemenu__overlay closed"></div>
 
 
 
 
 
 
 
 
 <!--googleoff: index-->
     <div class="speedbump">
      <div class="speedbump__wrapper">
        <div aria-labelledby="speedbump_header" class="speedbump" data-speedbump-type="default" role="alertdialog">
          <div class="speedbump__inner col-xs-12 col-sm-7">
            <p class="speedbump__inner--header" id="speedbump_header">You're Now Leaving Chase</p>
            <div class="speedbump__inner--desc">
              <p>Chase's website terms, privacy and security policies don't apply to the site you're about to visit. Please review its website terms, privacy and security policies to see how they apply to you. Chase isn't responsible for (and doesn't provide) any products, services or content at this third-party site, except for products and services that explicitly carry the Chase name.</p>
            </div>
            <div class="speedbump__inner--links col-sm-12 col-xs-12">
              <a class="btn btn--secondary speedbump__inner--links__cancel col-sm-4 col-xs-5" href="#">Cancel</a> <a class="btn btn--secondary speedbump__inner--links__proceed col-sm-4 col-xs-5" href="#">Proceed</a>
            </div>
          </div>
        </div>
      </div><!-- END speedbump__wrapper -->
    </div>
     <!-- No spanish speed bump found -->
   <!--googleon: index-->