	<div class="hero-container" > 
	       <div class="hero"> 
		 	<h1 class="title">Merchant Services</h1>
		      <img src='http://placekitten.com/1260/502' alt='hero image'> 
	       </div>
	</div>