  <!--<footer data-footer="" id="footer" class="footer">
    <div class="scroll-top">
      <a href="#top" title="Back to top"><i class="icon-arrow-up-fill"></i></a>
    </div>

    <section id="footer-main" class="footer-main link-bordered">
      <div class="container footer__content">
        <div class="row">
          <div class="col-xs-12 col-sm-8 colnoleftpadding-small-up">
            <h3 id="footer__title" class="footer-title">Your career. Your way.</h3>
          </div>
          <div class="col-xs-12 col-sm-4">
            <aside id="social-links-desktop" class="footer__social visible-sm-inline visible-md-inline visible-lg-inline "><a id="external-link__twitter" href="https://twitter.com/jpmorgan" class="twitter" target="_jpmc"><i class="icon-twitter-fill"></i></a>
              <a id="external-link__facebook" href="https://www.facebook.com/jpmorganchasecareers" class="facebook" target="_jpmc"><i class="icon-facebook-fill"></i></a>
              <a id="external-link__linkedin" href="https://www.linkedin.com/company/jpmorgan-chase" class="linkedin" target="_jpmc"><i class="icon-linkedin-fill"></i></a>
              <a id="external-link__youtube" href="https://www.youtube.com/jpmorgan" class="youtube" target="_jpmc"><i class="icon-youtube-fill"></i></a></aside>
          </div>
        </div>
        <div class="row">
          <div class="col-xs-12 col-sm-4 col-md-3 colnoleftpadding-small-up">
            <ol>
              <li id="legal-page__privacy"><a id="legal-page__privacy-link" href="http://www.jpmorganchase.com/corporate/Home/privacy.htm">Privacy &amp; Security</a></li>
              <li id="legal-page__terms"><a id="legal-page__terms-link" href="http://www.jpmorganchase.com/corporate/Home/terms.htm">Terms of Use</a></li>
              <li id="legal-page__cookie"><a id="legal-page__cookie-link" href="https://www.jpmorganchase.com/corporate/Home/cookie-policy.htm">Cookies Policy</a></li>
            </ol>
          </div>
          <div class="col-xs-12 col-sm-3 col-md-5">
            <ol>
              <li id="legal-page__oppr"><a id="legal-page__oppr-link" href="http://careers.jpmorgan.com/careers/legal-page">Legal Page</a></li>
              <li id="footer__sitemap"><a id="footer__sitemap-link" href="http://careers.jpmorgan.com/careers/sitemap">Sitemap</a></li>
            </ol>
          </div>
          <div class="col-xs-12 col-sm-4 col-md-4">
            <nav class="footer-link-jpmc">
              <ul id="footer__jpmsites-container"><li id="footer__jpmsite"><a id="footer__jpmsites-link" href="https://www.careersatchase.com/" target="_jpmc">Careers at Chase</a></li><li id="footer__jpmsite"><a id="footer__jpmsites-link" href="http://www.jpmorganchase.com/corporate/Careers/philippines.htm" target="_jpmc">Careers in the Philippines</a></li><li id="footer__jpmsite"><a id="footer__jpmsites-link" href="http://www.jpmorganchase.com/" target="_jpmc">jpmorganchase.com</a></li><li id="footer__jpmsite"><a id="footer__jpmsites-link" href="https://www.jpmorgan.com/" target="_jpmc">jpmorgan.com</a></li><li id="footer__jpmsite"><a id="footer__jpmsites-link" href="https://www.chase.com/" target="_jpmc">chase.com</a></li></ul>
            </nav>
            <aside id="social-links-mobile" class="footer__social visible-xs-inline-block"><a id="external-link__twitter" href="https://twitter.com/jpmorgan" class="twitter" target="_jpmc"><i class="icon-twitter-fill"></i></a>
              <a id="external-link__facebook" href="https://www.facebook.com/jpmorganchasecareers" class="facebook" target="_jpmc"><i class="icon-facebook-fill"></i></a>
              <a id="external-link__linkedin" href="https://www.linkedin.com/company/jpmorgan-chase" class="linkedin" target="_jpmc"><i class="icon-linkedin-fill"></i></a>
              <a id="external-link__youtube" href="https://www.youtube.com/jpmorgan" class="youtube" target="_jpmc"><i class="icon-youtube-fill"></i></a></aside>
          </div>
        </div>
      </div>
    </section>
    <section id="footer-legal" class="footer-legal">
      <div id="footer-legal__container" class="container">
        <div class="row">
          <div class="col-xs-12 col-sm-4 col-sm-push-8 ie-lang__container">
            <nav class="language-selector">
              <ul>
              <li id="lang-en-selector" class="active"><a href="." class="language-trigger" data-language="en" id="lang-en-text">ENG</a></li>
                <li id="lang-jp-selector" class=""><a href="." class="language-trigger" data-language="jp" id="lang-jp-text"> 日本語</a></li>
                <li id="lang-zh-selector" class=""><a href="." class="language-trigger" data-language="zh" id="lang-zh-text"></a></li>
              </ul>
            </nav>
          </div>
          <div class="col-xs-12 col-sm-8 col-sm-pull-4 colnoleftpadding-small-up ie-copyright__container">
            <p class="footer-copyright" id="footer-legal-text">&copy; 2016 JPMorgan Chase &amp; Co. All rights reserved.</p>
          </div>
        </div>
      </div>
    </section>
  </footer>-->
  
  
  <footer class="footer" data-footer="" id="footer">
<div class="scroll-top">
	<a href="#top" title="Back to top"><i class="icon-arrow-up-fill"></i></a>
</div>

<section id="footer-main" class="footer-main link-bordered">
      <div class="container footer__content">
        <div class="row">
          <div class="col-xs-12 col-sm-8 colnoleftpadding-small-up">
            <h3 class="footer-title" id="footer__title">Your career. Your way.</h3>
          </div>
          <div class="col-xs-12 col-sm-4">
		
            <aside class="footer__social visible-sm-inline visible-md-inline visible-lg-inline" id="social-links-desktop">
            <ul>
              <li><a class="twitter" href="#" id="external-link__twitter" target="_jpmc"><i class="icon-twitter-stroke"></i></a>
                <ul>
                  <li><a href="https://www.twitter.com/jpmorgan" target="blank">J.P. Morgan</a>
                        <hr class="footer-social-divider" />
                  </li>
                  <li><a href="https://www.twitter.com/jpmorganchase" target="blank">Chase</a></li>
                </ul>
              </li>
              </ul>
              <ul>
              <li><a class="facebook" href="#" id="external-link__facebook" target="_jpmc"><i class="icon-facebook-stroke"></i></a>
                <ul>
                  <li><a href="https://www.facebook.com/jpmorganchase" target="blank">JPMorgan Chase</a>
                        <hr class="footer-social-divider" />
                  </li>
                  <li><a href="https://www.facebook.com/chase" target="blank">Chase</a></li>
                </ul>
              </li>
              </ul>
              <ul>  
              <li><a class="linkedin" href="#" id="external-link__linkedin" target="_jpmc"><i class="icon-linkedin-stroke"></i></a>
              <ul>
                  <li><a href="https://www.linkedin.com/company/j-p-morgan" target="blank">J.P. Morgan</a>
                    <hr class="footer-social-divider" />
                  </li>
                  <li><a href="https://www.linkedin.com/company/jpmorgan-chase" target="blank">JPMorgan Chase</a>
                    <hr class="footer-social-divider" />
                  </li>
                  <li><a href="https://www.linkedin.com/company/chase" target="blank">Chase</a></li>
                </ul>
              </li>
              </ul>
              <ul>
              <li><a class="youtube" href="#" id="external-link__youtube" target="_jpmc"><i class="icon-youtube-stroke"></i></a>
              <ul>
                  <li><a href="https://www.youtube.com/user/jpmorgan" target="blank">J.P. Morgan</a>
                        <hr class="footer-social-divider" />
                  </li>
                  <li><a href="https://www.youtube.com/user/welcometochase" target="blank">Chase</a></li>
                </ul>
              </li>
              </ul>
              <ul>
              <li><a class="instagram" href="#" id="external-link__instagram" target="_jpmc"><i class="icon-instagram-stroke"></i></a>
              <ul>
                  <li><a href="https://instagram.com/jpmorgan" target="blank">J.P. Morgan</a>
                        <hr class="footer-social-divider" />
                  </li>
                  <li><a href="https://instagram.com/chase" target="blank">Chase</a></li>
                </ul>
              </li>
              </ul>
            </aside>

          </div>
        </div>
        <div class="row">
          <div class="col-xs-12 col-sm-4 col-md-3 colnoleftpadding-small-up">
            <ol>
              <li id="legal-page__privacy">
                <a href="http://www.jpmorganchase.com/corporate/Home/privacy.htm" id="legal-page__privacy-link">Privacy &amp; Security</a>
              </li>
              <li id="legal-page__terms">
                <a href="http://www.jpmorganchase.com/corporate/Home/terms.htm" id="legal-page__terms-link">Terms of Use</a>
              </li>
              <li id="legal-page__cookie">
                <a href="https://www.jpmorganchase.com/corporate/Home/cookie-policy.htm" id="legal-page__cookie-link">Cookies Policy</a>
              </li>
            </ol>
          </div>
          <div class="col-xs-12 col-sm-4 col-md-5">
            <ol>
              <li id="legal-page__oppr">
                <a href="http://careers.jpmorgan.com/careers/legal-page" id="legal-page__oppr-link">Legal Page</a>
              </li>
              <li id="footer__sitemap">
                <a href="http://careers.jpmorgan.com/careers/sitemap" id="footer__sitemap-link">Sitemap</a>
              </li>
            </ol>
          </div>
          <div class="col-xs-12 col-sm-4 col-md-4">
            <nav class="footer-link-jpmc">
              <ul id="footer__jpmsites-container">
                <li id="footer__jpmsite">
                  <a href="https://www.careersatchase.com/" id="footer__jpmsites-link" target="_jpmc">Careers at Chase</a>
                </li>
                <li id="footer__jpmsite">
                  <a href="http://www.jpmorganchase.com/corporate/Careers/philippines.htm" id="footer__jpmsites-link" target="_jpmc">Careers in the Philippines</a>
                </li>
                <li id="footer__jpmsite">
                  <a href="http://www.jpmorganchase.com/" id="footer__jpmsites-link" target="_jpmc">jpmorganchase.com</a>
                </li>
                <li id="footer__jpmsite">
                  <a href="https://www.jpmorgan.com/" id="footer__jpmsites-link" target="_jpmc">jpmorgan.com</a>
                </li>
                <li id="footer__jpmsite">
                  <a href="https://www.chase.com/" id="footer__jpmsites-link" target="_jpmc">chase.com</a>
                </li>
              </ul>
            </nav>
		
		<!-- Footer Social Links Mobile -->
             <aside class="footer__social visible-xs-inline-block" id="social-links-mobile">
             <div class="popr" data-mode="bottom" data-id="1"><a class="twitter" href="#" id="external-link__twitter" target="_jpmc">
		 	<i class="icon-twitter-stroke"></i></a></div>
             <div class="popr-box" data-box-id="1">
             <a href="https://www.twitter.com/jpmorgan" target="blank"><div class="popr-item">J.P. Morgan</div></a>
             <hr class="footer-social-divider" />
             <a href="https://www.twitter.com/jpmorganchase" target="blank"><div class="popr-item">Chase</div></a>
             </div>
 
             <div class="popr" data-mode="bottom" data-id="2"><a class="facebook" href="#" id="external-link__facebook" target="_jpmc">
		 	<i class="icon-facebook-stroke"></i></a></div>
             <div class="popr-box" data-box-id="2">
             <a href="https://www.facebook.com/jpmorganchase" target="blank"><div class="popr-item">JPMorgan Chase</div></a>
             <hr class="footer-social-divider" />
             <a href="https://www.facebook.com/chase" target="blank"><div class="popr-item">Chase</div></a>
             </div>
 
             <div class="popr" data-mode="bottom" data-id="3"><a class="linkedin" href="#" id="external-link__linkedin" target="_jpmc">
		 	<i class="icon-linkedin-stroke"></i></a></div>
             <div class="popr-box" data-box-id="3">
             <a href="https://www.linkedin.com/company/j-p-morgan" target="blank"><div class="popr-item">J.P. Morgan</div></a>
             <hr class="footer-social-divider" />
             <a href="https://www.linkedin.com/company/jpmorgan-chase" target="blank"><div class="popr-item">JPMorgan Chase</div></a>
             <hr class="footer-social-divider" />
             <a href="https://www.linkedin.com/company/chase" target="blank"><div class="popr-item">Chase</div></a>
             </div>
 
             <div class="popr" data-mode="bottom" data-id="4"><a class="youtube" href="#" id="external-link__youtube" target="_jpmc">
		 	<i class="icon-youtube-stroke"></i></a></div>
             <div class="popr-box" data-box-id="4">
             <a href="https://www.youtube.com/user/jpmorgan" target="blank"><div class="popr-item">J.P. Morgan</div></a>
             <hr class="footer-social-divider" />
             <a href="https://www.youtube.com/user/welcometochase" target="blank"><div class="popr-item">Chase</div></a>
             </div>

             <div class="popr" data-mode="bottom" data-id="5"><a class="instagram" href="#" id="external-link__instagram" target="_jpmc">
		 	<i class="icon-instagram-stroke"></i></a></div>
             <div class="popr-box" data-box-id="5">
             <a href="https://instagram.com/jpmorgan" target="blank"><div class="popr-item">J.P. Morgan</div></a>
             <hr class="footer-social-divider" />
             <a href="https://instagram.com/chase" target="blank"><div class="popr-item">Chase</div></a>
             </div>
             </aside>

          </div>
        </div>
      </div>
</section>

<section id="footer-legal" class="footer-legal">
	<div id="footer-legal__container" class="container">

		<div class="row">
			<div class="col-xs-12 col-sm-4 col-sm-push-8 ie-lang__container">
				<nav class="language-selector">
					<ul>
						<li id="lang-en-selector" class='active'><a href="/careers/home?lang=en" class="language-trigger" data-language="en" id="lang-en-text">ENG</a></li>
						<li id="lang-jp-selector" class=''><a href="/careers/home?lang=jp" class="language-trigger" data-language="jp" id="lang-jp-text">日本語</a></li>
					</ul>
				</nav>
			</div>
			<div class="col-xs-12 col-sm-8 col-sm-pull-4 colnoleftpadding-small-up ie-copyright__container">
				<p class="footer-copyright" id="footer-legal-text">
				&copy;&nbsp;2016&nbsp;JPMorgan Chase &amp; Co.&nbsp;All rights reserved.
				</p>
			</div>
		</div>

	</div><!-- #footer-legal__container -->
</section>
</footer>

