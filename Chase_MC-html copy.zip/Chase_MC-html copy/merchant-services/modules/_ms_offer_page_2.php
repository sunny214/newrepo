<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<!-- saved from url=(0063)https://commercesolutions.jpmorganchase.com/lp/compterm_cc.html -->
<html lang="en" style="display: block;"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Complimentary Terminal</title>
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<meta http-equiv="Keywords" name="Keywords" content="">
<meta http-equiv="Description" name="Description" content="">

<link rel="shortcut icon" href="https://www.chasepaymentech.com/favicon.ico">
<link rel="icon" type="image/png" href="https://www.chasepaymentech.com/favicon.png">
<link href="./Complimentary Terminal_files/usen_43.css" lang="en" media="screen" rel="stylesheet" type="text/css">
<link href="./Complimentary Terminal_files/dd.css" lang="en" media="screen" rel="stylesheet" type="text/css">
<link href="./Complimentary Terminal_files/jquery_megamenu.css" lang="en" media="screen" rel="stylesheet" type="text/css">
<link href="./Complimentary Terminal_files/print.css" lang="en" media="print" rel="stylesheet" type="text/css">
<link href="./Complimentary Terminal_files/jquery_ui_173_custom.css" lang="en" media="screen" rel="stylesheet" type="text/css">
<link href="./Complimentary Terminal_files/fancybox.css" lang="en" media="screen" rel="stylesheet" type="text/css">

<!-- Frame Busting for Clickjacking -->
<!-- <style>
html {
	display:none;
}
</style> -->
<script async="" src="./Complimentary Terminal_files/analytics.js"></script><script> if (self == top) { document.documentElement.style.display = 'block'; } else { top.location = self.location; } </script>

<!-- start head include -->
<!-- <script type="text/javascript" src="./Complimentary Terminal_files/lr.php" charset="UTF-8"></script><script type="text/javascript" src="./Complimentary Terminal_files/lr.php" charset="UTF-8"></script><script type="text/javascript" id="pixelTagExtensionScript" src="./Complimentary Terminal_files/tagmanagerextensions.js"></script><script type="text/javascript" id="personalizationScript" src="./Complimentary Terminal_files/Personalization.js"></script><script src="./Complimentary Terminal_files/compterm_cc.html"></script></head><body><div id="head-tag-include"></div> -->
<!-- /head include -->

<!--[if lt IE 7]> <link href="styles/ie6.css" rel="stylesheet" type="text/css"> <![endif]-->
<!-- ***** BEGIN ESTARA JAVASCRIPT ***** -->
<script type="text/javascript"> if(typeof(window.addEventListener)!='undefined'){ window.addEventListener('load',eStara_loadlr,false); }else if(typeof(document.addEventListener)!='undefined'){ document.addEventListener('load',eStara_loadlr,false); }else if(typeof(window.attachEvent)!='undefined'){ window.attachEvent('onload',eStara_loadlr); } function eStara_quick_append(u){ var s=document.createElement('script'); s.setAttribute('type','text/javascript'); s.setAttribute('src',u); s.setAttribute('charset','UTF-8'); if(typeof(window.attachEvent)!='undefined') document.body.appendChild(s); else  document.getElementsByTagName('head').item(0).appendChild(s); } function eStara_loadlr(){ try{ eStara_quick_append('//as00.estara.com/fs/lr.php?onload=1&accountid=200106295273',0); }catch(e){} }</script>
<!-- ***** END ESTARA JAVASCRIPT ***** -->

<!--[if lt IE 7]> <script type="text/javascript" src="scripts/unitpngfix.js"></script> <![endif]-->
<!-- <script src="scripts/jquery_1_4_3_min.js" type="text/javascript"></script> -->
<script src="https://commercesolutions.jpmorganchase.com/scripts/jquery_1_3_2_min.js" type="text/javascript" language="javascript"></script>
<script src="https://commercesolutions.jpmorganchase.com/scripts/jquery_dd.js" type="text/javascript" language="javascript"></script>
<script src="https://commercesolutions.jpmorganchase.com/scripts/jquery_megamenu.js" type="text/javascript" language="javascript"></script>
<script src="https://commercesolutions.jpmorganchase.com/scripts/jquery_ui_1_7_3_custom_min.js" type="text/javascript" language="javascript"></script>
<script src="https://commercesolutions.jpmorganchase.com/scripts/jquery_cycle_lite_1_0.js" type="text/javascript" language="javascript"></script>
<script src="https://commercesolutions.jpmorganchase.com/scripts/jquery_fancybox_1_3_4_pack.js" type="text/javascript" language="javascript"></script>
<script src="https://commercesolutions.jpmorganchase.com/scripts/jquery_hoverintent_minified.js" type="text/javascript" language="javascript"></script>
<script src="https://commercesolutions.jpmorganchase.com/scripts/chasepaymentech.js" type="text/javascript" language="javascript"></script>
<script src="https://commercesolutions.jpmorganchase.com/scripts/jquery_metadata_2_1.js" type="text/javascript" language="javascript"></script>
<script src="https://commercesolutions.jpmorganchase.com/scripts/jquery_validate_1_5_5_min.js" type="text/javascript" language="javascript"></script>
<script src="https://commercesolutions.jpmorganchase.com/scripts/cmxforms.js" type="text/javascript" language="javascript"></script>
<script src="https://commercesolutions.jpmorganchase.com/scripts/ewa_validation.js" type="text/javascript" language="javascript"></script>
<script src="https://commercesolutions.jpmorganchase.com/scripts/ddaccordion.js" type="text/javascript" language="javascript"></script>
 <script src="../../assets/scripts/form-redirect.js"></script>
<script type="text/javascript"> 
ddaccordion.init({
	headerclass: "ln-title", //Shared CSS class name of headers group
	contentclass: "ln-text", //Shared CSS class name of contents group
	revealtype: "clickgo", //Reveal content when user clicks or onmouseover the header? Valid value: "click", "clickgo", or "mouseover"
	mouseoverdelay: 200, //if revealtype="mouseover", set delay in milliseconds before header expands onMouseover
	collapseprev: true, //Collapse previous content (so only one open at any time)? true/false 
	defaultexpanded: [], //index of content(s) open by default [index1, index2, etc]. [] denotes no content.
	onemustopen: false, //Specify whether at least one header should be open always (so never all headers closed)
	animatedefault: false, //Should contents open by default be animated into view?
	persiststate: true, //persist state of opened contents within browser session?
	toggleclass: ["text-closed", "text-open"], //Two CSS classes to be applied to the header when it's collapsed and expanded, respectively ["class1", "class2"]
	togglehtml: ["prefix", "<span id='ln-icon-closed' class='ln-icon'></span>", "<span id='ln-icon-open' class='ln-icon'></span>"], //Additional HTML added to the header when it's collapsed and expanded, respectively  ["position", "html1", "html2"] (see docs)
	animatespeed: "fast", //speed of animation: integer in milliseconds (ie: 200), or keywords "fast", "normal", or "slow"
	oninit:function(expandedindices){ //custom code to run when headers have initalized
		//do nothing
	},
	onopenclose:function(header, index, state, isuseractivated){ //custom code to run whenever a header is opened or closed
		//do nothing
	}
})
</script><style type="text/css">
.ln-text{display: none}
a.hiddenajaxlink{display: none}
</style>

<!-- start validate script -->
<script type="text/javascript">
	$.metadata.setType("attr", "validate");
	ewa_validation.addAdditionalMethods();
	
	var redirectURL;
 
	function validateForm() {
	        // validation
	        var res = $('#referralForm').validate().form();
	        return res;
	}
</script>
<!-- end validate script -->

<!-- Chase.com Reporting Script -->
<script type="text/javascript" src="./Complimentary Terminal_files/Reporting.js"></script>

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-455854-1', 'auto');
  ga('send', 'pageview');

</script>
<meta name="ROBOTS" content="NOINDEX, NOFOLLOW">
<style type="text/css">
.recaptchatable {
	line-height: 0;
	width: 100% !important;
	border:0 !important;
}
#recaptcha_table {
	width: 200px !important;
	border: 0 !important;
	border-width: 0 !important;
}
.recaptchatable .recaptcha_imagecell {
	padding-left: 0px;
}
span#recaptcha_privacy.recaptcha_only_if_privacy a {
	color:#CCC;
}
.captchaWrap {
	padding:0 0 0 0;
	margin: 20px 0 0 6px;
	background-color: #FFF;
}
#registrationForm .captchaWrap p {
	margin: 0 0 20px 16px;
}
#registrationForm .captchaWrap h3 {
	margin:40px 0 0 16px;
	font-size: 16px;
	font-weight: bold;
	color:#6f6f6f;
}
#registrationForm h1 {
	color: #FFF;
	font-size: 43px;
	font-family: Amplitude-Regular;
	font-weight:normal;
	line-height: 42px;
	margin: 20px;
	letter-spacing:-1px;
	padding-top:12px;
}
#registrationForm h2 {
	color: #fff;
	font-size: 17px;
	line-height: 22px;
	margin:20px;
	font-family: Amplitude-Regular;
	font-weight:normal;
}
#registrationForm h3 {
	color: #6f6f6f;
	font-size: 26px;
	margin: 8px 0 0 28px;
	font-family: Amplitude-Regular;
	font-weight:normal;
}
#registrationForm h4 {
	color: #6f6f6f;
	font-family: Amplitude-Regular;
	font-weight:normal;
	font-size: 24px;
	line-height: 22px;
	margin: 30px 50px 0px 20px;
}
#leadForm {
	position:absolute;
	top:430px;
	width: 420px;
}
#leadForm div.formFields label.error {
	position:absolute;
	top:0px;
	right:0px;
	font-size:12px;
	}

#leadForm li#afr {
	font-family:Arial, Helvetica, sans-serif;
	font-size:11px;
	font-style:italic;
	text-align:right;
	margin:0px;
	height:25px;
}
#leadForm div.formFields ul li	{
	display:block;
	width:100%;
	height:67px;
	position:relative;	
	}
#leadForm div.formFields ul	{
	margin-left:24px;
	}
.formFields {
	margin: 0 0 0 10px;
}
.formFields .inputfield,
.formFields select {
	padding:6px 10px;
	clear:both;
}
.formFields .inputfield {
	width:377px;
}
.formFields select.inputfield {
	width:397px;
}
#leadformText h2 a.phone	{
	text-decoration:none !important;
	color:#fff !important;
	font-size:20px !important;
	}
#registrationForm .disclaimer {
    font-size: 12px;
	line-height:14px;
}
</style>


<script type="text/javascript">
function getURLParam(strParamName){
var strReturn = "";
var strHref = window.location.href;

	if ( strHref.indexOf("?") > -1 ){
		var strQueryString = strHref.substr(strHref.indexOf("?")).toLowerCase();
		var aQueryString = strQueryString.split("&");
		for ( var iParam = 0; iParam < aQueryString.length; iParam++ ){
			if (
				aQueryString[iParam].indexOf(strParamName.toLowerCase() + "=") > -1 ){
					var aParam = aQueryString[iParam].split("=");
					strReturn = aParam[1];
					break;
				}
		}
	}
return unescape(strReturn);

}
</script>

<script>
	document.getElementById("sf.00N00000006yj4I").value=getURLParam('ref'); 
</script>



<!-- Top Parameter Passing Script 3.0 -->
<script type="text/javascript">
jQuery(document).ready(function(){
                var urlParams = window.location.search.substring(1).split('&');
                var pNames;
                var haveParams = false;
                for (var parIndex=0;parIndex<urlParams.length;parIndex++){
       pNames = urlParams[parIndex].split('=');
       if (pNames[0] == 'referralParty'){
         document.getElementById("sf.00N00000008iRz1").value = pNames[1];
         haveParams = true;
       }else if( pNames [0] == 'f9tc'){
         document.getElementById("sf.00N00000008ipHV").value = pNames[1];
         haveParams = true;
       }else if( pNames [0] == 'ef_id'){
         document.getElementById("sf.00N00000008paPw").value = pNames[1];
         haveParams = true;
       }else if( pNames [0] == 'mkwid'){
         document.getElementById("sf.00N00000008q1AF").value = pNames[1];
         haveParams = true;
       }
                }
  
    if (!haveParams){
       var cookies = document.cookie.split(';');
       var cNames;
       var cName;
       for(var cIndex=0;cIndex<cookies.length;cIndex++){
         cNames = cookies[cIndex].split('=');
         cName = cNames[0].replace(' ', '');
         if (cName == 'referralParty'){
            document.getElementById("sf.00N00000008iRz1").value = cNames[1];
         }else if (cName == 'f9tc'){ 
             document.getElementById("sf.00N00000008ipHV").value = cNames[1];
         }else if (cName == 'ef_id'){ 
             document.getElementById("sf.00N00000008paPw").value = cNames[1];
         }else if (cName == 'mkwid'){ 
             document.getElementById("sf.00N00000008q1AF").value = cNames[1];
         }
       }
    }
  });

</script>
<!-- END : Top Parameter Passing Script 3.0 -->

<link rel="stylesheet" type="text/css" href="./Complimentary Terminal_files/jpm_overwrite.css" media="screen">

<div class="container contianer-page">
	<!-- <div class="header">
		<div class="logo"><img src="./Complimentary Terminal_files/chaseLogo.png" alt="Chase" width="160" height="31"> <span class="jpmLogo"><img src="./Complimentary Terminal_files/jpmLogo.png" alt="J.P. Morgan"></span></div>
		<div class="global">
			<div class="toprow"> 
				Start Country Menu 
				<script type="text/javascript">
			function navigateTo(url) {
				document.location.href = url;
			}
			
			$(document).ready(function(e) {
				try {
					$("#country").msDropDown();
				} catch(e) {
					alert(e.message);
				}
			});
			</script>
				<div class="countryDropdown">
					<div class="ddOutOfVision" style="height:0px;overflow:hidden;position:absolute;" id="country_msddHolder"><select name="countrymenu" id="country" onchange="navigateTo(this.value)" style="display: none; width: 170px;">
						<option value="http://www.chasepaymentech.com?WT.mc_id=usflag_us" selected="selected" title="/images/icon_united_states.gif">UNITED STATES</option>
						<option value="http://en.chasepaymentech.ca?WT.mc_id=caflag_us" title="/images/icon_canada_english.gif">CANADA: ENGLISH</option>
						<option value="http://fr.chasepaymentech.ca?WT.mc_id=frflag_us" title="/images/icon_canada_french.gif">CANADA: FRENCH</option>
						<option value="http://europe.chasepaymentech.com?WT.mc_id=ukflag_us" title="/images/icon_europe.gif">EUROPE</option>
						<option value="http://www.chasepaymentech.de/?WT.mc_id=deflag_us" title="/images/icon_germany.gif">GERMANY</option>
					</select></div><div id="country_msdd" class="dd" style="display:none;width:170px;"><div id="country_title" class="ddTitle"><span id="country_arrow" class="arrow"></span><span class="ddTitleText" id="country_titletext"><img src="./Complimentary Terminal_files/icon_united_states.gif" align="absmiddle"> <span class="ddTitleText">UNITED STATES</span></span></div><div id="country_child" class="ddChild" style="display: none; width: 168px;"><a href="javascript:void(0);" class="selected enabled" id="country_msa_0"><img src="./Complimentary Terminal_files/icon_united_states.gif" align="absmiddle"> <span class="ddTitleText">UNITED STATES</span></a><a href="javascript:void(0);" class="enabled" id="country_msa_1"><img src="./Complimentary Terminal_files/icon_canada_english.gif" align="absmiddle"> <span class="ddTitleText">CANADA: ENGLISH</span></a><a href="javascript:void(0);" class="enabled" id="country_msa_2"><img src="./Complimentary Terminal_files/icon_canada_french.gif" align="absmiddle"> <span class="ddTitleText">CANADA: FRENCH</span></a><a href="javascript:void(0);" class="enabled" id="country_msa_3"><img src="./Complimentary Terminal_files/icon_europe.gif" align="absmiddle"> <span class="ddTitleText">EUROPE</span></a><a href="javascript:void(0);" class="enabled" id="country_msa_4"><img src="./Complimentary Terminal_files/icon_germany.gif" align="absmiddle"> <span class="ddTitleText">GERMANY</span></a></div></div>
				</div>
				End Country Menu
				
				<div class="contact_open"><span id="wt_hcu" class="cu"><a href="https://commercesolutions.jpmorganchase.com/contact_us_overview.html">CONTACT US</a></span> <span id="wt_hoa" class="ap"><a href="http://www.chasepaymentech.com/forms/business-information.html" id="hoa">APPLY</a></span> </div>
				<div class="merchantlogin"><a href="https://commercesolutions.jpmorganchase.com/merchant_log_in.html" onclick="dcsMultiTrack(&#39;DCS.dcssip&#39;, &#39;www.chasepaymentech.com&#39;, &#39;WT.z_page_section&#39;, &#39;Header&#39;, &#39;WT.z_link_name&#39;, &#39;Merchant Login&#39;, &#39;WT.z_nav_section&#39;, &#39;Merchant Login&#39;);">LOGIN <img src="./Complimentary Terminal_files/link-int.gif" align="baseline"></a></div>
			</div>
			<div class="clearfloat"></div>
			<div class="commerceSolutions">Merchant Services</div>
		</div>
		<div class="clearfloat"></div>
		
		Start Megamenu
		<div id="supernav" class="nav">
			<ul class="megamenu" style="display: block;">
				<div id="megamenu-include"> -->


<style type="text/css">
ul.megamenu div.mm-item-content {
	padding:0px 20px;
}
.navbase {
	margin:0px;
	background-color:#6d6e71;
}
.navbase .inner {
	background-color:#6d6e71;
	margin:15px;
	overflow:hidden;
}
.navbase .inner .innerSection {
	float:left;
	padding-bottom:12px;
}
.navbase .inner .innerSection .subtitle {
	margin-top:12px;
}
.megamenu #productsServices {
	width:709px;
}
.navbase .inner #ps1 {
	width:228px;
}
.navbase .inner #ps2 {
	width:225px;
}
.navbase .inner #ps3 {
	width:210px;
}
.megamenu #merchantSupport {
	width:731px;
}
#learningResources .title {
	color:#e6e6e6;
	font-size:12px;
	font-family:Amplitude-Regular;
	padding:0;
	text-transform:uppercase;
	line-height:30px;
}
#learningResources .link {
	padding:5px 0 5px 0;
}
#learningResources .link a {
	line-height:18px;
	font-family: Amplitude-Regular;
	color: #fff;
	font-size:16px;
	display:block;
	padding:0;
}
#learningResources .title a {
	padding:0;
	line-height:30px;
	font-family: Amplitude-Regular;
	color: #fff;
	font-size:16px;
}
#productsServices .title {
	color:#e6e6e6;
	font-size:12px;
	font-family:Amplitude-Regular;
	padding:0;
	text-transform:uppercase;
	line-height:30px;
}
#productsServices .link {
	padding:5px 0 5px 0;
}

#productsServices .link a {
	line-height:18px;
	font-family: Amplitude-Regular;
	color: #fff;
	font-size:16px;
	display:block;
	padding:0;
}
#productsServices .title a {
	padding:0;
	line-height:30px;
	font-family: Amplitude-Regular;
	color: #fff;
	font-size:16px;
}
#merchantSupport .title {
	color:#e6e6e6;
	font-size:12px;
	font-family:Amplitude-Regular;
	padding:0;
	text-transform:uppercase;
	line-height:30px;
}
#merchantSupport .link {
	padding:5px 0 5px 0;
}
#merchantSupport .link a {
	line-height:18px;
	font-family: Amplitude-Regular;
	color: #fff;
	font-size:16px;
	display:block;
	padding:0;
}
#merchantSupport .title a {
	padding:0;
	line-height:30px;
	font-family: Amplitude-Regular;
	color: #fff;
	font-size:16px;
}
.navbase .inner #ms1 {
	width:225px;
}
.navbase .inner #ms2 {
	width:225px;
}
.navbase .inner #ms3 {
	width:214px;
	padding-left:10px;
}

.navbase .inner #lr1 {
	width:245px;
}
.navbase .inner #lr2 {
	width:275px;
}
.navbase .inner #lr3 {
	width:275px;

}
</style>

<!-- <div id="supernav" class="nav">
	<ul class="megamenu" style="display: block;">
		<li id="homeLink" class="mm-item" style="float: left;"><a href="https://commercesolutions.jpmorganchase.com/index.html" onclick="dcsMultiTrack(&#39;DCS.dcssip&#39;, &#39;www.chasepaymentech.com&#39;, &#39;WT.z_page_section&#39;, &#39;Super Nav&#39;, &#39;WT.z_link_name&#39;, &#39;Home Icon&#39;, &#39;WT.z_nav_section&#39;, &#39;Super Nav&#39;);" class="mm-item-link">&nbsp;<img src="./Complimentary Terminal_files/topnav_home_off.png" border="0" alt="Home Icon">&nbsp;</a></li>
		<li id="wt_ngs" class="mm-item" style="float: left;"> <a href="https://commercesolutions.jpmorganchase.com/apply/index.html?WT.mc_id=supernav_apply&amp;referralParty=SuperNavApply" class="mm-item-link">Apply</a></li>
		<li id="wt_nps" class="mm-item" style="float: left;"> <a href="https://commercesolutions.jpmorganchase.com/payment_processing_services_and_products.html" class="mm-item-link">Solutions</a>
			<div id="productsServices" class="navbase mm-item-content" style="display: none; top: 138px; left: 183px; height: auto;"><div class="mm-content-base">
				<div class="inner">
					<div id="ps1" class="innerSection">
						<div class="title">Point-of-Sale Payments</div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/credit_card_machines.html">Credit Card Machines</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/products/pos-systems.html">POS Systems</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/ingenico_ict250.html">Ingenico iCT250, iWL 250</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/verifone_vx520.html">Verifone VX520</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/verifone_vx680.html">Verifone VX680 Wireless</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/onlineposterminalsolutions/index.html">Online POS Terminal</a></div>
						<div class="title subtitle">Online Payment Processing</div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/orbital/">Orbital</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/payment_gateway.html">Payment Gateway</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/virtual_terminal.html">Virtual Terminal</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/hosted_pay_page.html">Hosted Pay Page</a></div>
					</div>
					<div id="ps2" class="innerSection">
						<div class="title">Methods of Payment</div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/nfc_payments.html">NFC Payments</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/apple-pay.html">Apple Pay</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/recurring_payments.html">Recurring Payments</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/electronic_check_processing.html">Electronic Checks</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/debit_card_processing.html">Debit Card Processing</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/international_payments.html">International Payments</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/purchase_card.html">Purchase Card</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/paypal.html">PayPal</a></div>
						<div class="title subtitle">Mobile Payment Processing</div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/mobilecheckout/?WT.mc_id=supernav">Chase Mobile Checkout</a></div>
						<div class="link"><a href="https://secure.paymentech.com/developercenter/mobilesdk/ios/?WT.mc_id=cp002_sdk" target="_blank">Apple Pay SDK <img src="./Complimentary Terminal_files/link-external-sn.gif" align="baseline"></a></div>
					</div>
					<div id="ps3" class="innerSection">
						<div class="title">Fraud &amp; Security</div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/fraud_prevention_technology.html">Safetech Fraud Tools</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/safetech_encryption.html">Safetech Encryption</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/safetech_page_encryption.html">Safetech Page Encryption</a></div>
						<div class="title subtitle">Online Reporting</div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/resourceonline/">Resource Online</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/paymentechonline/">Paymentech Online</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/online_chargeback_management.html">Online Chargeback Management</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/mobiledashboard/?WT.mc_id=supernav">Mobile Dashboard</a></div>
					</div>
				</div>
			</div></div>
		</li>
		<li id="wt_nms" class="mm-item" style="float: left;"> <a href="https://commercesolutions.jpmorganchase.com/merchantcenter/" class="mm-item-link">Support</a>
			<div id="merchantSupport" class="navbase mm-item-content" style="display: none;"><div class="mm-content-base">
				<div class="inner">
					<div id="ms1" class="innerSection">
						<div class="title">New Customers</div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/welcome/">Activate Your Account</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/terminal_help_for_merchants.html">Credit Card Terminal Solutions</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/merchant_services_training.html">Get Trained</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/credit_card_logos.html">Credit Card Logos</a></div>
					</div>
					<div id="ms2" class="innerSection">
						<div class="title">Existing Customers</div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/help.html">Product Support</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/help.html#faq">Frequently Asked Questions</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/iservice/how_to_read_your_statement.html#tab2">How to Read Your Statement</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/statement_fees_defined.html">Statement Fees Defined</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/address_verification_service.html">AVS Response Codes</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/card_verification_codes.html">Card Verification Codes</a></div>
					</div>
					<div id="ms3" class="innerSection">
						<div class="title">Log In to Your Account</div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/merchant_log_in.html">Log In</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/statements_and_reports.html">Managing Your Account</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/chargebacks.html">Chargeback Management</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/statements_and_reports.html">Get Reports &amp; Statements</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/add_more_services.html">Add More Services</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/mobile_reporting.html">Mobile Reporting</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/supplies.html">Order Supplies</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/1099k/">IRS Reporting Requirements</a></div>
						<div class="link"><a href="https://secure.paymentech.com/developercenter/mobilesdk/ios/?WT.mc_id=cp002_sdk">Enable Apple Pay</a></div>
					</div>
				</div>
			</div></div>
		</li>
		<li id="wt_nlr" class="mm-item" style="float: left;"> <a href="https://commercesolutions.jpmorganchase.com/merchant_resources_and_help.html" class="mm-item-link">Resources</a>
			<div id="learningResources" class="navbase mm-item-content" style="display: none;"><div class="mm-content-base">
				<div class="inner">
					<div id="lr1" class="innerSection">
						<div class="title">Before You Start Processing</div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/why_choose_us.html">Why Choose Us</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/switch2us/">Switch to Us</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/accept_credit_card_payments.html">Payment Processing Benefits</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/the_basics.html">Basic Info for New Businesses</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/5_things_to_consider.html">Five Important Considerations</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/merchant_account_services.html">Merchant Account</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/credit_card_processing_fees.html">Credit Card Processing Fees</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/free_statement_review.html">Free Statement Review</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/personalized_programs.html">Personalized Quote</a></div>
					</div>
					<div id="lr2" class="innerSection">
						<div class="title">All About Payment Processing</div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/small_business_credit_card_processing.html">Small Business Credit Card Processing</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/mobile_wallet_technology.html">Mobile Wallet Technology</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/mobile_credit_card_processing.html">Mobile Credit Card Processing</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/emv_chip_technology.html">EMV Chip Technology</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/contactless_payments.html">Contactless Payments</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/interchange_and_assessment_understanding.html">Interchange</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/merchant_funding.html">Merchant Funding</a></div>
					</div>
					<div id="lr3" class="innerSection">
						<div class="title">Security &amp; Fraud Prevention</div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/protect_your_business.html">Protect Your Business</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/fraud_prevention.html">Prevent Fraud</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/datasecurity/">PCI Data Security</a></div>
						<div class="title subtitle">Perspectives</div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/perspectives.html">White Papers &amp; Customer Stories</a></div>
					</div>
				</div>
			</div></div>
		</li>
		<li id="wt_ps" class="mm-item" style="float: left;"><a href="https://commercesolutions.jpmorganchase.com/partnership.html?WT.mc_id=supernav_partnership" class="mm-item-link">Partnerships</a></li>
		<li id="wt_nau" class="mm-item" style="float: left;"><a href="https://commercesolutions.jpmorganchase.com/developercenter/index.html?WT.mc_id=supernav_devcenter" target="_blank" class="mm-item-link">Developer Center <img src="./Complimentary Terminal_files/link-ex-topnav.png" align="baseline"></a></li><li class="clear-fix" style="display:none;"></li>
	</ul>
</div>
</div>
			</ul>
		</div>
		End Megamenu 
		
	</div> -->
    <div class="validation-offerform">
  <form id="referralForm">
   <!-- method="post" -->
  <!-- action="https://www.chasepaymentech.com/referralFormService" id="referralForm" -->

	<!-- Type -->
<input id="form.type" name="form.type" type="hidden" value="SF">

<!-- Success URL-->
<input id="redirectOnSuccessUrl" name="redirectOnSuccessUrl" type="hidden" value="https://www.chasepaymentech.com/form_success.html">

<!-- Error URL -->
<input id="redirectOnErrorUrl" name="redirectOnErrorUrl" type="hidden" value="https://www.chasepaymentech.com/form_error.html">

<!-- Environment -->
<input id="identification.environment" name="identification.environment" type="hidden" value="Prod">
 
<!-- OID -->
<input id="sf.oid" name="sf.oid" type="hidden" value="00D00000000heJJ">

<!-- Campaign ID -->
<input id="sf.Campaign_ID" name="sf.Campaign_ID" type="hidden" value="701000000009feC">
 
<!-- Custom Campaign ID-->
<input id="sf.00N00000006yPWW" name="sf.00N00000006yPWW" type="hidden" value="Chase.com Marquee Advertisings"> 
 
<!-- Lead Source --> 
<input id="sf.lead_source" name="sf.lead_source" type="hidden" value="CPS.com Apply">
<!-- <input id="sf.lead_source" name="sf.lead_source" type="hidden" value="CPS Marketing"> -->

<!-- Originating Offer -->
<input id="sf.00N00000008iozv" name="sf.00N00000008iozv" type="hidden" value="Express Funding Ink">
<!-- Agent ID -->
<input id="sf.00N00000006yj3K" type="hidden" name="sf.00N00000006yj3K" value="424973082888">  
<!-- Agent Name -->
<input id="sf.00N00000006yj3F" type="hidden" name="sf.00N00000006yj3F" value="CPS.COM">
<!-- Referral Source ID -->
<input id="sf.00N00000006yj3j" type="hidden" name="sf.00N00000006yj3j" value="E423">
<!-- Referral Source -->
<input id="sf.00N00000006ohHG" type="hidden" name="sf.00N00000006ohHG" value="Terminal Offer Q1 2017">
<!-- Marketing Program ID -->
<input id="sf.00N00000006yj4I" type="hidden" name="sf.00N00000006yj4I" value="4932">
<!-- Marketing Program -->
<input id="sf.00N00000006pTAM" type="hidden" name="sf.00N00000006pTAM" value="Chase Free Retail Checkout">

				

          <!-- The 4 parameters for passing script 3.0  -->
          <input id="sf.00N00000008ipHV" type="hidden" name="sf.00N00000008ipHV" value="">
          <input id="sf.00N00000008iRz1" type="hidden" name="sf.00N00000008iRz1" value="">
          <input id="sf.00N00000008paPw" type="hidden" name="sf.00N00000008paPw" value="">
          <input id="sf.00N00000008q1AF" type="hidden" name="sf.00N00000008q1AF" value="">
  
    
    
    
		<div id="blankForm"> 

			

			<div class="copy" id="registrationForm">
				<table border="0" cellpadding="0" cellspacing="0" width="936" height="829">
					<tbody><tr> 
						<!-- begin column 1 -->
						<td width="460" valign="top"><img alt="EMV Chip Card" border="0" height="308" src="./Complimentary Terminal_files/emv_chip_card.jpg" width="470">
			
							<div id="titleWrapper" style="padding-bottom:50px">
				<div class="line"></div>
				<div class="textbox">
					<h1>ACCEPT MORE PAYMENTS</h1>
				</div>
			</div>
							<p>Chips on credit cards, mobile wallets loaded on smart phones – the way customers pay is changing and merchants need a terminal to accept these new transactions. </p>
							<div class="orangeList" style="margin:0 20px">
								<ul>
									<li class="indentlines"><strong>CHIP CARDS-</strong> Fight fraud with the security of chip-enabled cards.</li>
								
									<li class="indentlines"><strong>MOBILE WALLETS-</strong> Smart phones loaded with mobile wallets may be the new payment juggernaut.</li>
								
									<li class="indentlines"><strong>TAP -</strong> Accelerate transactions with contactless payments.</li>
									
									<li class="indentlines"><strong>SWIPE - </strong>Accept all the payments you normally do.</li>
								</ul>
							</div>
							
							</td>
						<!-- end column 1 --> 
						
						<!-- begin column 2 -->
						<td width="476" height="829" valign="top" background="./Complimentary Terminal_files/lead_form_base.gif"><div id="leadformText">
								<h1>Complimentary Chip Card Terminal<sup>*</sup></h1>
								<h2>Apply for your Chase merchant services account today and get a terminal.</h2>
								<h2>Call us at <a class="phone" href="https://commercesolutions.jpmorganchase.com/lp/8008600116">800.860.0116</a> or complete the short form below.</h2>
							</div>
							<div id="leadForm"> 
								<h3 class="start">Start Today!</h3>
								<!-- Begin Validation Error Messages -->
								<div class="formFields">
									<ul>
									<li id="afr"><em>All fields are required.</em></li>
									<li>Company Name:
										<label for="sf.company" class="error">Required</label>
										
										<input class="inputfield" id="sf.company" maxlength="40" name="sf.company" title="Company is required." type="text" validate="required:true">
									</li>
									<li> State:
										<label for="sf.state" class="error">Required</label>
										
										<select class="inputfield select-state" id="sf.state" name="sf.state" title="State is required" validate="required:true">
											<option value="" selected="selected">Choose</option>
											<option value="AL">Alabama</option>
											<option value="AK">Alaska</option>
											<option value="AZ">Arizona</option>
											<option value="AR">Arkansas</option>
											<option value="CA">California</option>
											<option value="CO">Colorado</option>
											<option value="CT">Connecticut</option>
											<option value="DE">Delaware</option>
											<option value="DC">District Of Columbia</option>
											<option value="FL">Florida</option>
											<option value="GA">Georgia</option>
											<option value="HI">Hawaii</option>
											<option value="ID">Idaho</option>
											<option value="IL">Illinois</option>
											<option value="IN">Indiana</option>
											<option value="IA">Iowa</option>
											<option value="KS">Kansas</option>
											<option value="KY">Kentucky</option>
											<option value="LA">Louisiana</option>
											<option value="ME">Maine</option>
											<option value="MD">Maryland</option>
											<option value="MA">Massachusetts</option>
											<option value="MI">Michigan</option>
											<option value="MN">Minnesota</option>
											<option value="MS">Mississippi</option>
											<option value="MO">Missouri</option>
											<option value="MT">Montana</option>
											<option value="NE">Nebraska</option>
											<option value="NV">Nevada</option>
											<option value="NH">New Hampshire</option>
											<option value="NJ">New Jersey</option>
											<option value="NM">New Mexico</option>
											<option value="NY">New York</option>
											<option value="NC">North Carolina</option>
											<option value="ND">North Dakota</option>
											<option value="OH">Ohio</option>
											<option value="OK">Oklahoma</option>
											<option value="OR">Oregon</option>
											<option value="PA">Pennsylvania</option>
											<option value="RI">Rhode Island</option>
											<option value="SC">South Carolina</option>
											<option value="SD">South Dakota</option>
											<option value="TN">Tennessee</option>
											<option value="TX">Texas</option>
											<option value="UT">Utah</option>
											<option value="VT">Vermont</option>
											<option value="VA">Virginia</option>
											<option value="WA">Washington</option>
											<option value="WV">West Virginia</option>
											<option value="WI">Wisconsin</option>
											<option value="WY">Wyoming</option>
										</select>
									</li>
									<li> First Name:
										<label for="sf.first_name" class="error">Required </label>
										
										<input class="inputfield" id="sf.first_name" maxlength="80" name="sf.first_name" title="First Name is required." type="text" validate="required:true">
									</li>
									<li>Last Name:
										<label for="sf.last_name" class="error">Required</label>
										
										<input class="inputfield" id="sf.last_name" maxlength="80" name="sf.last_name" title="Last Name is required." type="text" validate="required:true">
									</li>
									<li>Email Address:
										<label for="sf.email" class="error">A valid email address is required.</label>
										
										<input class="inputfield" id="sf.email" maxlength="80" name="sf.email" title="A valid email address is required" type="text" validate="required:true, email:true">
									</li>
									<li>Phone:
										<label for="sf.phone" class="error">A valid phone number is required.</label>
									
										<input class="inputfield" id="sf.phone" maxlength="40" name="sf.phone" title="A valid phone number is required." type="text" validate="required:true, phone:true">
									</li>
									</ul>
								</div>
								<div id="submit" style="margin:14px 0 0 24px;text-align:center;">
									<input type="button" alt="Get Started" id="btnSubmit" value="GET STARTED"
									onClick="return validateForm()">
								</div>
							</div></td>
						<!-- end column 2 --> 
					</tr>
				</tbody></table>
				<table width="936" border="0" cellspacing="0" cellpadding="0">
					<tbody><tr>
						<td><p class="disclaimer">Offer valid for new U.S. Chase Merchant Services customers only and expires 05/31/2017.  Receipt of complimentary equipment (Ingenico iCT250) contingent upon the execution and approval of a Merchant Application and Agreement with Chase. The Ingenico  iCT250 operates exclusively with Chase’s processing services. Early termination of the Merchant Application and Agreement may require the repayment of all or a prorated portion of the free equipment. Merchant services are provided by Paymentech, LLC (“Chase”), a subsidiary of JPMorgan Chase Bank, N.A.
</p></td>
					</tr>
				</tbody></table>
				<br>
			</div>
		</div>
	</form>
	<div class="offer-popup">
					   		<div class="offer-popup-close">x</div>
					    <p>Thank You</p>
			</div>
			<div class="offer-popup-inside">
			</div> 
	</div>
	</div>
	
	<!-- print_footer class is only for the printed page -->
	
	<div id="print_footer">
		<div id="print_footer_logo"><img src="./Complimentary Terminal_files/chase_paymentech_footer_logo.jpg" width="258" height="47" alt="chase paymentech logo"></div>
		<h3>Sales: 800.708.3740&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;Customer Service: 800.934.7717</h3>
	</div>
	
	<!-- main footer class -->
	<div id="footer-include"> 
<!-- <div id="footer">
#footerLS
<div id="footerLS">
	<div class="footerLogo"><span style="margin-right:40px"><img src="./Complimentary Terminal_files/chaseFooterLogo.png"></span><img src="./Complimentary Terminal_files/jpmFooterLogo.gif"></div>
	<a class="speedbump ext_link" href="https://commercesolutions.jpmorganchase.com/lp/compterm_cc.html#speedbump-modal" title="https://www.linkedin.com/company/chase-for-business" data-toggle="modal" data-target="#speedbump"><div id="linkedIn"></div></a> 
	<a class="speedbump ext_link" href="https://commercesolutions.jpmorganchase.com/lp/compterm_cc.html#speedbump-modal" title="https://www.youtube.com/user/WelcomeToChase" data-toggle="modal" data-target="#speedbump"><div id="youTube"></div></a>
</div>
#/footerLS
#footCopy
<div id="footCopy">	
	<div class="leftCopy">
		<p><a href="https://commercesolutions.jpmorganchase.com/contact_us_overview.html">Support</a></p>
		<p>Sales: <b>800.708.3740</b></p>
		<p>Client Support: <b>800.934.7717</b></p>
	</div>
	<div class="rightCopy">
		<p><a href="https://www.chase.com/" target="_blank">Chase <img src="./Complimentary Terminal_files/link-ex-nav.png" align="baseline"></a></p>
		<p><a href="https://www.jpmorgan.com/" target="_blank">J.P. Morgan <img src="./Complimentary Terminal_files/link-ex-nav.png" align="baseline"></a></p>
		<p><a href="http://www.jpmorganchase.com/" target="_blank">JPMorgan Chase &amp; Co. <img src="./Complimentary Terminal_files/link-ex-nav.png" align="baseline"></a></p>
	</div>

</div>
/#footCopy
#footBase
<div id="footBase">
	<p class="copyright">Copyright 2017, Merchant services are provided by Paymentech, LLC (“Chase”). <br>All Rights Reserved.</p>
	<ul id="fbNav">
		<li><a href="https://commercesolutions.jpmorganchase.com/system_requirements/" class="policy_terms">System Requirements</a></li>
		<li><a href="https://commercesolutions.jpmorganchase.com/termsofuse/" class="policy_terms">Terms of Use</a></li>
		<li><a href="https://commercesolutions.jpmorganchase.com/privacypolicy" class="policy_terms">Privacy Policy</a></li>
		<li><a href="https://commercesolutions.jpmorganchase.com/site_map.html">Site Map</a></li>
		<li><a href="https://commercesolutions.jpmorganchase.com/index.html">Home</a></li>
	</ul>
	/#footBase 
</div>
/#footer 



Linkedin Lead Accelerator 
<img height="1" width="1" alt="" style="display:none;" src="./Complimentary Terminal_files/saved_resource">



<link rel="stylesheet" href="./Complimentary Terminal_files/speedbump.css" type="text/css">
Speedbump Modal
<div style="display:none;">
	<div id="speedbump-modal">
		<h4>You're Now Leaving Chase Merchant Services</h4>		 
		<p>Chase's website terms, privacy and security policies don't apply to the site you're about to visit. Please review its website terms, privacy and security policies to see how they apply to you. Chase isn't responsible for (and does not provide) any products, services, or content at this third-party site, except for products and services that explicitly carry the Chase name.</p>
 
        <ul class="modal-buttons">
            <li><a type="button" class="btn btn-default" data-dismiss="modal">Cancel</a></li>
            <li><a id="url_link" href="https://commercesolutions.jpmorganchase.com/lp/compterm_cc.html" target="_blank" class="btn btn-primary">Proceed</a></li>
        </ul>

	</div>
</div>



</div></div>
</div> -->

<!-- start header include script --> 
<script type="text/javascript">
$(document).ready(function(){
    $( "#megamenu-include" ).load( "../includes/supernav2.html", function() {
//alert( "MM Load was performed." );
});
		}); 
</script> 
<!-- end header include script --> 

<!-- start footer include script --> 
<script type="text/javascript">
$(document).ready(function(){
 	$( "#footer-include" ).load( "../includes/global-footer2.html", function() {
			});
		}); 
</script> 
<!-- end footer include script --> 

<!-- start head tag include script --> 
<script type="text/javascript">
$(document).ready(function(){
 	$( "#head-tag-include" ).load( "../includes/head-tag.html", function() {
			});
		}); 
</script> 
<!-- end head tag include script --> 

<!-- Bottom Parameter Passing Script 3.0 --> 
<script type="text/javascript"> 
  var params = window.location.search.substring(1).split('&');
  var date = new Date();
  var expiry = new Date(date.getTime() + 86400000);
  var names;
  for(var pIndex=0; pIndex<params.length;pIndex++){
         names = params[pIndex].split("=");
         if (names[0] == 'referralParty' || names[0] == 'f9tc' || names[0] == 'ef_id' || names[0] == 'mkwid'){  //add param name here.
           document.cookie = names[0]+'='+names[1]+';expires='+expiry.toGMTString()+';path=/;';
         }  
  }
</script> 

<!-- Google Code for Remarketing List 1 Remarketing List --> 
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 1066358774;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script> 
<script type="text/javascript" src="./Complimentary Terminal_files/conversion.js">
</script><!-- <iframe name="google_conversion_frame" title="Google conversion frame" width="300" height="13" src="./Complimentary Terminal_files/saved_resource.html" frameborder="0" marginwidth="0" marginheight="0" vspace="0" hspace="0" allowtransparency="true" scrolling="no"></iframe> -->
<noscript>
&lt;div style="display:inline;"&gt; &lt;img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/1066358774/?value=0&amp;amp;guid=ON&amp;amp;script=0"/&gt; &lt;/div&gt;
</noscript>


<div id="fancybox-tmp"></div><div id="fancybox-loading"><div></div></div><div id="fancybox-overlay"></div><div id="fancybox-wrap"><div id="fancybox-outer"><div class="fancybox-bg" id="fancybox-bg-n"></div><div class="fancybox-bg" id="fancybox-bg-ne"></div><div class="fancybox-bg" id="fancybox-bg-e"></div><div class="fancybox-bg" id="fancybox-bg-se"></div><div class="fancybox-bg" id="fancybox-bg-s"></div><div class="fancybox-bg" id="fancybox-bg-sw"></div><div class="fancybox-bg" id="fancybox-bg-w"></div><div class="fancybox-bg" id="fancybox-bg-nw"></div><div id="fancybox-content"></div><a id="fancybox-close"></a><div id="fancybox-title"></div><a href="javascript:;" id="fancybox-left"><span class="fancy-ico" id="fancybox-left-ico"></span></a><a href="javascript:;" id="fancybox-right"><span class="fancy-ico" id="fancybox-right-ico"></span></a></div></div><div id="WVRANDOMID9551691489551602690516249" style="POSITION:absolute; VISIBILITY:hidden; Z-INDEX:10; LEFT:0px; TOP:0px;"><a taborder="1" href="https://commercesolutions.jpmorganchase.com/lp/compterm_cc.html#Click to speak to a representative." title="Click to speak to a representative." alt="Click to speak to a representative." onmouseover="javascript:window.status=&#39;Click to speak to a representative.&#39;; return true;" style="cursor:pointer" onclick="webVoicePop(&#39;Template=955169&#39;, &#39;urid=306959&#39;); return false;"><img name="Click to speak to a representative." alt="Click to speak to a representative." href="#Click to speak to a representative." id="WVRANDOMID49551691489551602690213986" class="estaradefaultstyle5" style="MARGIN:0px; PADDING:0px; BORDER:0px; DISPLAY:block;" src="./Complimentary Terminal_files/cnp_award_banner.jpg" border="0" onmouseover="javascript:window.status=&#39;Click to speak to a representative.&#39;; return true;"></a></div></body></html>