<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<!-- saved from url=(0052)https://commercesolutions.jpmorganchase.com/certify/ -->
<html lang="en" style="display: block;"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">

<title>Certify and grow your business | Chase Merchant Services</title>

<meta http-equiv="Keywords" name="Keywords" content="">
<meta http-equiv="Description" name="Description" content="">

<link rel="shortcut icon" href="https://www.chasepaymentech.com/favicon.ico">
<link rel="icon" type="image/png" href="http://www.chasepaymentech.com/favicon.png">
<link rel="canonical" href="https://commercesolutions.jpmorganchase.com/certify/">
<link href="./page-three_files/usen_43.css" lang="en" media="screen" rel="stylesheet" rev="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="./page-three_files/dd.css">
<link href="./page-three_files/jquery_megamenu.css" media="screen" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="./page-three_files/print.css" type="text/css" media="print">
<link rel="stylesheet" href="./page-three_files/jquery_ui_173_custom.css" type="text/css">
<link rel="stylesheet" type="text/css" href="./page-three_files/fancybox.css" media="screen">
<!--[if lt IE 7]> <link href="/styles/ie6.css" rel="stylesheet" type="text/css"> <![endif]-->



<script async="" src="https://commercesolutions.jpmorganchase.com/scripts/analytics.js"></script>
<script src="https://commercesolutions.jpmorganchase.com/scripts/jquery_1_3_2_min.js" type="text/javascript"></script>
<script src="https://commercesolutions.jpmorganchase.com/scripts/jquery_dd.js" type="text/javascript"></script>
<script src="https://commercesolutions.jpmorganchase.com/scripts/jquery_megamenu.js" type="text/javascript"></script>
<script src="https://commercesolutions.jpmorganchase.com/scripts/jquery_ui_1_7_3_custom_min.js" type="text/javascript"></script>
<script src="https://commercesolutions.jpmorganchase.com/scripts/jquery_cycle_lite_1_0.js" type="text/javascript"></script>
<script src="https://commercesolutions.jpmorganchase.com/scripts/jquery_fancybox_1_3_4_pack.js" type="text/javascript"></script>
<script type="text/javascript" src="https://commercesolutions.jpmorganchase.com/scripts/jquery_hoverintent_minified.js"></script>
<script type="text/javascript" src="https://commercesolutions.jpmorganchase.com/scripts/chasepaymentech.js"></script>
<script language="javascript" src="https://commercesolutions.jpmorganchase.com/scripts/jquery_metadata_2_1.js" type="text/javascript"></script>
<script language="javascript" src="https://commercesolutions.jpmorganchase.com/scripts/jquery_validate_1_5_5_min.js" type="text/javascript"></script>
<script language="javascript" src="https://commercesolutions.jpmorganchase.com/scripts/cmxforms.js" type="text/javascript"></script>
<script language="javascript" src="https://commercesolutions.jpmorganchase.com/scripts/ewa_validation.js" type="text/javascript"></script>
<script src="../../assets/scripts/form-redirect.js"></script>
<!-- start validate script -->
<script type="text/javascript">
	$.metadata.setType("attr", "validate");
	ewa_validation.addAdditionalMethods();
	
	var redirectURL;
 
	function validateForm() {
	        // validation
	        var res = $('#referralForm').validate().form();
	        return res;
	}
</script>
<!-- end validate script -->

<script type="text/javascript">
		$(document).ready(function() {

			$("#terms").fancybox({
				'width'		: '70%',
				'height'		: '70%',
				'autoScale'	: true,
				'transitionIn'	: 'none',
				'transitionOut'	: 'none',
				'type'		: 'iframe'
			});
			
			$("#privacy").fancybox({
				'width'		: '75%',
				'height'		: '75%',
				'autoScale'	: true,
				'transitionIn'	: 'none',
				'transitionOut'	: 'none',
				'type'		: 'iframe'
			});

		});
</script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-455854-1', 'auto');
  ga('send', 'pageview');

</script>


<style type="text/css">

.area-wrap ul.form-section	{
	display:block;
	width:430px;
	float:left;
	margin-top:-15px;
	}
.area-wrap ul.form-section.full-width	{
	display:block;
	width:100%;
	}
.area-wrap ul.left	{
	margin-right:26px;
}
.area-wrap ul.form-section li	{
	margin:12px 0px;
	}

span.unlabel	{
	display:block;
	width:100%;
	}
span.unlabel em	{
	font-size:75%;
	font-style:italic;
	color:#321c0f;
	}
	
.area-wrap ul.form-section li .inputadjust	{
width:100%;
padding:4px 6px;
font:Helvetica, Arial, sans-serif;
color:#ddd;
box-sizing:border-box;
-webkit-border-radius: 3px;
-moz-border-radius: 3px;
border-radius: 3px;
}
textarea.height-adjust	{
	height:135px;
	}
.area-wrap ul.full-width li.checkbox-grid label	{
	float:left;
	display:block;
	width:170px;
	margin:5px 52px 0px 0px;
}
.area-wrap ul.full-width li.checkbox-grid	{
	display:block;
	margin-bottom:15px;
	overflow:hidden;
}

.multi-wrapper	{
	width:600px;
	float:left;
	margin:20px 20px 0px 0px;
	}
.multi-wrapper select	{
	width:600px;
	height:184px;
	border:1px solid #888888;
	}

ul.boxes-list li	{
	width:300px;
	float:left;
	display:block;
	}
ul.boxes-list	{
	width:600px;
	float:left;
	margin:0px 20px 0px 10px;
	}
ul.boxes-textbox	{
	width:260px;
	float:left;
	display:block;
	}
ul.boxes-textbox li	{
	width:260px;
	float:left;
	display:block;
	margin-bottom:15px;
	}
ul.boxes-textbox li textarea	{
	width:260px;
	height:217px;
	display:block;
	}

label {
	font-weight: normal;
	color:#6f6f6f;
}
input {
	color:#6f6f6f;
}
textarea {
	color:#6f6f6f;
}
select {
	color:#6f6f6f;
}
/* end elements */

/* start accordion styles */
.form-content {
	color: #888;
	line-height:18px;
	margin:0;
	padding:0 0 0 5px;
	border:0;
}


/* begin global-specific classes */
#introduction {
	padding:20px 20px 10px 20px;
	text-align:left;
	width:875px;
	margin:auto;
	margin-left:25px;
}
.formcontainer {
	border:1px solid #d7d7d7;
	padding:0 20px 20px 20px;
	margin:auto;
}
.tableborders {
	border:1px solid #d7d7d7;
	padding:6px;
}
#certifyformcontainer {
	margin-left:25px;
	position:relative;
}
#certifyformcontainer .inputfield {
	border: 1px solid #888888;
	font-size: 13px;
	line-height: 23px;
	margin-bottom: 5px;
	color:#6f6f6f;
}
.content, .contenta {
	color:#6f6f6f;
	width:875px;
	margin-left:0px;
	margin-top:-20px;
}


.headingtwo {
	background:#b7dcf7;
	padding:10px;
	color:#6f6f6f;
	font-size:16px;
	font-weight:bold;
	font-family: Amplitude-Regular;
}
.headingtwo h4 {
	width:876px;
	padding-right:0;
}
.headingtwo:hover {
	background:#b7dcf7;
	background-image: url(/images/btn_arrow_2.gif);
	background-repeat:no-repeat;
	background-position:right;
}
.formMargin ul {
	margin-bottom: 10px;
	margin-top: 10px;
}
.formMargin li {
	margin-bottom: -2px;
}
#errorsDiv label {
	width: 468px;
}
label.error {
	display: none;
}
table.tableborders tr td i {
	color:#1778be;
}
.header .logo img {
	top:26px!important;
}
ul.megamenu li#wt_ps{
	background-color:#572c21!important;	
}
form ul	{
	margin:0px;
	padding:0px;
	}
form ul	li {
	list-style-type:none;
	margin:0px;
	padding:0px;
	}
	
.area-wrap {
    color: #6f6f6f;
    font-family: Amplitude-Regular;
    font-size: 16px;
    line-height: 18px;
    border: 1px solid #6f6f6f;
    margin-bottom: 20px;
    padding: 18px;
    overflow: hidden;
}	

.area-wrap h3.legend-head {

    color: #6f6f6f;
    font: 26px bold;
    margin: 0 0 5px;
    font-family: Amplitude-Regular;

}	
a#DOM {
	text-decoration:underline;
	}
#certifyformcontainer .area-wrap p.sm	{
	margin:0px;
	padding:0px;
	size:14px !important;
	}		
</style>


<!-- Frame Busting for Clickjacking -->
<style>
html {
	display:none;
}
</style>
<script> if (self == top) { document.documentElement.style.display = 'block'; } else { top.location = self.location; } </script>

<!-- start head include -->
<script type="text/javascript" src="./page-three_files/lr.php" charset="UTF-8"></script></head><body><div id="head-tag-include"></div>
<!-- /head include -->


<link rel="stylesheet" type="text/css" href="./page-three_files/jpm_overwrite.css" media="screen">



<div class="container contianer-page"> 
	
	<!-- <div class="header"> 
	<div class="logo"><img src="./page-three_files/chaseLogo.png" alt="Chase" width="160" height="31"> <span class="jpmLogo"><img src="./page-three_files/jpmLogo.png" alt="J.P. Morgan"></span></div>
		<div class="global">
			<div class="toprow"> 
				Start Country Menu 
				<script type="text/javascript">
			function navigateTo(url) {
				document.location.href = url;
			}
			
			$(document).ready(function(e) {
				try {
					$("#country").msDropDown();
				} catch(e) {
					alert(e.message);
				}
	
	
			});
			</script>
				<div class="countryDropdown">
					<div class="ddOutOfVision" style="height:0px;overflow:hidden;position:absolute;" id="country_msddHolder"><select name="countrymenu" id="country" onchange="navigateTo(this.value)" style="display: none; width: 170px;">
						<option value="http://www.chasepaymentech.com?WT.mc_id=usflag_us" selected="selected" title="../images/icon_united_states.gif">UNITED STATES</option>
						<option value="http://en.chasepaymentech.ca?WT.mc_id=caflag_us" title="../images/icon_canada_english.gif">CANADA: ENGLISH</option>
						<option value="http://fr.chasepaymentech.ca?WT.mc_id=frflag_us" title="../images/icon_canada_french.gif">CANADA: FRENCH</option>
						<option value="http://europe.chasepaymentech.com?WT.mc_id=ukflag_us" title="../images/icon_europe.gif">EUROPE</option>
						<option value="http://www.chasepaymentech.de/?WT.mc_id=deflag_us" title="../images/icon_germany.gif">GERMANY</option>
					</select></div><div id="country_msdd" class="dd" style="display:none;width:170px;"><div id="country_title" class="ddTitle"><span id="country_arrow" class="arrow" style="background-position: 0px 0px;"></span><span class="ddTitleText" id="country_titletext"><img src="./page-three_files/icon_united_states.gif" align="absmiddle"> <span class="ddTitleText">UNITED STATES</span></span></div><div id="country_child" class="ddChild" style="display: none; width: 168px;"><a href="javascript:void(0);" class="selected enabled" id="country_msa_0"><img src="./page-three_files/icon_united_states.gif" align="absmiddle"> <span class="ddTitleText">UNITED STATES</span></a><a href="javascript:void(0);" class="enabled" id="country_msa_1"><img src="./page-three_files/icon_canada_english.gif" align="absmiddle"> <span class="ddTitleText">CANADA: ENGLISH</span></a><a href="javascript:void(0);" class="enabled" id="country_msa_2"><img src="./page-three_files/icon_canada_french.gif" align="absmiddle"> <span class="ddTitleText">CANADA: FRENCH</span></a><a href="javascript:void(0);" class="enabled" id="country_msa_3"><img src="./page-three_files/icon_europe.gif" align="absmiddle"> <span class="ddTitleText">EUROPE</span></a><a href="javascript:void(0);" class="enabled" id="country_msa_4"><img src="./page-three_files/icon_germany.gif" align="absmiddle"> <span class="ddTitleText">GERMANY</span></a></div></div>
				</div>
				End Country Menu
				
				<div class="contact_open"><span id="wt_hcu" class="cu"><a href="https://commercesolutions.jpmorganchase.com/contact_us_overview.html">CONTACT US</a></span> <span id="wt_hoa" class="ap"><a href="https://commercesolutions.jpmorganchase.com/forms/business-information.html" id="hoa">APPLY</a></span> </div>
				<div class="merchantlogin"><a href="https://commercesolutions.jpmorganchase.com/merchant_log_in.html">LOGIN <img src="./page-three_files/link-int.gif" align="baseline"></a></div>
			</div>
			<div class="clearfloat"></div>
			<div class="commerceSolutions">Merchant Services</div>
		</div>
		<div class="clearfloat"></div>	
		
		Start Megamenu
	<div id="supernav" class="nav">
		<ul class="megamenu" style="display: block;">
			<div id="megamenu-include"> -->


<style type="text/css">
ul.megamenu div.mm-item-content {
	padding:0px 20px;
}
.navbase {
	margin:0px;
	background-color:#6d6e71;
}
.navbase .inner {
	background-color:#6d6e71;
	margin:15px;
	overflow:hidden;
}
.navbase .inner .innerSection {
	float:left;
	padding-bottom:12px;
}
.navbase .inner .innerSection .subtitle {
	margin-top:12px;
}
.megamenu #productsServices {
	width:709px;
}
.navbase .inner #ps1 {
	width:228px;
}
.navbase .inner #ps2 {
	width:225px;
}
.navbase .inner #ps3 {
	width:210px;
}
.megamenu #merchantSupport {
	width:731px;
}
#learningResources .title {
	color:#e6e6e6;
	font-size:12px;
	font-family:Amplitude-Regular;
	padding:0;
	text-transform:uppercase;
	line-height:30px;
}
#learningResources .link {
	padding:5px 0 5px 0;
}
#learningResources .link a {
	line-height:18px;
	font-family: Amplitude-Regular;
	color: #fff;
	font-size:16px;
	display:block;
	padding:0;
}
#learningResources .title a {
	padding:0;
	line-height:30px;
	font-family: Amplitude-Regular;
	color: #fff;
	font-size:16px;
}
#productsServices .title {
	color:#e6e6e6;
	font-size:12px;
	font-family:Amplitude-Regular;
	padding:0;
	text-transform:uppercase;
	line-height:30px;
}
#productsServices .link {
	padding:5px 0 5px 0;
}

#productsServices .link a {
	line-height:18px;
	font-family: Amplitude-Regular;
	color: #fff;
	font-size:16px;
	display:block;
	padding:0;
}
#productsServices .title a {
	padding:0;
	line-height:30px;
	font-family: Amplitude-Regular;
	color: #fff;
	font-size:16px;
}
#merchantSupport .title {
	color:#e6e6e6;
	font-size:12px;
	font-family:Amplitude-Regular;
	padding:0;
	text-transform:uppercase;
	line-height:30px;
}
#merchantSupport .link {
	padding:5px 0 5px 0;
}
#merchantSupport .link a {
	line-height:18px;
	font-family: Amplitude-Regular;
	color: #fff;
	font-size:16px;
	display:block;
	padding:0;
}
#merchantSupport .title a {
	padding:0;
	line-height:30px;
	font-family: Amplitude-Regular;
	color: #fff;
	font-size:16px;
}
.navbase .inner #ms1 {
	width:225px;
}
.navbase .inner #ms2 {
	width:225px;
}
.navbase .inner #ms3 {
	width:214px;
	padding-left:10px;
}

.navbase .inner #lr1 {
	width:245px;
}
.navbase .inner #lr2 {
	width:275px;
}
.navbase .inner #lr3 {
	width:275px;

}
</style>

<!-- <div id="supernav" class="nav">
		<ul class="megamenu" style="display: block;">
			<li id="homeLink" class="mm-item" style="float: left;"><a href="https://commercesolutions.jpmorganchase.com/index.html" onclick="dcsMultiTrack(&#39;DCS.dcssip&#39;, &#39;www.chasepaymentech.com&#39;, &#39;WT.z_page_section&#39;, &#39;Super Nav&#39;, &#39;WT.z_link_name&#39;, &#39;Home Icon&#39;, &#39;WT.z_nav_section&#39;, &#39;Super Nav&#39;);" class="mm-item-link">&nbsp;<img src="./page-three_files/topnav_home_off.png" border="0" alt="Home Icon">&nbsp;</a></li>
			<li id="wt_ngs" class="mm-item" style="float: left;"> <a href="https://commercesolutions.jpmorganchase.com/apply/index.html?WT.mc_id=supernav_apply&amp;referralParty=SuperNavApply" class="mm-item-link">Apply</a></li>
			<li id="wt_nps" class="mm-item" style="float: left;"> <a href="https://commercesolutions.jpmorganchase.com/payment_processing_services_and_products.html" class="mm-item-link">Solutions</a>
				<div id="productsServices" class="navbase mm-item-content" style="display: none;"><div class="mm-content-base">
					<div class="inner">
						<div id="ps1" class="innerSection">
							<div class="title">Point-of-Sale Payments</div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/credit_card_machines.html">Credit Card Machines</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/products/pos-systems.html">POS Systems</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/ingenico_ict250.html">Ingenico iCT250, iWL 250</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/verifone_vx520.html">Verifone VX520</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/verifone_vx680.html">Verifone VX680 Wireless</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/onlineposterminalsolutions/index.html">Online POS Terminal</a></div>
							<div class="title subtitle">Online Payment Processing</div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/orbital/">Orbital</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/payment_gateway.html">Payment Gateway</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/virtual_terminal.html">Virtual Terminal</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/hosted_pay_page.html">Hosted Pay Page</a></div>
						</div>
						<div id="ps2" class="innerSection">
							<div class="title">Methods of Payment</div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/nfc_payments.html">NFC Payments</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/apple-pay.html">Apple Pay</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/recurring_payments.html">Recurring Payments</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/electronic_check_processing.html">Electronic Checks</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/debit_card_processing.html">Debit Card Processing</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/international_payments.html">International Payments</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/purchase_card.html">Purchase Card</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/paypal.html">PayPal</a></div>
							<div class="title subtitle">Mobile Payment Processing</div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/mobilecheckout/?WT.mc_id=supernav">Chase Mobile Checkout</a></div>
							<div class="link"><a href="https://secure.paymentech.com/developercenter/mobilesdk/ios/?WT.mc_id=cp002_sdk" target="_blank">Apple Pay SDK <img src="./page-three_files/link-external-sn.gif" align="baseline"></a></div>
						</div>
						<div id="ps3" class="innerSection">
							<div class="title">Fraud &amp; Security</div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/fraud_prevention_technology.html">Safetech Fraud Tools</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/safetech_encryption.html">Safetech Encryption</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/safetech_page_encryption.html">Safetech Page Encryption</a></div>
							<div class="title subtitle">Online Reporting</div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/resourceonline/">Resource Online</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/paymentechonline/">Paymentech Online</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/online_chargeback_management.html">Online Chargeback Management</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/mobiledashboard/?WT.mc_id=supernav">Mobile Dashboard</a></div>
						</div>
					</div>
				</div></div>
			</li>
			<li id="wt_nms" class="mm-item" style="float: left;"> <a href="https://commercesolutions.jpmorganchase.com/merchantcenter/" class="mm-item-link">Support</a>
				<div id="merchantSupport" class="navbase mm-item-content" style="display: none;"><div class="mm-content-base">
					<div class="inner">
						<div id="ms1" class="innerSection">
							<div class="title">New Customers</div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/welcome/">Activate Your Account</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/terminal_help_for_merchants.html">Credit Card Terminal Solutions</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/merchant_services_training.html">Get Trained</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/credit_card_logos.html">Credit Card Logos</a></div>
						</div>
						<div id="ms2" class="innerSection">
							<div class="title">Existing Customers</div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/help.html">Product Support</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/help.html#faq">Frequently Asked Questions</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/iservice/how_to_read_your_statement.html#tab2">How to Read Your Statement</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/statement_fees_defined.html">Statement Fees Defined</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/address_verification_service.html">AVS Response Codes</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/card_verification_codes.html">Card Verification Codes</a></div>
						</div>
						<div id="ms3" class="innerSection">
							<div class="title">Log In to Your Account</div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/merchant_log_in.html">Log In</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/statements_and_reports.html">Managing Your Account</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/chargebacks.html">Chargeback Management</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/statements_and_reports.html">Get Reports &amp; Statements</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/add_more_services.html">Add More Services</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/mobile_reporting.html">Mobile Reporting</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/supplies.html">Order Supplies</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/1099k/">IRS Reporting Requirements</a></div>
							<div class="link"><a href="https://secure.paymentech.com/developercenter/mobilesdk/ios/?WT.mc_id=cp002_sdk">Enable Apple Pay</a></div>
						</div>
					</div>
				</div></div>
			</li>
			<li id="wt_nlr" class="mm-item" style="float: left;"> <a href="https://commercesolutions.jpmorganchase.com/merchant_resources_and_help.html" class="mm-item-link">Resources</a>
				<div id="learningResources" class="navbase mm-item-content" style="display: none; top: 138px; left: 536.5px; height: auto;"><div class="mm-content-base">
					<div class="inner">
						<div id="lr1" class="innerSection">
							<div class="title">Before You Start Processing</div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/why_choose_us.html">Why Choose Us</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/switch2us/">Switch to Us</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/accept_credit_card_payments.html">Payment Processing Benefits</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/the_basics.html">Basic Info for New Businesses</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/5_things_to_consider.html">Five Important Considerations</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/merchant_account_services.html">Merchant Account</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/credit_card_processing_fees.html">Credit Card Processing Fees</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/free_statement_review.html">Free Statement Review</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/personalized_programs.html">Personalized Quote</a></div>
						</div>
						<div id="lr2" class="innerSection">
							<div class="title">All About Payment Processing</div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/small_business_credit_card_processing.html">Small Business Credit Card Processing</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/mobile_wallet_technology.html">Mobile Wallet Technology</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/mobile_credit_card_processing.html">Mobile Credit Card Processing</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/emv_chip_technology.html">EMV Chip Technology</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/contactless_payments.html">Contactless Payments</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/interchange_and_assessment_understanding.html">Interchange</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/merchant_funding.html">Merchant Funding</a></div>
						</div>
						<div id="lr3" class="innerSection">
							<div class="title">Security &amp; Fraud Prevention</div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/protect_your_business.html">Protect Your Business</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/fraud_prevention.html">Prevent Fraud</a></div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/datasecurity/">PCI Data Security</a></div>
							<div class="title subtitle">Perspectives</div>
							<div class="link"><a href="https://commercesolutions.jpmorganchase.com/perspectives.html">White Papers &amp; Customer Stories</a></div>
						</div>
					</div>
				</div></div>
			</li>
			<li id="wt_ps" class="mm-item" style="float: left;"><a href="https://commercesolutions.jpmorganchase.com/partnership.html?WT.mc_id=supernav_partnership" class="mm-item-link">Partnerships</a></li>
			<li id="wt_nau" class="mm-item" style="float: left;"><a href="https://commercesolutions.jpmorganchase.com/developercenter/index.html?WT.mc_id=supernav_devcenter" target="_blank" class="mm-item-link">Developer Center <img src="./page-three_files/link-ex-topnav.png" align="baseline"></a></li><li class="clear-fix" style="display:none;"></li>
		</ul>
	</div>
	</div>
			</ul>
		</div>
		End Megamenu 
	</div> -->	

<script>
var d = (new Date()).toString().split(' ').splice(1,3).join(' ');

$(function () {
  $('.datepicker').val(d);
});

</script>
	<div class="validation-offerform">
	<form action="https://www.chasepaymentech.com/referralFormService" id="referralForm" onsubmit="return validateForm()" method="post">
		<div id="blankForm"> 
			<!-- Type -->
			<input id="form.type" name="form.type" type="hidden" value="SF">
			
			<!-- Success URL-->
			<input id="redirectOnSuccessUrl" name="redirectOnSuccessUrl" type="hidden" value="https://www.chasepaymentech.com/certify/certify_form_success.html">
			
			<!-- Error URL -->
			<input id="redirectOnErrorUrl" name="redirectOnErrorUrl" type="hidden" value="https://www.chasepaymentech.com/full_certify_form_error.html">
			
			<!-- Environment -->
			<input id="identification.environment" name="identification.environment" type="hidden" value="Prod">
			
			<!-- OID -->
			<input id="sf.oid" name="sf.oid" type="hidden" value="00D00000000heJJ">
						
			<!-- Campaign ID -->
			<input id="sf.Campaign_ID" name="sf.Campaign_ID" type="hidden" value="">
			
			<!-- Lead Source -->
			<input id="sf.lead_source" name="sf.lead_source" type="hidden" value="ISG Partner Profile">
			
			<!-- Custom Campaign ID-->
			<input id="sf.00N00000006yPWW" name="sf.00N00000006yPWW" type="hidden" value="">
			
			<!-- Daddy Analytics Token -->
<input type="hidden" id="Daddy_Analytics_Token" name="sf.00N00000008opUw">

			<!-- Daddy Analytics Web to Lead URL -->
<input type="hidden" id="Daddy_Analytics_WebForm_URL" name="sf.00N00000008opV2">

			<div class="copy">
				<div id="titleWrapper" style="padding-bottom:60px">
				<div class="line"></div>
				<div class="textbox">
					<h1>Certify and Grow Your Business</h1>
				</div>
			</div>
			<p class="overview" style="margin-left:154px">Integrate your software with us and discover how the power of the Chase Paymentech ecosystem can help you achieve your financial goals. Complete this form and one of our Research &amp; Discovery representatives will contact you within two business days for an evaluation.<br><br><em>All fields are required unless indicated</em>.</p>
			
			</div>
			
			<!-- overall table - contains all form elements -->
			<div id="certifyformcontainer">
				<div style="display:block; margin: 20px 0px 0px 0px;padding:0px;">
					<label for="sf.00N00000008p1YL" class="error clear">Date is Required<br></label>
					<label for="sf.company" class="error clear">Company Name is Required<br></label>
					<label for="sf.00N00000008irgb" class="error clear">DBA Name is Required<br></label>
					<label for="sf.00N37000006UHlg" class="error clear">Domiciled Country is Required<br></label>
					<label for="sf.phone" class="error clear">Phone Number is Required</label>
					<label for="sf.street" class="error clear">Company Address is Required<br></label>
					<label for="sf.city" class="error clear">City is Required<br></label>
					<label for="sf.state" class="error clear">State or Province is Required<br></label>
					<label for="sf.zip" class="error clear">Zip/Postal Code code is Required<br></label>
					<label for="sf.country" class="error clear">Country is Required</label>
				</div>
                
                
				<div class="area-wrap">
					<h3 class="legend-head">General Company Information</h3>
					<div class="form-content"> 
					<ul class="form-section left">
                    	<li>					
					<span class="unlabel">Date:
					<label for="sf.00N00000008p1YL" class="error right"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                    </span>
					<input class="inputfield inputadjust datepicker" id="sf.00N00000008p1YL" name="sf.00N00000008p1YL" size="35" title="Enter Today&#39;s Date" type="text" validate="required:true">
                        </li>
                        <li>        
					<span class="unlabel">Company Name:
					<label for="sf.company" class="error right"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                    </span>
					<input class="inputfield inputadjust" id="sf.company" name="sf.company" size="35" title="Enter Company name" type="text" validate="required:true">
                        </li>
                        <li>        
                    <span class="unlabel">DBA Name:
					<label for="sf.00N00000008irgb" class="error right"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                    </span>
					<input class="inputfield inputadjust" id="sf.00N00000008irgb" name="sf.00N00000008irgb" size="35" title="Enter DBA Name" type="text" validate="required:true">
                        </li>
                        <li>        
					<span class="unlabel">Where is the company <a name="what_is_domiciled" id="DOM">domiciled</a>?
					<label for="sf.00N37000006UHlg" class="error right"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                    </span>
					<input class="inputfield inputadjust" id="sf.00N37000006UHlg" name="sf.00N37000006UHlg" size="35" title="Enter Domiciled Country" type="text" validate="required:true">
                        </li>
                        <li id="DOM-H" style="display:none;">
                        Corporate domicile refers to a place where a companyâ€™s affairs are discharged. It is also known as the legal home of a corporation because the place is considered by law as the centre of corporate affairs. Corporate domicile is a place where a companyâ€™s principal affairs of business are maintained.
                        </li>
                         <li>        
					<span class="unlabel">Phone:
					<label for="sf.phone" class="error right"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                    </span>
					<input class="inputfield inputadjust" id="sf.phone" name="sf.phone" size="35" title="Enter Phone Number" type="text" validate="required:true">
                        </li>
                       </ul>
 
      <script>           
      $(document).ready(function () { 
		$("#DOM").click(function(){
    $("#DOM-H").toggle();
});
		
	});
     </script>           

 
                        
                        <ul class="form-section right">
                        <li>        
                    <span class="unlabel">Company Address:
					<label for="sf.street" class="error right"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                    </span>
					<input class="inputfield inputadjust" id="sf.street" name="sf.street" size="35" title="Enter Street Address" type="text" validate="required:true">
                        </li>
                        <li>        
                    <span class="unlabel">City:
					<label for="sf.city" class="error right"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                    </span>
					<input class="inputfield inputadjust" id="sf.city" name="sf.city" size="35" title="Enter City" type="text" validate="required:true">
                        </li>
                        <li>        
					<span class="unlabel">State/Province:
					<label for="sf.state" class="error right"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                    </span>
					<input class="inputfield inputadjust" id="sf.state" name="sf.state" size="35" title="Enter State or Province" type="text" validate="required:true">                  
                        </li>
                        <li>        
                    <span class="unlabel">ZIP/Postal Code:
					<label for="sf.zip" class="error right"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                    </span>
					<input class="inputfield inputadjust" id="sf.zip" name="sf.zip" size="35" title="Enter ZIP/Postal Code" type="text" validate="required:true">
                    	</li>
                        <li>        
					<span class="unlabel">Country:
					<label for="sf.country" class="error right"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                    </span>
					<input class="inputfield inputadjust" id="sf.country" name="sf.country" size="35" title="Enter Country" type="text" validate="required:true">
                        </li>
					</ul>
					</div>
				</div>
                
                
                
                
                
                
                
                
                
				<div style="display:block; margin: 20px 0px 0px 0px;padding:0px;">
					<label for="sf.first_name" class="error clear">Business Contact First Name is Required<br></label>
					<label for="sf.last_name" class="error clear">Business Contact Last Name is Required<br></label>
					<label for="sf.email" class="error clear">Business Contact Email is Required<br></label>
					<label for="sf.00N00000008nyhs" class="error clear">Business Contact Phone Number is Required<br></label>
					<label for="sf.first_name" class="error clear">Senior Management First Name is Required<br></label>
					<label for="sf.last_name" class="error clear">Senior Management Last Name is Required<br></label>
					<label for="sf.email" class="error clear">Senior Management Email is Required<br></label>
					<label for="sf.00N37000006UHld" class="error clear">Senior Management First Name is Required<br></label>
					<label for="sf.00N37000006UHle" class="error clear">Senior Management Last Name is Required<br></label>
					<label for="sf.00N37000006UHlc" class="error clear">Senior Management E-mail is Required<br></label>
					<label for="sf.00N37000006UHlf" class="error clear">Senior Management Title is Required<br></label>
				</div>
                
				<div class="area-wrap">
					<h3 class="legend-head">Contact Information</h3>
					<div class="form-content"> 
					<ul class="form-section left">
                    	<li>					
							<span class="unlabel">Business Contact First Name:
							<label for="sf.first_name" class="error right"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                            </span>
								<input class="inputfield inputadjust" id="sf.first_name" name="sf.first_name" size="28" title="Enter Business Contact First Name" type="text" validate="required:true">
                         </li>
                         <li>       
						<span class="unlabel">Business Contact Last Name:
						<label for="sf.last_name" class="error right"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                        </span>
						<input class="inputfield inputadjust" id="sf.last_name" name="sf.last_name" size="28" title="Enter Business Contact Last Name" type="text" validate="required:true">
                         </li>
                         <li>       
						<span class="unlabel">Business Contact E-mail:
						<label for="sf.email" class="error right"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                        </span>
						<input class="inputfield inputadjust" id="sf.email" name="sf.email" size="28" title="Enter Business Contact E-mail Addresss" type="text" validate="required:true, email:true">
                         </li>
                         <li>       
						<span class="unlabel">Business Contact Phone Number:
									<label for="sf.00N00000008nyhs" class="error right"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                                    </span>
								<input class="inputfield inputadjust" id="sf.00N00000008nyhs" name="sf.00N00000008nyhs" size="28" title="Enter Business Contact Phone Number" type="text" validate="required:true">
                         </li>
                         <li style="padding-top:20px;">       
						<span class="unlabel">Tech Contact First Name: <em>optional</em></span>
						<input class="inputfield inputadjust" id="sf.00N00000008nijL" name="sf.00N00000008nijL" size="28" title="Enter Technical Contact First Name" type="text" validate="required:false">
                         </li>
                         <li>       
						<span class="unlabel">Tech Contact Last Name: <em>optional</em></span>
						<input class="inputfield inputadjust" id="sf.00N00000008oyZV" name="sf.00N00000008oyZV" size="28" title="Enter Technical Contact Last Name" type="text" validate="required:false">
                         </li>
                        </ul>
                        
					<ul class="form-section right">
                         <li>       
						<span class="unlabel">Senior Management Contact First Name:
						<label for="sf.00N37000006UHld" class="error right"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                        </span>
						<input class="inputfield inputadjust" id="sf.00N37000006UHld" name="sf.00N37000006UHld" size="28" title="Enter Senior Management First Name" type="text" validate="required:true">
                         </li>
                         <li>       
						<span class="unlabel">Senior Management Contact Last Name:
						<label for="sf.00N37000006UHle" class="error right"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                        </span>
						<input class="inputfield inputadjust" id="sf.00N37000006UHle" name="sf.00N37000006UHle" size="28" title="Enter Senior Management last Name" type="text" validate="required:true">
                         </li>
                         <li>       
						<span class="unlabel">Senior Management Contact E-mail:
						<label for="sf.00N37000006UHlc" class="error right"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                        </span>
						<input class="inputfield inputadjust" id="sf.00N37000006UHlc" name="sf.00N37000006UHlc" size="28" title="Enter Senior Management Email" type="text" validate="required:true, email:true">
                         </li>
                         <li>       
						<span class="unlabel">Senior Management Contact Title:
						<label for="sf.00N37000006UHlf" class="error right"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                        </span>
						<input class="inputfield inputadjust" id="sf.00N37000006UHlf" name="sf.00N37000006UHlf" size="28" title="Enter Senior Management Title" type="text" validate="required:true">
						</li>
                         <li style="padding-top:20px;">       
						<span class="unlabel">Tech Contact Phone Number: <em>optional</em></span>
						<input class="inputfield inputadjust" id="sf.00N00000008nijQ" name="sf.00N00000008nijQ" size="28" title="Enter Technical Contact Telephone number" type="text" validate="required:false">
						</li>
                         <li>       
						<span class="unlabel">Tech Contact E-mail: <em>optional</em></span>
						<input class="inputfield inputadjust" id="sf.00N00000008nijV" name="sf.00N00000008nijV" size="28" title="Enter Technical Contact Telephone number" type="text" validate="required:false">
						</li>
					</ul>                        
					</div>
				</div>
                
                
                
                
                
                
				<div style="display:block; margin: 20px 0px 0px 0px;padding:0px;">
					<label for="sf.URL" class="error clear">Web Site is Required<br></label>
					<label for="sf.00N00000008nijG" class="error clear">Year Established is Required<br></label>
					<label for="sf.00N00000008nikn" class="error clear">Company Overview is Required</label>
		
				</div>
				<div class="area-wrap">
					<h3 class="legend-head">Detailed Company Information</h3>
					<div class="form-content"> 
					<ul class="form-section left">
					<li>
					<span class="unlabel">Web Site:
					<label for="sf.URL" class="error right"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                    </span>
					<input class="inputfield inputadjust" id="sf.URL" name="sf.URL" size="30" title="Enter Web Site" type="text" validate="required:true">
					</li>
					<li>
					<span class="unlabel">Year Established:
                    <label for="sf.00N00000008nijG" class="error"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                    </span>
					<input class="inputfield inputadjust" id="sf.00N00000008nijG" name="sf.00N00000008nijG" size="30" title="Enter Year Company was Established" type="text" validate="required:true">
					</li>
					<li>
					<span class="unlabel">Number of Employees: <em>optional</em></span> 
					<input class="inputfield inputadjust" id="sf.employees" name="sf.employees" size="30" title="Enter Number of Employees" type="text" validate="required:false">
					</li>
					<li>
					<span class="unlabel">Company Overview:
					<label for="sf.00N00000008nikn" class="error"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
					</span>
					<textarea class="inputfield inputadjust" id="sf.00N00000008nikn" name="sf.00N00000008nikn" cols="48" rows="5" title="Please Enter Overview of Company" validate="required:true"></textarea>
					</li>
                    </ul>
                    <ul class="form-section right">
					<li>
					<span class="unlabel">Competition / Differentiation: <em>optional</em></span>
                    <p class="sm">(Alternatives that are available to your solution and how your solution will differ)</p>
					<textarea class="inputfield inputadjust height-adjust" id="sf.00N00000008niks" name="sf.00N00000008niks" cols="48" rows="5" title="Please Enter Competition and Differentiation" validate="required:false"></textarea>
					</li>
					<li>
					<span class="unlabel">Market Strategy: <em>optional</em></span>
					<textarea class="inputfield inputadjust height-adjust" id="sf.00N00000008nim5" name="sf.00N00000008nim5" cols="48" rows="5" title="Please Enter Your Market Strategy" validate="required:false"></textarea>
					</li>
					</ul>
					</div>
				</div>
                
                
                
                
                
				<div style="display:block; margin: 20px 0px 0px 0px;padding:0px;">
					<label for="sf.00N00000008nio1" class="error clear">Please tell us if you are a Service Provider<br></label>
					<label for="sf.00N37000006UHlX" class="error clear">Please tell us if you have an AOC<br></label>
					<label for="sf.00N37000006UHlW" class="error clear">Please tell us if you have an SAQ-D<br></label>
					<label for="sf.00N37000006UHlU" class="error clear">Please tell us if you have are registered<br></label>
					<label for="sf.00N00000008nikO" class="error clear">Please tell us if you have paid your Third Party Registration Fees<br></label>
					<label for="sf.00N37000006V7g3" class="error clear">Please tell us which acquirers you are registered with<br></label>
					<label for="sf.00N00000008nijz" class="error clear">Please tell us about your Partner QSA<br></label>
					<label for="sf.00N00000008nj15" class="error clear">Please tell us if you are a Software Vendor<br></label>
					<label for="sf.pa_dss_validated" class="error clear">Please tell us if your solution is PA-DSS validated?<br></label>
					<label for="sf.00N37000006UHlY" class="error clear">Please tell us if you have an AOV</label>
				</div>
                
                
                
                
				<div class="area-wrap">
					<h3 class="legend-head">Compliance Information</h3>
					<div class="form-content"> 
					<ul class="form-section left">
					<li>
					<span class="unlabel">
                    Are you a Service Provider?
					<label for="sf.00N00000008nio1" class="error"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                    </span>
					<input class="certifyradio" id="sf.00N00000008nio1" name="sf.00N00000008nio1" title="Service Provider" type="radio" value="Yes" validate="required:true">
					Yes&nbsp;&nbsp;
					<input class="certifyradio" id="sf.00N00000008nio1" name="sf.00N00000008nio1" type="radio" value="No" validate="required:true">
					No&nbsp;&nbsp; 
					<input class="certifyradio" id="sf.00N00000008nio1" name="sf.00N00000008nio1" type="radio" value="N/A" validate="required:true">
					N/A&nbsp;&nbsp; 
					</li>
					<li>
                    <span class="unlabel">
					Do you have an AOC?
					<label for="sf.00N37000006UHlX" class="error"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                    </span>
					<input class="certifyradio" id="sf.00N37000006UHlX" name="sf.00N37000006UHlX" title="AOC" type="radio" value="Yes" validate="required:true">
					Yes&nbsp;&nbsp;
					<input class="certifyradio" id="sf.00N37000006UHlX" name="sf.00N37000006UHlX" type="radio" value="No" validate="required:true">
					No&nbsp;&nbsp; 
					<input class="certifyradio" id="sf.00N37000006UHlX" name="sf.00N37000006UHlX" type="radio" value="N/A" validate="required:true">
					N/A&nbsp;&nbsp; 
					</li>
					<li>
                    <span class="unlabel">
					Do you have a SAQ-D?
					<label for="sf.00N37000006UHlW" class="error"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                    </span>
					<input class="certifyradio" id="sf.00N37000006UHlW" name="sf.00N37000006UHlW" title="Service Provider" type="radio" value="Yes" validate="required:true">
					Yes&nbsp;&nbsp;
					<input class="certifyradio" id="sf.00N37000006UHlW" name="sf.00N37000006UHlW" type="radio" value="No" validate="required:true">
					No&nbsp;&nbsp; 
					<input class="certifyradio" id="sf.00N37000006UHlW" name="sf.00N37000006UHlW" type="radio" value="N/A" validate="required:true">
					N/A&nbsp;&nbsp; 
					</li>
					<li>
                    <span class="unlabel">
					Are you Registered?
					<label for="sf.00N37000006UHlU" class="error"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                    </span>
					<input class="certifyradio" id="sf.00N00000008nio1" name="sf.00N37000006UHlU" title="Are you registered" type="radio" value="Yes" validate="required:true">
					Yes&nbsp;&nbsp;
					<input class="certifyradio" id="sf.00N37000006UHlU" name="sf.00N37000006UHlU" type="radio" value="No" validate="required:true">
					No&nbsp;&nbsp; 
					<input class="certifyradio" id="sf.00N37000006UHlU" name="sf.00N37000006UHlU" type="radio" value="N/A" validate="required:true">
					N/A&nbsp;&nbsp; 
					</li>
					<li>
                    <span class="unlabel">
					Have you paid your annual Third Party Registration Fees for the Card Brands?
					<label for="sf.00N00000008nikO" class="error"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                    </span>
					<input class="certifyradio" id="sf.00N00000008nikO" name="sf.00N00000008nikO" title="Third Party Registration Fees" type="radio" value="Yes" validate="required:true">
					Yes&nbsp;&nbsp;
					<input class="certifyradio" id="sf.00N00000008nikO" name="sf.00N00000008nikO" type="radio" value="No" validate="required:true">
					No&nbsp;&nbsp; 
					<input class="certifyradio" id="sf.00N00000008nikO" name="sf.00N00000008nikO" type="radio" value="N/A" validate="required:true">
					N/A&nbsp;&nbsp; 
					</li>
					<li>
                    <span class="unlabel">
					Registered with which acquirers?
					<label for="sf.00N37000006V7g3" class="error"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                    </span>
					<textarea class="inputfield textareaadjust" id="sf.00N37000006V7g3" name="sf.00N37000006V7g3" cols="48" rows="5" title="Are you registered with which acquirers?" validate="required:true"></textarea>
					</li>		
                    </ul>
                    <ul class="form-section right">
					<li>
                    <span class="unlabel">
					Partner QSA
					<label for="sf.00N00000008nijz" class="error"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                    </span>
					<textarea class="inputfield textareaadjust" id="sf.00N00000008nijz" name="sf.00N00000008nijz" cols="48" rows="5" title="Partner QSA" validate="required:true"></textarea>
					</li>		
                    <li>
                    <span class="unlabel">				
					Are you a Software Vendor?
					<label for="sf.00N00000008nj15" class="error"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                    </span>
					<input class="certifyradio" id="sf.00N00000008nj15" name="sf.00N00000008nj15" title="Software Provider" type="radio" value="Yes" validate="required:true">
					Yes&nbsp;&nbsp;
					<input class="certifyradio" id="sf.00N00000008nj15" name="sf.00N00000008nj15" type="radio" value="No" validate="required:true">
					No&nbsp;&nbsp; 
					<input class="certifyradio" id="sf.00N00000008nj15" name="sf.00N00000008nj15" type="radio" value="N/A" validate="required:true">
					N/A&nbsp;&nbsp; 
					</li>
                    <li>
                    <span class="unlabel">				
					Is your Solution PA-DSS validated?
					<label for="sf.00N00000008nijf" class="error"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                    </span>
					<input class="certifyradio PA-DSS-Y" id="sf.pa_dss_validated" name="sf.pa_dss_validated" title="Is your Solution PA-DSS validated" type="radio" value="Yes" validate="required:true">
					Yes&nbsp;&nbsp;
					<input class="certifyradio PA-DSS-N" id="sf.pa_dss_validated" name="sf.pa_dss_validated" type="radio" value="No" validate="required:true">
					No&nbsp;&nbsp; 
					<input class="certifyradio PA-DSS-OFF" id="sf.pa_dss_validated" name="sf.pa_dss_validated" type="radio" value="N/A" validate="required:true">
					N/A&nbsp;&nbsp;
                    	<div id="hd1" style=" display:none">
                        	Your Validated Version:
                            <input class="inputfield inputadjust" id="sf.00N00000008nijp" name="sf.00N00000008nijp" size="30" title="Enter Validated Version" type="text" validate="required:false">
						</div> 
                    	<div id="hd2" style=" display:none">
                        	When will you be compliant?
                            <input class="inputfield inputadjust" id="sf.00N00000008niob" name="sf.00N00000008niob" size="30" title="Enter Compliance Date" type="text" validate="required:false">
						</div> 
					</li>
                    
                    <li>
                    <span class="unlabel">				
					Do you have an AOV? 
					<label for="sf.00N37000006UHlY" class="error"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                    </span>
					<input class="certifyradio" id="sf.00N37000006UHlY" name="sf.00N37000006UHlY" title="Software Provider" type="radio" value="Yes" validate="required:true">
					Yes&nbsp;&nbsp;
					<input class="certifyradio" id="sf.00N37000006UHlY" name="sf.00N37000006UHlY" type="radio" value="No" validate="required:true">
					No&nbsp;&nbsp; 
					<input class="certifyradio" id="sf.00N37000006UHlY" name="sf.00N37000006UHlY" type="radio" value="N/A" validate="required:true">
					N/A&nbsp;&nbsp; 
					</li>
					</ul>				
					</div>
				</div>
                
     <script>           
      $(document).ready(function () { 
		$(".PA-DSS-Y").change(function () {
		  if ($(this).attr("checked")) {
			$("#hd1").show();
			$("#hd2").hide();
		  }
		});
		
		$(".PA-DSS-N").change(function () {
		  if ($(this).attr("checked")) {
			$("#hd2").show();
			$("#hd1").hide();
		  }
		});
		
		
		$(".PA-DSS-OFF").change(function () {
		  if ($(this).attr("checked")) {
			$("#hd1").hide();
			$("#hd2").hide();
		  }
		});
	});
     </script>           
                
                
				<div style="display:block; margin: 20px 0px 0px 0px;padding:0px;">
					<label for="sf.00N00000008nimA" class="error clear" style="clear:both;width:100%;">Please tell what functions are critical for your success<br>
					</label>
					<label for="sf.00N00000008nimF" class="error clear" style="clear:both;width:100%;">Please tell tell us how you propose to measure success<br>
					</label>
					<label for="sf.00N00000008nimK" class="error clear" style="clear:both;width:100%;">Please tell if you are in an existing processor relationship, and with whom</label>
				</div>
                
                
				<div class="area-wrap">
					<h3 class="legend-head">Partnership Information</h3>
					<div class="form-content"> 
					<ul class="form-section left">
						<li>
                        <span class="unlabel">								
						Incentive for Partnering with Chase Paymentech: <em>optional</em>
                        </span>
						<textarea class="inputfield inputadjust" id="sf.00N00000008nimA" name="sf.00N00000008nimA" cols="48" rows="5" title="Please Enter Overview of Company" validate="required:false" style="margin-top: 0px; margin-bottom: 5px; height: 425px;"></textarea>
						</li>
                        </ul>
                        <ul class="form-section right">
                        <li>
                        <span class="unlabel">
						Identify Existing Processor Relationships:
						<label for="sf.00N00000008nimK" class="error"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                        </span>
						<textarea class="inputfield inputadjust" id="sf.00N00000008nimK" name="sf.00N00000008nimK" cols="48" rows="5" title="Please Enter Target Market and Size of Market" validate="required:true"></textarea>
						</li>
                        </ul>				
					</div>
				</div>
                
                
                
                
                
                
				<div style="display:block; margin: 20px 0px 0px 0px;padding:0px;">
					<label for="sf.00N00000008nimP" class="error">At Least One Business Vertical is Required</label>
				</div>
				<div class="area-wrap">
					<h3 class="legend-head">Business Verticals </h3>
					<div class="form-content"> 
					<ul class="form-section full-width">
							<li>
								<em>(Select all that apply; at least one choice is required)</em>
								<label for="sf.00N00000008nimP" class="error"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
							</li>
                         </ul>
                        <div class="multi-wrapper">
                                <span class="unlabel">
                                Use the shift key to select items in a row.<br>The Control or Alt keys can be used to to select multiple items. 
                                </span>
                                                       
                        <select id="sf.00N00000008nimP" multiple="multiple" name="sf.00N00000008nimP" title="Business Verticals" validate="required:true">
                        <option value="Ecommerce">Ecommerce</option>
                        <option value="Retail">Retail</option>
                        <option value="Petroleum">Petroleum</option>
                        <option value="Medical">Medical</option>
                        <option value="Government">Government</option>
                        <option value="Lodging">Lodging</option>
                        <option value="Auto Rental">Auto Rental</option>
                        <option value="Not-For-Profit">Not-For-Profit</option>
                        <option value="Restaurant">Restaurant</option>
                        <option value="Cash Advance">Cash Advance</option>
                        <option value="Direct Marketing">Direct Marketing</option>
                        <option value="Debit Only">Debit Only</option>
                        <option value="Stored Value">Stored Value</option>
                        </select>
                        </div>




					</div>
				</div>
                
                
                
				<div style="display:block; margin: 20px 0px 0px 0px;padding:0px;">
					<label for="sf.00N00000008nirP" class="error clear">Please tell us the number of Existing Merchants for all acquirers<br></label>
					<label for="sf.00N00000008nirU" class="error clear">Please tell us the Projected New Merchants Per Month to Chase<br></label>
					<label for="sf.00N00000008nirZ" class="error clear">Please tell us the Avg. Annual Merchant Sales Volume<br></label>
					<label for="sf.00N00000008nire" class="error clear">Please tell us if the Avg. Annual Merchant Sales Transactions<br></label>
					<label for="sf.00N37000006UHlb" class="error clear">Please List Merchant's driving integration<br></label>
					<label for="sf.00N37000006UHlV" class="error clear">Please Detail the Transactional Flow from customer to Chase<br></label>
                </div>
				<div class="area-wrap">
					<h3 class="legend-head">Portfolio Profile</h3>
					<div class="form-content"> 
					<ul class="form-section left">
					<li>
                    <span class="unlabel">
					Number of Existing Merchants using your solution across all acquirers:
					<label for="sf.00N00000008nirP" class="error right"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                    </span>
					<input class="inputfield inputadjust" id="sf.00N00000008nirP" name="sf.00N00000008nirP" size="30" title="Number of existing merchants" type="text" validate="required:true">
					</li>
					<li>
                    <span class="unlabel">
					Projected New Merchants Per Month to Chase:
					<label for="sf.00N00000008nirU" class="error right"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                    </span>
					<input class="inputfield inputadjust" id="sf.00N00000008nirU" name="sf.00N00000008nirU" size="30" title="Projected new Merchants per month" type="text" validate="required:true">
					</li>
					<li>
                    <span class="unlabel">
					Average Annual Merchant Sales Volume:
					<label for="sf.00N00000008nirZ" class="error right"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                    </span>
					<input class="inputfield inputadjust" id="sf.00N00000008nirZ" name="sf.00N00000008nirZ" size="30" title="Average Annual Merchant Sales Volume" type="text" validate="required:true">
					</li>
                    </ul>
                    <ul class="form-section right">
					<li>
                    <span class="unlabel">
					Average Annual Merchant Sales Transactions:
					<label for="sf.00N00000008nire" class="error right"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                    </span>
					<input class="inputfield inputadjust" id="sf.00N00000008nire" name="sf.00N00000008nire" size="30" title="Average Annual Merchant Sales Transactions" type="text" validate="required:true">
					</li>
					<li>
                    <span class="unlabel">
					List Merchant's driving integration:
					<label for="sf.00N37000006UHlb" class="error right"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                    </span>
					<input class="inputfield inputadjust" id="sf.00N37000006UHlb" name="sf.00N37000006UHlb" size="30" title="List Merchant&#39;s driving integration" type="text" validate="required:true">
					</li>
					<li>
                    <span class="unlabel">
					Detail the Transactional Flow from customer to Chase
					<label for="sf.00N37000006UHlV" class="error right"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                    </span>
					<input class="inputfield inputadjust" id="sf.00N37000006UHlV" name="sf.00N37000006UHlV" size="30" title="Detail the Transactional Flow from customer to Chase" type="text" validate="required:true">
					</li>
					</ul>	
					</div>
				</div>
                
                
                
                
				<div style="display:block; margin: 20px 0px 0px 0px;padding:0px;">
					<label for="sf.00N00000008nimP" class="error">At Least One Business Vertical is Required</label>
				</div>
				<div class="area-wrap">
					<h3 class="legend-head">Transactional Data</h3>
					<div class="form-content"> 
						
								<p style="margin:-10px 0px 0px 0px;"><em>(Select all that apply; at least one choice is required)</em>
									<label for="sf.00N00000008pDOh" class="error"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
                                </p>


<div class="multi-wrapper">
		<span class="unlabel">
		Use the shift key to select items in a row.<br>The Control or Alt keys can be used to to select multiple items. 
		</span>
                               
<select id="sf.00N00000008pDOh" class="multiselect" multiple="multiple" name="sf.00N00000008pDOh" title="Transactional Data" validate="required:true">
<option value="Name">Name</option>
<option value="Chosen Name">Chosen Name</option>
<option value="Physical Address">Physical Address</option>
<option value="Zip Code">Zip Code</option>
<option value="Country of Domicile">Country of Domicile</option>
<option value="Telephone Number">Telephone Number</option>
<option value="Email address">Email address</option>
<option value="Date of Birth">Date of Birth</option>
<option value="Age">Age</option>
<option value="Marital Status">Marital Status</option>
<option value="Mother Maiden Name">Mother Maiden Name</option>
<option value="Account  Number">Account  Number</option>
<option value="Driver License">Driver License</option>
<option value="SSN or Equal">SSN or Equal</option>
<option value="Digital Signature">Digital Signature</option>
<option value="Account Transactions">Account Transactions</option>
<option value="Gift Card Ranges">Gift Card Ranges</option>
<option value="Debit Card Number">Debit Card Number</option>
<option value="Credit Card Number">Credit Card Number</option>
<option value="DVV CVC code">DVV CVC code</option>
<option value="DDA Number">DDA Number</option>
<option value="Utility Bill">Utility Bill</option>
<option value="Credit Bureau Score">Credit Bureau Score</option>
</select>
</div>
                                

                                      
                                        <ul class="boxes-textbox">																																																																																																																																										
                                        <li>
										<span class="unlabel">
                                        Additional Information <em>optional</em>
                                        </span>
                                        <textarea class="inputfield inputadjust" id="sf.description" name="sf.description" cols="48" rows="5" title="Additional Information" validate="required:false"></textarea>
										</li>
										</ul>

							
					</div>
				</div>


                
				<div style="display:block; margin: 20px 0px 0px 0px;padding:0px;">
					<label for="sf.00N37000006UHlZ" class="error">Certification of Functions is Required</label>
				</div>
				<div class="area-wrap">
					<h3 class="legend-head">Certification</h3>
					<div class="form-content"> 
					<ul class="form-section full-width">
						<li>	
                        <span class="unlabel">
						What are the features and functionalities you want to certify for?
                        <label for="sf.00N37000006UHlZ" class="error right"><img src="./page-three_files/warning15h.gif" alt="required field"></label>
						</span>
						<textarea class="inputfield inputadjust" id="sf.00N37000006UHlZ" name="sf.00N37000006UHlZ" cols="48" rows="5" title="Features and Functionalities you want to certify for" validate="required:true"></textarea>
						</li>
                        </ul>				
					</div>
				</div>
                
                
                


						<p id="submit" style="text-align:center;"><input onclick="return validateForm();" type="button" alt="Submit" id="btnSubmit" value="SUBMIT"></p>
							
					
				<br><br>
				<!--close the entire form div--> 
			</div>
		</div>
	</form>
	<div class="offer-popup">
					   		<div class="offer-popup-close">x</div>
					    <p>Thank You</p>
			</div>
			<div class="offer-popup-inside">
			</div> 
	</div>
</div>


	<!-- <div id="footer-include"> 
	<div id="footer">
	#footerLS
	<div id="footerLS">
	<div class="footerLogo"><span style="margin-right:40px"><img src="./page-three_files/chaseFooterLogo.png"></span><img src="./page-three_files/jpmFooterLogo.gif"></div>
	<a class="speedbump ext_link" href="https://commercesolutions.jpmorganchase.com/certify/#speedbump-modal" title="https://www.linkedin.com/company/chase-for-business" data-toggle="modal" data-target="#speedbump"><div id="linkedIn"></div></a> 
	<a class="speedbump ext_link" href="https://commercesolutions.jpmorganchase.com/certify/#speedbump-modal" title="https://www.youtube.com/user/WelcomeToChase" data-toggle="modal" data-target="#speedbump"><div id="youTube"></div></a>
	</div>
	#/footerLS
	#footCopy
	<div id="footCopy">	
	<div class="leftCopy">
		<p><a href="https://commercesolutions.jpmorganchase.com/contact_us_overview.html">Support</a></p>
		<p>Sales: <b>800.708.3740</b></p>
		<p>Client Support: <b>800.934.7717</b></p>
	</div>
	<div class="rightCopy">
		<p><a href="https://www.chase.com/" target="_blank">Chase <img src="./page-three_files/link-ex-nav.png" align="baseline"></a></p>
		<p><a href="https://www.jpmorgan.com/" target="_blank">J.P. Morgan <img src="./page-three_files/link-ex-nav.png" align="baseline"></a></p>
		<p><a href="http://www.jpmorganchase.com/" target="_blank">JPMorgan Chase &amp; Co. <img src="./page-three_files/link-ex-nav.png" align="baseline"></a></p>
	</div>
	
	</div>
	/#footCopy
	#footBase
	<div id="footBase">
	<p class="copyright">Copyright 2017, Merchant services are provided by Paymentech, LLC (“Chase”). <br>All Rights Reserved.</p>
	<ul id="fbNav">
		<li><a href="https://commercesolutions.jpmorganchase.com/system_requirements/" class="policy_terms">System Requirements</a></li>
		<li><a href="https://commercesolutions.jpmorganchase.com/termsofuse/" class="policy_terms">Terms of Use</a></li>
		<li><a href="https://commercesolutions.jpmorganchase.com/privacypolicy" class="policy_terms">Privacy Policy</a></li>
		<li><a href="https://commercesolutions.jpmorganchase.com/site_map.html">Site Map</a></li>
		<li><a href="https://commercesolutions.jpmorganchase.com/index.html">Home</a></li>
	</ul>
	/#footBase 
	</div>
	/#footer 
	
	
	
	Linkedin Lead Accelerator 
	<img height="1" width="1" alt="" style="display:none;" src="./page-three_files/saved_resource">
	
	
	
	<link rel="stylesheet" href="./page-three_files/speedbump.css" type="text/css">
	Speedbump Modal
	<div style="display:none;">
	<div id="speedbump-modal">
		<h4>You're Now Leaving Chase Merchant Services</h4>		 
		<p>Chase's website terms, privacy and security policies don't apply to the site you're about to visit. Please review its website terms, privacy and security policies to see how they apply to you. Chase isn't responsible for (and does not provide) any products, services, or content at this third-party site, except for products and services that explicitly carry the Chase name.</p>
	 
	        <ul class="modal-buttons">
	            <li><a type="button" class="btn btn-default" data-dismiss="modal">Cancel</a></li>
	            <li><a id="url_link" href="https://commercesolutions.jpmorganchase.com/certify/" target="_blank" class="btn btn-primary">Proceed</a></li>
	        </ul>
	
	</div>
	</div>
	
	
	
	</div></div> -->


<!-- start header include script --> 
<script type="text/javascript">
$(document).ready(function(){
    $( "#megamenu-include" ).load( "../includes/supernav2.html", function() {
//alert( "MM Load was performed." );
});
		}); 
</script> 
<!-- end header include script --> 

<!-- start footer include script --> 
<script type="text/javascript">
$(document).ready(function(){
 	$( "#footer-include" ).load( "../includes/global-footer2.html", function() {
			});
		}); 
</script> 
<!-- end footer include script --> 

<!-- start head tag include script --> 
<script type="text/javascript">
$(document).ready(function(){
 	$( "#head-tag-include" ).load( "../includes/head-tag.html", function() {
			});
		}); 
</script> 
<!-- end head tag include script -->

<!-- Bottom Parameter Passing Script 3.0 --> 
<script type="text/javascript"> 
  var params = window.location.search.substring(1).split('&');
  var date = new Date();
  var expiry = new Date(date.getTime() + 86400000);
  var names;
  for(var pIndex=0; pIndex<params.length;pIndex++){
         names = params[pIndex].split("=");
         if (names[0] == 'referralParty' || names[0] == 'f9tc' || names[0] == 'ef_id' || names[0] == 'mkwid'){  //add param name here.
           document.cookie = names[0]+'='+names[1]+';expires='+expiry.toGMTString()+';path=/;';
         }  
  }
</script> 

<!-- Google Code for Remarketing List 1 Remarketing List --> 
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 1066358774;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script> 
<script type="text/javascript" src="./page-three_files/conversion.js">
</script><!-- <iframe name="google_conversion_frame" title="Google conversion frame" width="300" height="13" src="./page-three_files/saved_resource.html" frameborder="0" marginwidth="0" marginheight="0" vspace="0" hspace="0" allowtransparency="true" scrolling="no"></iframe> -->
<noscript>
&lt;div style="display:inline;"&gt; &lt;img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/1066358774/?value=0&amp;amp;guid=ON&amp;amp;script=0"/&gt; &lt;/div&gt;
</noscript>

<!-- Top Parameter Passing Script 3.0 -->
<script type="text/javascript">
jQuery(document).ready(function(){
                var urlParams = window.location.search.substring(1).split('&');
                var pNames;
                var haveParams = false;
                for (var parIndex=0;parIndex<urlParams.length;parIndex++){
       pNames = urlParams[parIndex].split('=');
       if (pNames[0] == 'referralParty'){
         document.getElementById("sf.00N00000008iRz1").value = pNames[1];
         haveParams = true;
       }else if( pNames [0] == 'f9tc'){
         document.getElementById("sf.00N00000008ipHV").value = pNames[1];
         haveParams = true;
       }else if( pNames [0] == 'ef_id'){
         document.getElementById("sf.00N00000008paPw").value = pNames[1];
         haveParams = true;
       }else if( pNames [0] == 'mkwid'){
         document.getElementById("sf.00N00000008q1AF").value = pNames[1];
         haveParams = true;
       }
                }
  
    if (!haveParams){
       var cookies = document.cookie.split(';');
       var cNames;
       var cName;
       for(var cIndex=0;cIndex<cookies.length;cIndex++){
         cNames = cookies[cIndex].split('=');
         cName = cNames[0].replace(' ', '');
         if (cName == 'referralParty'){
            document.getElementById("sf.00N00000008iRz1").value = cNames[1];
         }else if (cName == 'f9tc'){ 
             document.getElementById("sf.00N00000008ipHV").value = cNames[1];
         }else if (cName == 'ef_id'){ 
             document.getElementById("sf.00N00000008paPw").value = cNames[1];
         }else if (cName == 'mkwid'){ 
             document.getElementById("sf.00N00000008q1AF").value = cNames[1];
         }
       }
    }
  });

</script>
<!-- END : Top Parameter Passing Script 3.0 -->





<div id="fancybox-tmp"></div><div id="fancybox-loading"><div></div></div><div id="fancybox-overlay"></div><div id="fancybox-wrap"><div id="fancybox-outer"><div class="fancybox-bg" id="fancybox-bg-n"></div><div class="fancybox-bg" id="fancybox-bg-ne"></div><div class="fancybox-bg" id="fancybox-bg-e"></div><div class="fancybox-bg" id="fancybox-bg-se"></div><div class="fancybox-bg" id="fancybox-bg-s"></div><div class="fancybox-bg" id="fancybox-bg-sw"></div><div class="fancybox-bg" id="fancybox-bg-w"></div><div class="fancybox-bg" id="fancybox-bg-nw"></div><div id="fancybox-content"></div><a id="fancybox-close"></a><div id="fancybox-title"></div><a href="javascript:;" id="fancybox-left"><span class="fancy-ico" id="fancybox-left-ico"></span></a><a href="javascript:;" id="fancybox-right"><span class="fancy-ico" id="fancybox-right-ico"></span></a></div></div><div id="WVRANDOMID9551691489551631390782488" style="POSITION:absolute; VISIBILITY:hidden; Z-INDEX:10; LEFT:0px; TOP:0px;"><a taborder="1" href="https://commercesolutions.jpmorganchase.com/certify/#Click to speak to a representative." title="Click to speak to a representative." alt="Click to speak to a representative." onmouseover="javascript:window.status=&#39;Click to speak to a representative.&#39;; return true;" style="cursor:pointer" onclick="webVoicePop(&#39;Template=955169&#39;, &#39;urid=306959&#39;); return false;"><img name="Click to speak to a representative." alt="Click to speak to a representative." href="#Click to speak to a representative." id="WVRANDOMID4955169148955163139078195" class="estaradefaultstyle5" style="MARGIN:0px; PADDING:0px; BORDER:0px; DISPLAY:block;" src="./page-three_files/cnp_award_banner.jpg" border="0" onmouseover="javascript:window.status=&#39;Click to speak to a representative.&#39;; return true;"></a></div></body></html>