<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<!-- saved from url=(0065)https://commercesolutions.jpmorganchase.com/partnership_form.html -->
<html lang="en" style="display: block;"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Become a Partner | Chase Merchant Services</title>
<meta http-equiv="Keywords" name="Keywords" content="chase partner">
<meta http-equiv="Description" name="Description" content="Establish a partnership with Chase, a leader in payment processing solutions.
">

<meta name="WT.ti" content="Become a Partner
">
<meta name="WT.cg_n" content="Forms">
<meta name="WT.cg_s" content="Email">
<link rel="shortcut icon" href="https://www.chasepaymentech.com/favicon.ico">
<link rel="icon" type="image/png" href="https://www.chasepaymentech.com/favicon.png">
<link rel="canonical" href="https://commercesolutions.jpmorganchase.com/partnership_form.html">
<link href="./page-four_files/usen_43.css" lang="en" media="screen" rel="stylesheet" rev="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="./page-four_files/dd.css">
<link href="./page-four_files/jquery_megamenu.css" media="screen" rel="stylesheet" type="text/css">
<link rel="stylesheet" href="./page-four_files/print.css" type="text/css" media="print">
<link rel="stylesheet" href="./page-four_files/jquery_ui_173_custom.css" type="text/css">
<link rel="stylesheet" type="text/css" href="./page-four_files/fancybox.css" media="screen">
<style type="text/css">
.recaptchatable {
	border: 1px solid #D7D7D7 !important;
	line-height: 1em;
	width: 100% !important;
}
span#recaptcha_privacy.recaptcha_only_if_privacy a {
	color:#CCC;
}
.captchaWrap {
	padding:0 10px 18px 10px;
	border: 1px solid #d7d7d7;
	width:450px;
	margin:20px auto 0 auto;
}
#formWrapper .wideColumn {
	margin-bottom: 20px;
	width: 960px;
}
#formWrapper .columnTwo {
	float: left;
	margin: 0;
	width: 960px;
}
#formWrapper .formOuterContainer {
	width: 432px;
	margin:0 auto;
}
#formWrapper .formOuterContainer h3 {
	font-family:Amplitude-Regular;
	font-size:20px;
	color:#6f6f6f;
	font-weight:normal;
	line-height:30px;
}
#formWrapper .captchaWrap h3 {
	font-family:Amplitude-Regular;
	font-size:20px;
	color:#6f6f6f;
	font-weight:normal;
	line-height:20px;
}
{
 display:none;
}
ul.megamenu li#wt_ps {
	background-color:#572c21!important;
}
</style>
<script async="" src="./page-four_files/analytics.js"></script><script> if (self == top) { document.documentElement.style.display = 'block'; } else { top.location = self.location; } </script>

<!-- start head include -->
<script type="text/javascript" src="./page-four_files/lr.php" charset="UTF-8"></script></head><body><div id="head-tag-include"></div>
<!-- /head include -->

<script src="./page-four_files/jquery_1_3_2_min.js" type="text/javascript"></script>
<script src="./page-four_files/jquery_dd.js" type="text/javascript"></script>
<script src="./page-four_files/jquery_megamenu.js" type="text/javascript"></script>
<script src="./page-four_files/jquery_ui_1_7_3_custom_min.js" type="text/javascript"></script>
<script src="./page-four_files/jquery_cycle_lite_1_0.js" type="text/javascript"></script>
<script src="./page-four_files/jquery_fancybox_1_3_4_pack.js" type="text/javascript"></script>
<script src="./page-four_files/jquery_hoverintent_minified.js" type="text/javascript"></script>
<script src="./page-four_files/chasepaymentech.js" type="text/javascript"></script>
<script language="javascript" src="./page-four_files/jquery_metadata_2_1.js" type="text/javascript"></script>
<script language="javascript" src="./page-four_files/jquery_validate_1_5_5_min.js" type="text/javascript"></script>
<script language="javascript" src="./page-four_files/cmxforms.js" type="text/javascript"></script>
<script language="javascript" src="./page-four_files/ewa_validation.js" type="text/javascript"></script>
<script type="text/javascript" src="./page-four_files/ddaccordion.js"></script>
<script type="text/javascript"> 
ddaccordion.init({
	headerclass: "ln-title", //Shared CSS class name of headers group
	contentclass: "ln-text", //Shared CSS class name of contents group
	revealtype: "clickgo", //Reveal content when user clicks or onmouseover the header? Valid value: "click", "clickgo", or "mouseover"
	mouseoverdelay: 200, //if revealtype="mouseover", set delay in milliseconds before header expands onMouseover
	collapseprev: true, //Collapse previous content (so only one open at any time)? true/false 
	defaultexpanded: [], //index of content(s) open by default [index1, index2, etc]. [] denotes no content.
	onemustopen: false, //Specify whether at least one header should be open always (so never all headers closed)
	animatedefault: false, //Should contents open by default be animated into view?
	persiststate: true, //persist state of opened contents within browser session?
	toggleclass: ["text-closed", "text-open"], //Two CSS classes to be applied to the header when it's collapsed and expanded, respectively ["class1", "class2"]
	togglehtml: ["prefix", "<span id='ln-icon-closed' class='ln-icon'></span>", "<span id='ln-icon-open' class='ln-icon'></span>"], //Additional HTML added to the header when it's collapsed and expanded, respectively  ["position", "html1", "html2"] (see docs)
	animatespeed: "fast", //speed of animation: integer in milliseconds (ie: 200), or keywords "fast", "normal", or "slow"
	oninit:function(expandedindices){ //custom code to run when headers have initalized
		//do nothing
	},
	onopenclose:function(header, index, state, isuseractivated){ //custom code to run whenever a header is opened or closed
		//do nothing
	}
})
</script><style type="text/css">
.ln-text{display: none}
a.hiddenajaxlink{display: none}
</style>

<!-- start validate script -->
<script type="text/javascript">
	$.metadata.setType("attr", "validate");
	ewa_validation.addAdditionalMethods();
	
	var redirectURL;
 
	function validateForm() {
	        // validation
	        var res = $('#referralForm').validate().form();
	        return res;
	}
</script>
<!-- end validate script -->

<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-455854-1', 'auto');
  ga('send', 'pageview');

</script>

<!-- Top Parameter Passing Script 3.0 -->
<script type="text/javascript">
jQuery(document).ready(function(){
                var urlParams = window.location.search.substring(1).split('&');
                var pNames;
                var haveParams = false;
                for (var parIndex=0;parIndex<urlParams.length;parIndex++){
       pNames = urlParams[parIndex].split('=');
       if (pNames[0] == 'referralParty'){
         document.getElementById("sf.00N00000008iRz1").value = pNames[1];
         haveParams = true;
       }else if( pNames [0] == 'f9tc'){
         document.getElementById("sf.00N00000008ipHV").value = pNames[1];
         haveParams = true;
       }else if( pNames [0] == 'ef_id'){
         document.getElementById("sf.00N00000008paPw").value = pNames[1];
         haveParams = true;
       }else if( pNames [0] == 'mkwid'){
         document.getElementById("sf.00N00000008q1AF").value = pNames[1];
         haveParams = true;
       }
                }
  
    if (!haveParams){
       var cookies = document.cookie.split(';');
       var cNames;
       var cName;
       for(var cIndex=0;cIndex<cookies.length;cIndex++){
         cNames = cookies[cIndex].split('=');
         cName = cNames[0].replace(' ', '');
         if (cName == 'referralParty'){
            document.getElementById("sf.00N00000008iRz1").value = cNames[1];
         }else if (cName == 'f9tc'){ 
             document.getElementById("sf.00N00000008ipHV").value = cNames[1];
         }else if (cName == 'ef_id'){ 
             document.getElementById("sf.00N00000008paPw").value = cNames[1];
         }else if (cName == 'mkwid'){ 
             document.getElementById("sf.00N00000008q1AF").value = cNames[1];
         }
       }
    }
  });

</script>
<!-- END : Top Parameter Passing Script 3.0 -->
<link rel="stylesheet" type="text/css" href="./page-four_files/jpm_overwrite.css" media="screen">

<div class="container">
	<!-- <div class="header">
		<div class="logo"><img src="./page-four_files/chaseLogo.png" alt="Chase" width="160" height="31"> <span class="jpmLogo"><img src="./page-four_files/jpmLogo.png" alt="J.P. Morgan"></span></div>
		<div class="global">
			<div class="toprow"> 
				Start Country Menu 
				<script type="text/javascript">
			function navigateTo(url) {
				document.location.href = url;
			}
			
			$(document).ready(function(e) {
				try {
					$("#country").msDropDown();
				} catch(e) {
					alert(e.message);
				}
			});
			</script>
				<div class="countryDropdown">
					<div class="ddOutOfVision" style="height:0px;overflow:hidden;position:absolute;" id="country_msddHolder"><select name="countrymenu" id="country" onchange="navigateTo(this.value)" style="display: none; width: 170px;">
						<option value="http://www.chasepaymentech.com?WT.mc_id=usflag_us" selected="selected" title="/images/icon_united_states.gif">UNITED STATES</option>
						<option value="http://en.chasepaymentech.ca?WT.mc_id=caflag_us" title="/images/icon_canada_english.gif">CANADA: ENGLISH</option>
						<option value="http://fr.chasepaymentech.ca?WT.mc_id=frflag_us" title="/images/icon_canada_french.gif">CANADA: FRENCH</option>
						<option value="http://europe.chasepaymentech.com?WT.mc_id=ukflag_us" title="/images/icon_europe.gif">EUROPE</option>
						<option value="http://www.chasepaymentech.de/?WT.mc_id=deflag_us" title="/images/icon_germany.gif">GERMANY</option>
					</select></div><div id="country_msdd" class="dd" style="display:none;width:170px;"><div id="country_title" class="ddTitle"><span id="country_arrow" class="arrow"></span><span class="ddTitleText" id="country_titletext"><img src="./page-four_files/icon_united_states.gif" align="absmiddle"> <span class="ddTitleText">UNITED STATES</span></span></div><div id="country_child" class="ddChild" style="display: none; width: 168px;"><a href="javascript:void(0);" class="selected enabled" id="country_msa_0"><img src="./page-four_files/icon_united_states.gif" align="absmiddle"> <span class="ddTitleText">UNITED STATES</span></a><a href="javascript:void(0);" class="enabled" id="country_msa_1"><img src="./page-four_files/icon_canada_english.gif" align="absmiddle"> <span class="ddTitleText">CANADA: ENGLISH</span></a><a href="javascript:void(0);" class="enabled" id="country_msa_2"><img src="./page-four_files/icon_canada_french.gif" align="absmiddle"> <span class="ddTitleText">CANADA: FRENCH</span></a><a href="javascript:void(0);" class="enabled" id="country_msa_3"><img src="./page-four_files/icon_europe.gif" align="absmiddle"> <span class="ddTitleText">EUROPE</span></a><a href="javascript:void(0);" class="enabled" id="country_msa_4"><img src="./page-four_files/icon_germany.gif" align="absmiddle"> <span class="ddTitleText">GERMANY</span></a></div></div>
				</div>
				End Country Menu
				
				<div class="contact_open"><span id="wt_hcu" class="cu"><a href="https://commercesolutions.jpmorganchase.com/contact_us_overview.html">CONTACT US</a></span> <span id="wt_hoa" class="ap"><a href="https://commercesolutions.jpmorganchase.com/forms/business-information.html" id="hoa">APPLY</a></span> </div>
				<div class="merchantlogin"><a href="https://commercesolutions.jpmorganchase.com/merchant_log_in.html" onclick="dcsMultiTrack(&#39;DCS.dcssip&#39;, &#39;www.chasepaymentech.com&#39;, &#39;WT.z_page_section&#39;, &#39;Header&#39;, &#39;WT.z_link_name&#39;, &#39;Merchant Login&#39;, &#39;WT.z_nav_section&#39;, &#39;Merchant Login&#39;);">LOGIN <img src="./page-four_files/link-int.gif" align="baseline"></a></div>
			</div>
			<div class="clearfloat"></div>
			<div class="commerceSolutions">Merchant Services</div>
		</div>
		<div class="clearfloat"></div>
		
		Start Megamenu
		<div id="supernav" class="nav">
			<ul class="megamenu" style="display: block;">
				<div id="megamenu-include"> -->


<style type="text/css">
ul.megamenu div.mm-item-content {
	padding:0px 20px;
}
.navbase {
	margin:0px;
	background-color:#6d6e71;
}
.navbase .inner {
	background-color:#6d6e71;
	margin:15px;
	overflow:hidden;
}
.navbase .inner .innerSection {
	float:left;
	padding-bottom:12px;
}
.navbase .inner .innerSection .subtitle {
	margin-top:12px;
}
.megamenu #productsServices {
	width:709px;
}
.navbase .inner #ps1 {
	width:228px;
}
.navbase .inner #ps2 {
	width:225px;
}
.navbase .inner #ps3 {
	width:210px;
}
.megamenu #merchantSupport {
	width:731px;
}
#learningResources .title {
	color:#e6e6e6;
	font-size:12px;
	font-family:Amplitude-Regular;
	padding:0;
	text-transform:uppercase;
	line-height:30px;
}
#learningResources .link {
	padding:5px 0 5px 0;
}
#learningResources .link a {
	line-height:18px;
	font-family: Amplitude-Regular;
	color: #fff;
	font-size:16px;
	display:block;
	padding:0;
}
#learningResources .title a {
	padding:0;
	line-height:30px;
	font-family: Amplitude-Regular;
	color: #fff;
	font-size:16px;
}
#productsServices .title {
	color:#e6e6e6;
	font-size:12px;
	font-family:Amplitude-Regular;
	padding:0;
	text-transform:uppercase;
	line-height:30px;
}
#productsServices .link {
	padding:5px 0 5px 0;
}

#productsServices .link a {
	line-height:18px;
	font-family: Amplitude-Regular;
	color: #fff;
	font-size:16px;
	display:block;
	padding:0;
}
#productsServices .title a {
	padding:0;
	line-height:30px;
	font-family: Amplitude-Regular;
	color: #fff;
	font-size:16px;
}
#merchantSupport .title {
	color:#e6e6e6;
	font-size:12px;
	font-family:Amplitude-Regular;
	padding:0;
	text-transform:uppercase;
	line-height:30px;
}
#merchantSupport .link {
	padding:5px 0 5px 0;
}
#merchantSupport .link a {
	line-height:18px;
	font-family: Amplitude-Regular;
	color: #fff;
	font-size:16px;
	display:block;
	padding:0;
}
#merchantSupport .title a {
	padding:0;
	line-height:30px;
	font-family: Amplitude-Regular;
	color: #fff;
	font-size:16px;
}
.navbase .inner #ms1 {
	width:225px;
}
.navbase .inner #ms2 {
	width:225px;
}
.navbase .inner #ms3 {
	width:214px;
	padding-left:10px;
}

.navbase .inner #lr1 {
	width:245px;
}
.navbase .inner #lr2 {
	width:275px;
}
.navbase .inner #lr3 {
	width:275px;

}
</style>

<!-- <div id="supernav" class="nav">
	<ul class="megamenu" style="display: block;">
		<li id="homeLink" class="mm-item" style="float: left;"><a href="https://commercesolutions.jpmorganchase.com/index.html" onclick="dcsMultiTrack(&#39;DCS.dcssip&#39;, &#39;www.chasepaymentech.com&#39;, &#39;WT.z_page_section&#39;, &#39;Super Nav&#39;, &#39;WT.z_link_name&#39;, &#39;Home Icon&#39;, &#39;WT.z_nav_section&#39;, &#39;Super Nav&#39;);" class="mm-item-link">&nbsp;<img src="./page-four_files/topnav_home_off.png" border="0" alt="Home Icon">&nbsp;</a></li>
		<li id="wt_ngs" class="mm-item" style="float: left;"> <a href="https://commercesolutions.jpmorganchase.com/apply/index.html?WT.mc_id=supernav_apply&amp;referralParty=SuperNavApply" class="mm-item-link">Apply</a></li>
		<li id="wt_nps" class="mm-item" style="float: left;"> <a href="https://commercesolutions.jpmorganchase.com/payment_processing_services_and_products.html" class="mm-item-link">Solutions</a>
			<div id="productsServices" class="navbase mm-item-content" style="display: none;"><div class="mm-content-base">
				<div class="inner">
					<div id="ps1" class="innerSection">
						<div class="title">Point-of-Sale Payments</div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/credit_card_machines.html">Credit Card Machines</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/products/pos-systems.html">POS Systems</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/ingenico_ict250.html">Ingenico iCT250, iWL 250</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/verifone_vx520.html">Verifone VX520</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/verifone_vx680.html">Verifone VX680 Wireless</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/onlineposterminalsolutions/index.html">Online POS Terminal</a></div>
						<div class="title subtitle">Online Payment Processing</div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/orbital/">Orbital</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/payment_gateway.html">Payment Gateway</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/virtual_terminal.html">Virtual Terminal</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/hosted_pay_page.html">Hosted Pay Page</a></div>
					</div>
					<div id="ps2" class="innerSection">
						<div class="title">Methods of Payment</div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/nfc_payments.html">NFC Payments</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/apple-pay.html">Apple Pay</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/recurring_payments.html">Recurring Payments</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/electronic_check_processing.html">Electronic Checks</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/debit_card_processing.html">Debit Card Processing</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/international_payments.html">International Payments</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/purchase_card.html">Purchase Card</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/paypal.html">PayPal</a></div>
						<div class="title subtitle">Mobile Payment Processing</div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/mobilecheckout/?WT.mc_id=supernav">Chase Mobile Checkout</a></div>
						<div class="link"><a href="https://secure.paymentech.com/developercenter/mobilesdk/ios/?WT.mc_id=cp002_sdk" target="_blank">Apple Pay SDK <img src="./page-four_files/link-external-sn.gif" align="baseline"></a></div>
					</div>
					<div id="ps3" class="innerSection">
						<div class="title">Fraud &amp; Security</div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/fraud_prevention_technology.html">Safetech Fraud Tools</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/safetech_encryption.html">Safetech Encryption</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/safetech_page_encryption.html">Safetech Page Encryption</a></div>
						<div class="title subtitle">Online Reporting</div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/resourceonline/">Resource Online</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/paymentechonline/">Paymentech Online</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/online_chargeback_management.html">Online Chargeback Management</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/mobiledashboard/?WT.mc_id=supernav">Mobile Dashboard</a></div>
					</div>
				</div>
			</div></div>
		</li>
		<li id="wt_nms" class="mm-item" style="float: left;"> <a href="https://commercesolutions.jpmorganchase.com/merchantcenter/" class="mm-item-link">Support</a>
			<div id="merchantSupport" class="navbase mm-item-content" style="display: none;"><div class="mm-content-base">
				<div class="inner">
					<div id="ms1" class="innerSection">
						<div class="title">New Customers</div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/welcome/">Activate Your Account</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/terminal_help_for_merchants.html">Credit Card Terminal Solutions</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/merchant_services_training.html">Get Trained</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/credit_card_logos.html">Credit Card Logos</a></div>
					</div>
					<div id="ms2" class="innerSection">
						<div class="title">Existing Customers</div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/help.html">Product Support</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/help.html#faq">Frequently Asked Questions</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/iservice/how_to_read_your_statement.html#tab2">How to Read Your Statement</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/statement_fees_defined.html">Statement Fees Defined</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/address_verification_service.html">AVS Response Codes</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/card_verification_codes.html">Card Verification Codes</a></div>
					</div>
					<div id="ms3" class="innerSection">
						<div class="title">Log In to Your Account</div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/merchant_log_in.html">Log In</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/statements_and_reports.html">Managing Your Account</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/chargebacks.html">Chargeback Management</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/statements_and_reports.html">Get Reports &amp; Statements</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/add_more_services.html">Add More Services</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/mobile_reporting.html">Mobile Reporting</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/supplies.html">Order Supplies</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/1099k/">IRS Reporting Requirements</a></div>
						<div class="link"><a href="https://secure.paymentech.com/developercenter/mobilesdk/ios/?WT.mc_id=cp002_sdk">Enable Apple Pay</a></div>
					</div>
				</div>
			</div></div>
		</li>
		<li id="wt_nlr" class="mm-item" style="float: left;"> <a href="https://commercesolutions.jpmorganchase.com/merchant_resources_and_help.html" class="mm-item-link">Resources</a>
			<div id="learningResources" class="navbase mm-item-content" style="display: none;"><div class="mm-content-base">
				<div class="inner">
					<div id="lr1" class="innerSection">
						<div class="title">Before You Start Processing</div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/why_choose_us.html">Why Choose Us</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/switch2us/">Switch to Us</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/accept_credit_card_payments.html">Payment Processing Benefits</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/the_basics.html">Basic Info for New Businesses</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/5_things_to_consider.html">Five Important Considerations</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/merchant_account_services.html">Merchant Account</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/credit_card_processing_fees.html">Credit Card Processing Fees</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/free_statement_review.html">Free Statement Review</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/personalized_programs.html">Personalized Quote</a></div>
					</div>
					<div id="lr2" class="innerSection">
						<div class="title">All About Payment Processing</div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/small_business_credit_card_processing.html">Small Business Credit Card Processing</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/mobile_wallet_technology.html">Mobile Wallet Technology</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/mobile_credit_card_processing.html">Mobile Credit Card Processing</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/emv_chip_technology.html">EMV Chip Technology</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/contactless_payments.html">Contactless Payments</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/interchange_and_assessment_understanding.html">Interchange</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/merchant_funding.html">Merchant Funding</a></div>
					</div>
					<div id="lr3" class="innerSection">
						<div class="title">Security &amp; Fraud Prevention</div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/protect_your_business.html">Protect Your Business</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/fraud_prevention.html">Prevent Fraud</a></div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/datasecurity/">PCI Data Security</a></div>
						<div class="title subtitle">Perspectives</div>
						<div class="link"><a href="https://commercesolutions.jpmorganchase.com/perspectives.html">White Papers &amp; Customer Stories</a></div>
					</div>
				</div>
			</div></div>
		</li>
		<li id="wt_ps" class="mm-item" style="float: left;"><a href="https://commercesolutions.jpmorganchase.com/partnership.html?WT.mc_id=supernav_partnership" class="mm-item-link">Partnerships</a></li>
		<li id="wt_nau" class="mm-item" style="float: left;"><a href="https://commercesolutions.jpmorganchase.com/developercenter/index.html?WT.mc_id=supernav_devcenter" target="_blank" class="mm-item-link">Developer Center <img src="./page-four_files/link-ex-topnav.png" align="baseline"></a></li><li class="clear-fix" style="display:none;"></li>
	</ul>
</div>
</div>
			</ul>
		</div>
		End Megamenu 
		
	</div> -->
	<div id="titleWrapper" style="padding-bottom:60px">
		<div class="line"></div>
		<div class="textbox">
			<h1>Become a Partner</h1>
		</div>
	</div>
	<p class="overview">Establish a partnership with the leader in payment processing solutions.</p>
	<br>
	<p class="overview">Establish a Partnership with Chase - the world's premier leader in payment processing solutions. In order for us to consider your proposed partnership, we'll need you to complete the form below.
		Any ideas, proposals, or other information (collectively, "Information") submitted or collected on this form shall be considered non-confidential and non-binding.</p>
	<br>
	<p class="overview" style="padding-left:50px"><i>Answers to all questions are required except those marked as optional.</i></p>
	<div id="formWrapper">
  <form action="https://www.chasepaymentech.com/referralFormService" id="referralForm" onsubmit="return validateForm()" method="post">
			<div class="wideColumn">
				<div class="columnTwo"> 
					<!-- Type -->
					<input id="form.type" name="form.type" type="hidden" value="SF">
					
					<!-- Environment -->
					<input id="identification.environment" name="identification.environment" type="hidden" value="Prod">
					
					<!-- OID -->
					<input id="sf.oid" name="sf.oid" type="hidden" value="00D00000000heJJ">
					
					<!-- Lead Source -->
			<input id="sf.lead_source" name="sf.lead_source" type="hidden" value="US Partner">
					<!-- 	<input id="sf.lead_source" name="sf.lead_source" type="hidden" value="CPS Marketing"> --> 


					<!-- Referral Source -->
					<input id="sf.00N00000006ohHG" name="sf.00N00000006ohHG" type="hidden" value="Partners Web Referral Form">
					
					<!-- Success URL-->
					<input type="hidden" id="redirectOnSuccessUrl" name="redirectOnSuccessUrl" value="https://www.chasepaymentech.com/thank_you.html">
					<!-- Error URL -->
					<input id="redirectOnErrorUrl" name="redirectOnErrorUrl" type="hidden" value="https://www.chasepaymentech.com/form_error.html">
					
					<!-- Daddy Analytics Token -->
					<input type="hidden" id="Daddy_Analytics_Token" name="sf.00N00000008opUw">
					
					<!-- Daddy Analytics Web to Lead URL -->
					<input type="hidden" id="Daddy_Analytics_WebForm_URL" name="sf.00N00000008opV2">
					
					<!-- The 4 parameters for passing script 3.0  -->
					<input id="sf.00N00000008ipHV" type="hidden" name="sf.00N00000008ipHV" value="">
					<input id="sf.00N00000008iRz1" type="hidden" name="sf.00N00000008iRz1" value="">
					<input id="sf.00N00000008paPw" type="hidden" name="sf.00N00000008paPw" value="">
					<input id="sf.00N00000008q1AF" type="hidden" name="sf.00N00000008q1AF" value="">
					<div class="formOuterContainer">
						<h3>Please tell us who you are:</h3>
						<p>Company Name:
							<label for="sf.company" class="error">Required</label>
							<br>
							<input class="inputfield" id="sf.company" maxlength="80" name="sf.company" style="width: 428px;" title="Company Name is required" type="text" validate="required:true">
						</p>
						<p>Contact First Name:
							<label for="sf.first_name" class="error">Required</label>
							<br>
							<input class="inputfield" id="sf.first_name" maxlength="80" name="sf.first_name" style="width: 428px;" title="Contact First Name is required" type="text" validate="required:true">
						</p>
						<p>Contact Last Name:
							<label for="sf.last_name" class="error">Required</label>
							<br>
							<input class="inputfield" id="sf.last_name" maxlength="80" name="sf.last_name" style="width: 428px;" title="Contact Last Name is required" type="text" validate="required:true">
						</p>
						<p>Title:
							<label for="sf.title" class="error">Required</label>
							<br>
							<select class="inputfield" id="sf.title" name="sf.title" style="width: 428px;" title="Title is required" validate="required:true">
								<option value="" selected="selected">Select Job Title...</option>
								<option value="CEO">CEO</option>
								<option value="President">President</option>
								<option value="Owner">Owner</option>
								<option value="Treasurer/Controller">Treasurer/Controller</option>
								<option value="Administrative Assistant">Administrative Assistant</option>
								<option value="Business Manager">Business Manager</option>
								<option value="Business Development">Business Development</option>
								<option value="Marketing Manager">Marketing Manager</option>
								<option value="Operations Manager">Operations Manager</option>
								<option value="Office Manager">Office Manager</option>
								<option value="Consultant">Consultant</option>
								<option value="Other">Other</option>
							</select>
						</p>
						<p>Address:
							<label for="sf.street" class="error">Required</label>
							<br>
							<input class="inputfield" id="sf.street" maxlength="80" name="sf.street" style="width: 428px;" title="Address is required" type="text" validate="required:true">
						</p>
						<p>City:
							<label for="sf.city" class="error">Required</label>
							<br>
							<input class="inputfield" id="sf.city" maxlength="80" name="sf.city" style="width: 428px;" title="City is required" type="text" validate="required:true">
						</p>
						<p>State/Province:
							<label for="sf.state" class="error">Required</label>
							<br>
							<select class="inputfield" id="sf.state" name="sf.state" style="width: 428px;" title="State/Province is required" validate="required:true">
								<option value="" selected="selected">Select...</option>
								<option value="AL">Alabama</option>
								<option value="AK">Alaska</option>
								<option value="AZ">Arizona</option>
								<option value="AR">Arkansas</option>
								<option value="CA">California</option>
								<option value="CO">Colorado</option>
								<option value="CT">Connecticut</option>
								<option value="DE">Delaware</option>
								<option value="DC">District Of Columbia</option>
								<option value="FL">Florida</option>
								<option value="GA">Georgia</option>
								<option value="HI">Hawaii</option>
								<option value="ID">Idaho</option>
								<option value="IL">Illinois</option>
								<option value="IN">Indiana</option>
								<option value="IA">Iowa</option>
								<option value="KS">Kansas</option>
								<option value="KY">Kentucky</option>
								<option value="LA">Louisiana</option>
								<option value="ME">Maine</option>
								<option value="MD">Maryland</option>
								<option value="MA">Massachusetts</option>
								<option value="MI">Michigan</option>
								<option value="MN">Minnesota</option>
								<option value="MS">Mississippi</option>
								<option value="MO">Missouri</option>
								<option value="MT">Montana</option>
								<option value="NE">Nebraska</option>
								<option value="NV">Nevada</option>
								<option value="NH">New Hampshire</option>
								<option value="NJ">New Jersey</option>
								<option value="NM">New Mexico</option>
								<option value="NY">New York</option>
								<option value="NC">North Carolina</option>
								<option value="ND">North Dakota</option>
								<option value="OH">Ohio</option>
								<option value="OK">Oklahoma</option>
								<option value="OR">Oregon</option>
								<option value="PA">Pennsylvania</option>
								<option value="RI">Rhode Island</option>
								<option value="SC">South Carolina</option>
								<option value="SD">South Dakota</option>
								<option value="TN">Tennessee</option>
								<option value="TX">Texas</option>
								<option value="UT">Utah</option>
								<option value="VT">Vermont</option>
								<option value="VA">Virginia</option>
								<option value="WA">Washington</option>
								<option value="WV">West Virginia</option>
								<option value="WI">Wisconsin</option>
								<option value="WY">Wyoming</option>
								<option value="Alberta">Alberta</option>
								<option value="British Columbia">British Columbia</option>
								<option value="Manitoba">Manitoba</option>
								<option value="New Bunswick">New Bunswick</option>
								<option value="Newfoundland and Labrador">Newfoundland and Labrador</option>
								<option value="Northwest Territories">Northwest Territories</option>
								<option value="Nova Scotia">Nova Scotia</option>
								<option value="Nunavut">Nunavut</option>
								<option value="Ontario">Ontario</option>
								<option value="Prince Edward Island">Prince Edward Island</option>
								<option value="Quebec">Quebec</option>
								<option value="Saskatchewan">Saskatchewan</option>
								<option value="Yukon Territory">Yukon Territory</option>
							</select>
						</p>
						<p>Zip/Postal Code:
							<label for="sf.zip" class="error">Required</label>
							<br>
							<input class="inputfield" id="sf.zip" maxlength="20" name="sf.zip" style="width: 428px;" title="Zip/Postal Code is required" type="text" validate="required:true, zipcode:true">
						</p>
						<p>Telephone Number:
							<label for="sf.phone" class="error">A valid telephone number is required.</label>
							<br>
							<input class="inputfield" id="sf.phone" maxlength="40" name="sf.phone" style="width: 428px;" title="A valid phone number is required" type="text" validate="required:true, phone:true">
						</p>
						<p>Email Address:
							<label for="sf.email" class="error">A valid email address is required.</label>
							<br>
							<input class="inputfield" id="sf.email" maxlength="80" name="sf.email" style="width: 428px;" title="A valid email address is required" type="text" validate="required:true, email:true">
						</p>
						<p>Web Address:
							<label for="url" class="error">A valid web address is required.</label>
							<br>
							<input class="inputfield" id="sf.url" name="sf.url" style="width: 428px;" title="A valid web address is required" type="text" validate="required:true">
							<br>
						</p><p>Description of Business:<br>
							(Description of products/services sold):
							<label for="sf.description" class="error">Required</label>
							<br>
							<textarea id="sf.description" name="sf.description" cols="50" rows="10" title="Please Enter Business Description" validate="required:true"></textarea>
						</p>
						<p>Please give a brief description of your proposed partnership with Chase Paymentech, including how this partnership would benefit Chase Paymentech and/or its merchant base.
							<label for="sf.00N00000008oi5H" class="error">Required</label>
							<br>
							<textarea id="sf.00N00000008oi5H" name="00N00000008oi5H" cols="50" rows="10" title="Please Enter Partnership Description" validate="required:true"></textarea>
						</p>

					<div id="submit" style="width:464px;margin:24px auto 0 auto">
						<input type="submit" alt="Send Message" id="btnSubmit" value="GET STARTED">
					</div>
				</div>
										
				</div>
				<div class="columnThree"> </div>
			</div>
		</form>
	</div>
	<div style="clear:both"></div>
</div>

<!-- main footer class -->
<div id="footer-include"> 
<div id="footer">
<!-- #footerLS -->
<div id="footerLS">
	<div class="footerLogo"><span style="margin-right:40px"><img src="./page-four_files/chaseFooterLogo.png"></span><img src="./page-four_files/jpmFooterLogo.gif"></div>
	<a class="speedbump ext_link" href="https://commercesolutions.jpmorganchase.com/partnership_form.html#speedbump-modal" title="https://www.linkedin.com/company/chase-for-business" data-toggle="modal" data-target="#speedbump"><div id="linkedIn"></div></a> 
	<a class="speedbump ext_link" href="https://commercesolutions.jpmorganchase.com/partnership_form.html#speedbump-modal" title="https://www.youtube.com/user/WelcomeToChase" data-toggle="modal" data-target="#speedbump"><div id="youTube"></div></a>
</div>
<!-- #/footerLS -->
<!-- #footCopy -->
<div id="footCopy">	
	<div class="leftCopy">
		<p><a href="https://commercesolutions.jpmorganchase.com/contact_us_overview.html">Support</a></p>
		<p>Sales: <b>800.708.3740</b></p>
		<p>Client Support: <b>800.934.7717</b></p>
	</div>
	<div class="rightCopy">
		<p><a href="https://www.chase.com/" target="_blank">Chase <img src="./page-four_files/link-ex-nav.png" align="baseline"></a></p>
		<p><a href="https://www.jpmorgan.com/" target="_blank">J.P. Morgan <img src="./page-four_files/link-ex-nav.png" align="baseline"></a></p>
		<p><a href="http://www.jpmorganchase.com/" target="_blank">JPMorgan Chase &amp; Co. <img src="./page-four_files/link-ex-nav.png" align="baseline"></a></p>
	</div>

</div>
<!-- /#footCopy -->
<!-- #footBase -->
<div id="footBase">
	<p class="copyright">Copyright 2017, Merchant services are provided by Paymentech, LLC (“Chase”). <br>All Rights Reserved.</p>
	<ul id="fbNav">
		<li><a href="https://commercesolutions.jpmorganchase.com/system_requirements/" class="policy_terms">System Requirements</a></li>
		<li><a href="https://commercesolutions.jpmorganchase.com/termsofuse/" class="policy_terms">Terms of Use</a></li>
		<li><a href="https://commercesolutions.jpmorganchase.com/privacypolicy" class="policy_terms">Privacy Policy</a></li>
		<li><a href="https://commercesolutions.jpmorganchase.com/site_map.html">Site Map</a></li>
		<li><a href="https://commercesolutions.jpmorganchase.com/index.html">Home</a></li>
	</ul>
	<!-- /#footBase --> 
</div>
<!-- /#footer --> 



<!-- Linkedin Lead Accelerator  --> 
<img height="1" width="1" alt="" style="display:none;" src="./page-four_files/saved_resource">



<link rel="stylesheet" href="./page-four_files/speedbump.css" type="text/css">
<!-- Speedbump Modal -->
<div style="display:none;">
	<div id="speedbump-modal">
		<h4>You're Now Leaving Chase Merchant Services</h4>		 
		<p>Chase's website terms, privacy and security policies don't apply to the site you're about to visit. Please review its website terms, privacy and security policies to see how they apply to you. Chase isn't responsible for (and does not provide) any products, services, or content at this third-party site, except for products and services that explicitly carry the Chase name.</p>
 
        <ul class="modal-buttons">
            <li><a type="button" class="btn btn-default" data-dismiss="modal">Cancel</a></li>
            <li><a id="url_link" href="https://commercesolutions.jpmorganchase.com/partnership_form.html" target="_blank" class="btn btn-primary">Proceed</a></li>
        </ul>

	</div>
</div>



</div></div>


<!-- start header include script --> 
<script type="text/javascript">
$(document).ready(function(){
    $( "#megamenu-include" ).load( "includes/supernav2.html", function() {
//alert( "MM Load was performed." );
});
		}); 
</script> 
<!-- end header include script --> 

<!-- start footer include script --> 
<script type="text/javascript">
$(document).ready(function(){
 	$( "#footer-include" ).load( "includes/global-footer2.html", function() {
			});
		}); 
</script> 
<!-- end footer include script --> 

<!-- start head tag include script --> 
<script type="text/javascript">
$(document).ready(function(){
 	$( "#head-tag-include" ).load( "includes/head-tag.html", function() {
			});
		}); 
</script> 
<!-- end head tag include script --> 

<!-- Bottom Parameter Passing Script 3.0 --> 
<script type="text/javascript"> 
  var params = window.location.search.substring(1).split('&');
  var date = new Date();
  var expiry = new Date(date.getTime() + 86400000);
  var names;
  for(var pIndex=0; pIndex<params.length;pIndex++){
         names = params[pIndex].split("=");
         if (names[0] == 'referralParty' || names[0] == 'f9tc' || names[0] == 'ef_id' || names[0] == 'mkwid'){  //add param name here.
           document.cookie = names[0]+'='+names[1]+';expires='+expiry.toGMTString()+';path=/;';
         }  
  }
</script> 

<!-- Google Code for Remarketing List 1 Remarketing List --> 
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 1066358774;
var google_custom_params = window.google_tag_params;
var google_remarketing_only = true;
/* ]]> */
</script> 
<script type="text/javascript" src="./page-four_files/conversion.js">
</script><iframe name="google_conversion_frame" title="Google conversion frame" width="300" height="13" src="./page-four_files/saved_resource.html" frameborder="0" marginwidth="0" marginheight="0" vspace="0" hspace="0" allowtransparency="true" scrolling="no"></iframe>
<noscript>
&lt;div style="display:inline;"&gt; &lt;img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/1066358774/?value=0&amp;amp;guid=ON&amp;amp;script=0"/&gt; &lt;/div&gt;
</noscript>






<div id="fancybox-tmp"></div><div id="fancybox-loading"><div></div></div><div id="fancybox-overlay"></div><div id="fancybox-wrap"><div id="fancybox-outer"><div class="fancybox-bg" id="fancybox-bg-n"></div><div class="fancybox-bg" id="fancybox-bg-ne"></div><div class="fancybox-bg" id="fancybox-bg-e"></div><div class="fancybox-bg" id="fancybox-bg-se"></div><div class="fancybox-bg" id="fancybox-bg-s"></div><div class="fancybox-bg" id="fancybox-bg-sw"></div><div class="fancybox-bg" id="fancybox-bg-w"></div><div class="fancybox-bg" id="fancybox-bg-nw"></div><div id="fancybox-content"></div><a id="fancybox-close"></a><div id="fancybox-title"></div><a href="javascript:;" id="fancybox-left"><span class="fancy-ico" id="fancybox-left-ico"></span></a><a href="javascript:;" id="fancybox-right"><span class="fancy-ico" id="fancybox-right-ico"></span></a></div></div><div id="WVRANDOMID9551691489551654673989884" style="POSITION:absolute; VISIBILITY:hidden; Z-INDEX:10; LEFT:0px; TOP:0px;"><a taborder="1" href="https://commercesolutions.jpmorganchase.com/partnership_form.html#Click to speak to a representative." title="Click to speak to a representative." alt="Click to speak to a representative." onmouseover="javascript:window.status=&#39;Click to speak to a representative.&#39;; return true;" style="cursor:pointer" onclick="webVoicePop(&#39;Template=955169&#39;, &#39;urid=306959&#39;); return false;"><img name="Click to speak to a representative." alt="Click to speak to a representative." href="#Click to speak to a representative." id="WVRANDOMID49551691489551654673785685" class="estaradefaultstyle5" style="MARGIN:0px; PADDING:0px; BORDER:0px; DISPLAY:block;" src="./page-four_files/cnp_award_banner.jpg" border="0" onmouseover="javascript:window.status=&#39;Click to speak to a representative.&#39;; return true;"></a></div></body></html>