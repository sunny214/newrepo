<section id="division-container" class="module module-padding-medium">
    <div id="division-hero-container">
        <div id="" class="img-txt-split container-highlight">
            <img id="img-txt-split__img" class="img-txt-split__img lazy img-responsive" data-bttrlazyloading-xs-src="http://jpmcareers.jpmchase.net/careers/1320541900707/1320541900687.jpg"
                data-bttrlazyloading-sm-src="http://jpmcareers.jpmchase.net/careers/1320541900709/1320541900685.jpg" alt="Divisions "
            />
            <noscript><img id="" class="img-txt-split img-responsive" src="/images/tmp/photo01-16-9.jpg" /></noscript>
            <div class="img-txt-split__content--wrap">
                <div class="container">
                    <div class="row">
                        <div class="col-xs-12 col-md-6 colnoleftpadding-small-up">
                            <div id="" class="img-txt-split__content">
                                <div class="img-txt-split__content--bacon">
                                    <h3 id="img-txt-split__title" class="img-txt-split__title">Featured divisions</h3>
                                    <p id="img-txt-split__desc" class="img-txt-split__desc">We’ve been in London since the 1930s. It’s our headquarters for Europe, the Middle East
                                        and Africa. We offer an unparalleled client base and leadership across the spectrum
                                        of financial services products. Find your new team with us.</p>
                                    <p>
                                    </p>
                                    <ul id="img-txt-split__list-items" class="unstyled">
                                        <li><a href="http://jpmcareers.jpmchase.net/careers/divisions/investor-services">Investor Services</a></li>
                                        <li><a href="http://jpmcareers.jpmchase.net/careers/divisions/global-wealth-management">Global Wealth Management</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div id="all-divisions" class="module no-module-padding no-module-margin">
        <div class="container">
            <div class="col-xs-12 text-center">
                <a href="http://jpmcareers.jpmchase.net/careers/divisions" class="btn btn-outline red margin-sm">browse all divisions</a>
            </div>
        </div>
    </div>
</section>