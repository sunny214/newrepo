jQuery(document).ready(function(){
	jQuery(".offer-popup, .offer-popup-inside").hide();
	jQuery("#submit").click(function(){
	//	setTimeout(function(){

			var errorsLen=jQuery('.validation-offerform label.error').filter(function(){
								return jQuery(this).css('display')!=='none';
							}).length;

			
			
			if(!(errorsLen>0)){
				jQuery(".offer-popup, .offer-popup-inside").show();
				return false;
			}
	//	},500);

	})
	jQuery(".offer-popup-close").click(function(){
		jQuery(".offer-popup, .offer-popup-inside").hide();
	})
	
});