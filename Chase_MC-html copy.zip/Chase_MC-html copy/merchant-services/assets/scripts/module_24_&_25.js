$(document).ready(function () {
	$("#referralForm").on("submit",function (evt) {
		var $inputFields = $("#referralForm").find('.form-control'),valid = true;
				$inputFields.each(function(key,field){
				$(field).removeClass("errorInput");
				$(field).siblings('span.error').addClass('hidden');
			if($(field).val() == ""){
				valid = false;
				$(field).addClass("errorInput");
				$(field).siblings('span.error').removeClass('hidden');
			}
		})
		if(!valid){
		evt.preventDefault();	
		}
		
	})
})