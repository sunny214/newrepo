    <div class="relatedProgramsModule">
      <div class="row">
        <div class="col-xs-12 col-sm-8 col-sm-offset-2 text-center">
          <h2 id="related-programs-title" class="margin-bottom-xs">You may also be interested in...</h2>
          <ul id="related-programs-listing" class="unstyled"><li id="related-programs-listing-item-1"><a id="related-programs-listing-item__a" href="http://careers.jpmorgan.com/careers/programs/global-investment-management-fulltime-analyst">Global Investment Management Analyst Program - Full-time</a></li><li id="related-programs-listing-item-2"><a id="related-programs-listing-item__a" href="http://careers.jpmorgan.com/careers/programs/investment-banking-fulltime-analyst">Investment Banking Analyst Program - Full-time</a></li></ul>
          
          <p class="module-padding-base-both">
            <a id="browse-all-programs" class="btn btn-outline red margin-bottom-lg" href="http://careers.jpmorgan.com/careers/programs">Browse all programs</a>
          </p>
        </div>
      </div>
    </div>
