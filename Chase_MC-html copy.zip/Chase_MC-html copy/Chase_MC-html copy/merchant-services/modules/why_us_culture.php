
  <section id="whyus__culture" class="module">
    <div class="container">
      <div class="row">
        <div class="col-xs-12 col-sm-8 col-sm-offset-2">
          <h2 id="whyus__culture-title" class="text-center text-xs-left">Culture</h2>
        </div>
      </div>
    </div>
    <div class="container-highlight colnopadding-small-down module-padding-base-both">
      <div class="row">
        <div class="col-xs-12 padding-reset">
          <img id="whyus__culture-img" class="img-responsive lazy" data-bttrlazyloading-xs-src="http://careers.jpmorgan.com/careers/1320685562020/1320542568671.jpg" data-bttrlazyloading-sm-src="http://careers.jpmorgan.com/careers/1320685562022/1320542568669.jpg" alt="Our culture" />
          <noscript><img id="whyus__culture-img-default" class="img-responsive" src="http://careers.jpmorgan.com/careers/1320685562020/1320542568671.jpg" data-bttrlazyloading-xs-src="http://careers.jpmorgan.com/careers/1320685562020/1320542568671.jpg" alt="Our culture" /></noscript>
        </div>
      </div>
    </div>
    <div class="container">
      <div class="row">
        <div id="whyus__culture-stories" class="col-xs-12 col-sm-8 col-sm-offset-2"><div id="text-one-container" class="col-xs-12">
  <p id="column-1">We believe in “doing first-class business in a first-class way.” That conviction guides how we treat our clients—and how we treat each other. We respect, value and support each individual client and employee.<br /><br /><strong>We are a winning team</strong> - A great culture takes hard work. We succeed because we have passion and because we believe in doing the right thing even when it isn’t the easy thing. Our teams are disciplined, work well together, and execute consistently.<br /><br /><strong>Together we can make a difference</strong> - We accomplish extraordinary things every day. Our teams support various causes - fighting world hunger through the StepUp initiative and raising awareness for ALS during the Team Gleason Ice Bucket Challenge.&nbsp; Here, you’ll make a difference. </p>
</div></div>
      </div>
    </div>
  </section>