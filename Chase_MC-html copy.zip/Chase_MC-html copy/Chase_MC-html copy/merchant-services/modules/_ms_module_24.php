<!-- first form start -->
<div class="col col-xs-12 col-sm-6 col-md-5">
        <form id="referralForm" method="post" action="https://www.chasepaymentech.com/referralFormService" novalidate="novalidate">
        <!-- 
        <form id="referralForm" method="get"  action="">
         -->
          <!-- Type -->
          <input type="hidden" id="form.type" name="form.type" value="SF">
          
          <!-- Environment -->
          <input type="hidden" id="identification.environment" name="identification.environment" value="Prod">
          
          <!-- Success URL-->
          <input type="hidden" id="redirectOnSuccessUrl" name="redirectOnSuccessUrl" value="https://www.chasepaymentech.com/form_success.html">
          
          <!-- Error URL -->
          <input type="hidden" id="redirectOnErrorUrl" name="redirectOnErrorUrl" value="https://www.chasepaymentech.com/form_error.html">
          
          <!-- OID -->
          <input type="hidden" id="sf.oid" name="sf.oid" value="00D00000000heJJ">
          
          <!-- Campaign ID -->
          <input type="hidden" id="sf.Campaign_ID" name="sf.Campaign_ID" value="701000000009Fve">
          
          <!-- Custom Campaign ID-->
          <input type="hidden" id="sf.00N00000006yPWW" name="sf.00N00000006yPWW" value="Web Public Site Leads">
          
          <!-- Lead Source --> 
          <!-- <input id="sf.lead_source" name="sf.lead_source" type="hidden" value="CPS.com Apply">
          <input id="sf.lead_source" name="sf.lead_source" type="hidden" value="CPS Marketing"> --> 
          
          <!-- Agent ID -->
          <input type="hidden" id="sf.00N00000006yj3K" name="sf.00N00000006yj3K" value="424973082888">
          
          <!-- Agent Name -->
          <input type="hidden" id="sf.00N00000006yj3F" name="sf.00N00000006yj3F" value="CPS.COM">
          
          <!-- Referral Source ID -->
          <input type="hidden" id="sf.00N00000006yj3j" name="sf.00N00000006yj3j" value="D968">
          
          <!-- Referral Source -->
          <input type="hidden" id="sf.00N00000006ohHG" name="sf.00N00000006ohHG" value="CPS.com">
          
          <!-- Marketing Program -->
          <input type="hidden" id="sf.00N00000006pTAM" name="sf.00N00000006pTAM" value="CPS.com EPM Pricing">
          
          <!-- Marketing Program ID -->
          <input type="hidden" id="sf.00N00000006yj4I" name="sf.00N00000006yj4I" value="">
          
          <!-- Originating Offer -->
          <input type="hidden" id="sf.00N00000008iozv" name="sf.00N00000008iozv" value="Open Mercant Account">
          
          <!-- The 4 parameters for passing script 3.0  -->
          <input type="hidden" id="sf.00N00000008ipHV" name="sf.00N00000008ipHV" value="">
          <input type="hidden" id="sf.00N00000008iRz1" name="sf.00N00000008iRz1" value="">
          <input type="hidden" id="sf.00N00000008paPw" name="sf.00N00000008paPw" value="">
          <input type="hidden" id="sf.00N00000008q1AF" name="sf.00N00000008q1AF" value="">
          
          <div class="text-center form-top">
            <h3 align="center">BECOME A PARTNER</h3>
            <!-- <h4>
              Call <a class="visible-xs-inline" href="tel:1-800-708-3740">800.708.3740</a><span class="hidden-xs" href="tel:1-800-708-3740">800.708.3740</span> or complete 
              the short form below.
            </h4> -->
          </div>

          <div class="form-group form-group-sm">
          <span class="hidden error">Company Name is required</span>
            <label class="control-label" for="sf.company">Company Name</label>
            <input class="form-control" id="sf.company" name="sf.company"  title="Company Name is required" type="text" required="" aria-required="true">
          </div>
          
          <div class="col-md-12 col-sm-12 col-xs-12 form-group form-group-sm name-fields">
            <div class="row">
           <div class="col-sm-4 col-xs-12 form-first-name">
           <span class="hidden error">First Name is required</span>
           <label class="control-label" for="sf.first_name">First Name</label>
            <input class="form-control" id="sf.first_name" name="sf.first_name"  title="First name is required" type="text" required="" aria-required="true">
           </div>

			
			     <div class="col-sm-8 col-xs-12 form-last-name">
           <span class="hidden error">Last Name is required</span>
            <label class="control-label" for="sf.last_name">Last Name</label>
            <input class="form-control" id="sf.last_name" name="sf.last_name" title="Last name is required" type="text" required="" aria-required="true">
            </div>
          </div>
          </div>

          <div class="col-xs-12 form-group form-group-sm">
          <div class="row">
             <span class="hidden error">Title is required</span>
            <label class="control-label title" for="sf.country">Title</label>
            <select class="col-xs-8 form-control" id="sf.country" name="sf.country" title="Country is required" required="" aria-required="true">
              <option value="" selected="selected">Select</option>
              <option value="United States">United States</option>
              <option value="Canada">Canada</option>
            </select>
            </div>
          </div>

         <!--  <div class="form-group form-group-sm">
          <label class="control-label" for="sf.last_name">Last Name</label>
          <input class="form-control" id="sf.last_name" name="sf.last_name" placeholder="Last Name<" title="Last name is required" type="text" required="" aria-required="true">
                  </div> -->

          <div class="form-group form-group-sm">
          <span class="hidden error"> address is required</span>
            <label class="control-label" for="sf.company">Address</label>
            <input class="form-control" id="sf.company" name="sf.company" placeholder="Jobtitle" title="Company Name is required" type="text" required="" aria-required="true">
          </div>

          <div class="form-group form-group-sm">
          <span class="hidden error">city is required</span>
            <label class="control-label" for="sf.company">city</label>
            <input class="form-control" id="sf.company" name="sf.company" title="Company Name is required" type="text" required="" aria-required="true">
          </div>

          <!-- <div class="col-xs-12 form-group form-group-sm">
          <div class="row">
            <label class="control-label title" for="sf.country">State/Province</label>
            <select class="col-xs-4 form-control" id="sf.country" name="sf.country" title="Country is required" required="" aria-required="true">
              <option value="" selected="selected">Select</option>
              <option value="United States">United States</option>
              <option value="Canada">Canada</option>
            </select>
            </div>
          </div> -->

          <div class="col-xs-12 form-group form-group-sm">
          <div class="row">
             <span class="hidden error">A state is required</span>
            <label class="control-label title" for="sf.state">State/Province</label>
            <select class="col-xs-5 form-control" id="sf.state" name="sf.state" title="State/Province is required" required="" aria-required="true">
              <option value="" selected="selected">Select...</option>
              <option value="AL">Alabama</option>
              <option value="AK">Alaska</option>
              <option value="AZ">Arizona</option>
              <option value="AR">Arkansas</option>
              <option value="CA">California</option>
              <option value="CO">Colorado</option>
              <option value="CT">Connecticut</option>
              <option value="DE">Delaware</option>
              <option value="DC">District Of Columbia</option>
              <option value="FL">Florida</option>
              <option value="HI">Hawaii</option>
              <option value="GA">Georgia</option>
              <option value="ID">Idaho</option>
              <option value="IL">Illinois</option>
              <option value="IN">Indiana</option>
              <option value="IA">Iowa</option>
              <option value="KS">Kansas</option>
              <option value="KY">Kentucky</option>
              <option value="LA">Louisiana</option>
              <option value="ME">Maine</option>
              <option value="MD">Maryland</option>
              <option value="MA">Massachusetts</option>
              <option value="MI">Michigan</option>
              <option value="MN">Minnesota</option>
              <option value="MS">Mississippi</option>
              <option value="MO">Missouri</option>
              <option value="MT">Montana</option>
              <option value="NE">Nebraska</option>
              <option value="NV">Nevada</option>
              <option value="NH">New Hampshire</option>
              <option value="NJ">New Jersey</option>
              <option value="NM">New Mexico</option>
              <option value="NY">New York</option>
              <option value="NC">North Carolina</option>
              <option value="ND">North Dakota</option>
              <option value="OH">Ohio</option>
              <option value="OK">Oklahoma</option>
              <option value="OR">Oregon</option>
              <option value="PA">Pennsylvania</option>
              <option value="RI">Rhode Island</option>
              <option value="SC">South Carolina</option>
              <option value="SD">South Dakota</option>
              <option value="TN">Tennessee</option>
              <option value="TX">Texas</option>
              <option value="UT">Utah</option>
              <option value="VT">Vermont</option>
              <option value="VA">Virginia</option>
              <option value="WA">Washington</option>
              <option value="WV">West Virginia</option>
              <option value="WI">Wisconsin</option>
              <option value="WY">Wyoming</option>
              <option value="0"> </option>
              <option value="Alberta">Alberta</option>
              <option value="British Columbia">British Columbia</option>
              <option value="Manitoba">Manitoba</option>
              <option value="New Bunswick">New Bunswick</option>
              <option value="Newfoundland and Labrador">Newfoundland and Labrador</option>
              <option value="Northwest Territories">Northwest Territories</option>
              <option value="Nova Scotia">Nova Scotia</option>
              <option value="Nunavut">Nunavut</option>
              <option value="Ontario">Ontario</option>
              <option value="Prince Edward Island">Prince Edward Island</option>
              <option value="Quebec">Quebec</option>
              <option value="Saskatchewan">Saskatchewan</option>
              <option value="Yukon Territory">Yukon Territory</option>
            </select>
            </div>
          </div>
          
          <div class="col-xs-12 form-group form-group-sm">
          <div class="row">
          <span class="hidden error">A valid zip code is required</span>
            <label class="control-label title" for="sf.zip">Zip Code</label>
            <input class="col-xs-5 form-control" id="sf.zip" name="sf.zip" title="A valid email address is required" type="email" required="" aria-required="true">
            </div>
          </div>

          <div class="col-xs-12 form-group form-group-sm">
           <div class="row">
           <span class="hidden error">A valid telephone number is required</span>
            <label class="control-label title" for="sf.phone">Telephone Number</label>
            <input class="col-xs-5 form-control" id="sf.phone" name="sf.phone" title="A valid phone number is required" type="tel" required="" aria-required="true">
            </div>
          </div>

          <div class="col-xs-12 form-group form-group-sm">
          <div class="row">
          <span class="hidden error">A valid email address is required</span>
            <label class="control-label title" for="sf.email">Email Address</label>
            <input class="col-xs-5 form-control" id="sf.email" name="sf.email" title="A valid email address is required" type="email" required="" aria-required="true">
          </div>
          </div>

          <div class="col-xs-12 form-group form-group-sm">
          <div class="row">
          <span class="hidden error">A valid web address is required</span>
            <label class="control-label title" for="sf.web">Web Address</label>
            <input class="col-xs-5 form-control" id="sf.web" name="sf.web" title="A valid email address is required" type="email" required="" aria-required="true">
          </div>
          </div>

          

          <!-- <div class="form-group form-group-sm">
            <label class="control-label" for="sf.country">Country</label>
            <select class="form-control" id="sf.country" name="sf.country" title="Country is required" required="" aria-required="true">
              <option value="" selected="selected">Country</option>
              <option value="United States">United States</option>
              <option value="Canada">Canada</option>
            </select>
          </div> -->

         

          <div class="form-group form-group-sm">
          <span class="hidden error">A valid description is required</span>
           <label class="control-label" for="sf.description">Description of Business (and of products/services sold)</label>
           <textarea id="sf.description" name="sf.description" rows="3" class="form-control"></textarea>
         </div>

         <div class="form-group form-group-sm">
         <span class="hidden error">A valid description is required</span>
           <label class="control-label" for="sf.description">Please give a brief description of your proposed partnership</label>
           <textarea id="sf.description" name="sf.description" rows="3" class="form-control"></textarea>
         </div>

          <div class="text-center" align="center">
            <input type="submit" alt="Get Started" class="btn btn-primary btn-lg" value="GET STARTED">
          </div>

        </form>
      </div>
      <!-- first form end -->




