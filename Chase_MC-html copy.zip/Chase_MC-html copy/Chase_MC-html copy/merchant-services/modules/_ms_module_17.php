<div class="panel-group accordion-details" id="accordion">

   <div class="panel panel-default">

       <div class="panel-heading">
         <h4 class="panel-title">
         	<a class="accordion-toggle" data-toggle="collapse" data-parent="#accordion" 
         	href="#collapseone">Technical Details</a>
         </h4>
       </div>

       <div id="collapseone" class="col-xs-12 panel-collapse collapse">

         <div class="panel-body">
            <div class="col-md-6 col-sm-6 col-xs-12 accordion-part">

              <div class="accordion-inside col-xs-12">
	              <span class="col-xs-6">color</span>
	              <span class="col-xs-6">Chase Blue</span>
              </div>
              <div class="accordion-inside col-xs-12">
	              <span class="col-xs-6">Specs</span>
	              <span class="col-xs-6">5*5*2</span>
              </div>
              <div class="accordion-inside col-xs-12">
	              <span class="col-xs-6">Additional Hardware</span>
	              <span class="col-xs-6">Single Cable</span>
              </div>
              <div class="accordion-inside col-xs-12">
	              <span class="col-xs-6">Memory</span>
	              <span class="col-xs-6">144 MB Memory</span>
              </div>
              <div class="accordion-inside col-xs-12">
	              <span class="col-xs-6">Transaction Security</span>
	              <span class="col-xs-6">PCI PTS,TRSM</span>
              </div>
              <div class="accordion-inside col-xs-12">
	              <span class="col-xs-6">Additional Features</span>
	              <div class="col-xs-6">
		              <p>Anti-glare,backlit,color display</p>
		              <p>Tib/Tab Transactions and reports</p>
		              <p>High speed communication with dial back-up</p>
	              </div>
              </div>


            </div>
         </div>

       </div>

   </div>
</div>
