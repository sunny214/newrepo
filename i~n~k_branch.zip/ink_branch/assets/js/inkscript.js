 $(document).ready(function(){

 	var ink_heading=$('.left_text h1').text();
 	$('.main_header .container-fluid:eq(1) .nav ').before('<h1 class="nav_head">'+ink_heading+'</h1>');
 	$('.nav_head').css("display","none");	
    $(window).scroll(function() {
    	console.log($(this).scrollTop());
	if ($(this).scrollTop() >= 27){  
	    $('.main_header').addClass("sticky");
	    $('.nav_head').css("display","block");
	  }
	  else{
		    $('.main_header').removeClass("sticky");
		   $('.nav_head').css("display","none");	 
	     }
});
    });