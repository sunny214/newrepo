    <section class="introductionModule module-padding-medium-both">
      <div class="container">
        <div class="row">
          <div id="prog-details-welcome-intro" class="col-xs-12 col-sm-8 col-sm-offset-2">
            <article class="title-desc margin-bottom-md">
              <h2 id="intro__title" class="title-desc__title {{extraclass}}">Master core banking skills</h2>
              <p id="intro__desc" class="title-desc__desc delta header-font-family">You’ll learn modeling, accounting and credit analysis working on one of our teams: Middle Market Banking &amp; Specialized Industries, Credit Markets &amp; Treasury Services, Commercial Real Estate, International Banking and Corporate Client Banking &amp; Specialized Industries.</p>
            </article>
          </div>
        </div>
      </div>
    </section>
