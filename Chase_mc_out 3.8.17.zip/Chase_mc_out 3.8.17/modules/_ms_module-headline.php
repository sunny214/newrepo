<div class="module-bucket">
	<h2 class="moduleTitle">{title from title module}</h2>
</div>