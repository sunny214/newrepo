<section id="location-featured" class="featured module bottom-module-padding no-bottom-module-margin">
    <div class="container">
        <div class="row">
            <div class="col-xs-12 col-md-8 col-md-push-2">
                <div id="local-impact-intro">
                    <article class="title-desc margin-bottom-md">
                        <h2 id="intro__title" class="title-desc__title {{extraclass}}">Where yesterday meets tomorrow</h2>
                        <p id="intro__desc" class="title-desc__desc delta header-font-family">London’s history dates back over 2,000 years. From the Royals to the River, everything about it is
                            the stuff of legend. Today, it’s a technology-driven city, and we’re playing a key part in this
                            financial and commercial capital.</p>
                    </article>
                </div>
            </div>
        </div>
        <!-- Secondary featured locations -->
        <div id="local-impact" data-carousel="" data-resolution="{{$root.deviceResolution}}" data-carousel-mobile="true" data-carousel-tablet="false"
            data-carousel-desktop="false" class="row module carousel module-padding no-top-module-padding" data-carousel-control-color="red">
            <div id="local-impact-block" class="col-xs-12 col-sm-4 col-centered">
                <div class="item location-img-rounded">
                    <figure>
                        <img class="lazy img-responsive img-circle center-block" data-bttrlazyloading-xs-src="http://jpmcareers.jpmchase.net/careers/1320541894448/1320541894430.jpg"
                            alt="Local Impact 1" data-bttrlazyloading-sm-src="http://jpmcareers.jpmchase.net/careers/1320541894447/1320541894429.jpg"
                        />
                    </figure>
                    <span id="local-impact-block__title" class="delta">Connecting people to jobs</span>
                    <p id="local-impact-block__summary" class="small margin-top-xs">We’re proud to partner with Participle on the building of Backr; a service that uses social networks
                        to create connections and career opportunities between people living in Lambeth and small local businesses.</p>
                </div>
            </div>
            <div id="local-impact-block" class="col-xs-12 col-sm-4 col-centered">
                <div class="item location-img-rounded">
                    <figure>
                        <img class="lazy img-responsive img-circle center-block" data-bttrlazyloading-xs-src="http://jpmcareers.jpmchase.net/careers/1320541894339/1320541894321.jpg"
                            alt="Local Impact 2" data-bttrlazyloading-sm-src="http://jpmcareers.jpmchase.net/careers/1320541894338/1320541894320.jpg"
                        />
                    </figure>
                    <span id="local-impact-block__title" class="delta">Code for Good</span>
                    <p id="local-impact-block__summary" class="small margin-top-xs">Every year we invite students to come, spend time with us and participate in coding challenges that help
                        generate innovative solutions for non-profit organizations. </p>
                </div>
            </div>
            <div id="local-impact-block" class="col-xs-12 col-sm-4 col-centered">
                <div class="item location-img-rounded">
                    <figure>
                        <img class="lazy img-responsive img-circle center-block" data-bttrlazyloading-xs-src="http://jpmcareers.jpmchase.net/careers/1320541894412/1320541894394.jpg"
                            alt="Local Impact 3" data-bttrlazyloading-sm-src="http://jpmcareers.jpmchase.net/careers/1320541894411/1320541894393.jpg"
                        />
                    </figure>
                    <span id="local-impact-block__title" class="delta">Fighting world hunger, one step at a time</span>
                    <p id="local-impact-block__summary" class="small margin-top-xs">More than 83,000 employees across the globe have raised over $2 million for charities that feed the hungry
                        by ‘virtually walking’ from NY to Sydney. In London, we are supporting Oxfam.</p>
                </div>
            </div>
    </div>
    <!-- /Secondary featured -->
    </div>
</section>