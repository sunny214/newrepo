<section>
	<div id="event-listing">
		<div class="container student-events career-programs not-mobile">
			<section class="col-xs-12 col-sm-4 filter-section">
				<div class="events-filter">
					<div class="filter-row1">
						<span class="events-count">0</span>
						<span class="events-count-label" id="listing-header"> result</span>
					</div>
					<div style="clear: both;"></div>
					<div class="filter-row2">
						<i class="icon-search"><input id="search_form_submit" value="" type="submit"></i>
						<form id="search_form" name="careers_search"  action='/cm/ContentServer' method=get accept-charset="UTF-8">
							<input type=hidden name="pagename" value="search_driver" />
							<input type=hidden name="wrapper" value="true" />
							<input id="filters-search" placeholder="Search Careers site" name="q" type="text" class="search-input" />
						</form>
					</div>
					<div class="filter-row5">
						<div>
							<div class="filter-container type">
								<div style="height: 30px;" class="filter-section-header">
									<div id="d_filter-by-event-type" class="filter-button-label">Content type</div>
									<div class="filter-button-icon">
										<a href="javascript:;" class="search-accordion" style="text-decoration: none;">
											<span class="hide">
                                            	<i class="icon-plus"></i>
                                            </span>
											<span>
                                            	<i class="icon-minus"></i>
                                            </span>
										</a>
									</div>
								</div>
								<div style="clear:both;"></div>
								<div class="filter-options filter-triggers open">
									<div id="filter_Advice" class="filter-item-wrapper" style="">
										<input type="checkbox" name="filter" class="trigger event-type-filter" id="typeFilter0"
														value="Advice">
											<label class="checkbox" for="typeFilter0">Advice</label>
									</div>
									<div id="filter_Division" class="filter-item-wrapper " style="">
										<input type="checkbox" name="filter" class="trigger event-type-filter" id="typeFilter1"
														value="Division">
											<label class="checkbox" for="typeFilter1">Division</label>
									</div>
									<div id="filter_Event" class="filter-item-wrapper " style="">
										<input type="checkbox" name="filter" class="trigger event-type-filter" id="typeFilter2"
														value="Event">
											<label class="checkbox" for="typeFilter2">Event</label>
									</div>
									<div id="filter_Location" class="filter-item-wrapper " style="">
										<input type="checkbox" name="filter" class="trigger event-type-filter" id="typeFilter3"
														value="Location">
											<label class="checkbox" for="typeFilter3">Location</label>
									</div>
									<div id="filter_Program" class="filter-item-wrapper " style="">
										<input type="checkbox" name="filter" class="trigger event-type-filter" id="typeFilter4"
														value="Program">
											<label class="checkbox" for="typeFilter4">Program</label>
									</div>
								</div>
							</div>
						</div>
						<hr />
					</div>
				</div>
			</section>
			<div id="no-results" class="col-xs-12 col-sm-8 text-center no-results-message-section">
				<span class="no-search-results">
			<h2 id="no-results-title" class="no-results-title">We're sorry</h2>
			<p id="no-results-subtitle" class="no-results-subtitle">Currently, we don't offer an event that exactly matches your criteria. Please adjust your filters, and explore alternatives that may be of interest to you.</p>
		</span>
			</div>
		</div>
	</div>
</section>