<section class="adviceEventPromo module">   <!-- DM28 advice event promo  --> 
    
    <div class="container module-spacing-large">
    
	    <div class="row">
		   <div class="col-xs-12 col-sm-8 col-sm-offset-2 text-center">
			<h2 class="margin-bottom-md">Come meet our teams</h2>
	    		 <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Cras tincidunt pellentesque lorem, id suscipit dolor rutrum id. Morbi facilisi, sapien purus suscipit diet sapien id purus pretium id aliquam mi ullamcorper.</p>
			 <p class="module-padding-base-both">
			    <a id="browse-all-programs" class="btn btn-outline red" href="http://careers.jpmorgan.com/careers/programs">Browse all events</a>
			 </p>
		   </div>
	    </div>
    </div>
  
</section> 