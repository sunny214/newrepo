<div class="col-md-12 chase-customer">
    <div class="chase-data">
        <p>Seamless experience for customers and merchants</p>
	    <p>Open a Merchant Services Account today</p>
	    <button type="button" class="btn btn-primary">Get Started</button>
    </div>
</div>