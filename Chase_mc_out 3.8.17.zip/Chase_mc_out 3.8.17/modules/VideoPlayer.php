<section class="videoPlayerModule module-padding-medium-both">
  <div class="container">
    <div id="profiles-intro" class="row">
      <div class="col-xs-12 col-sm-10 col-sm-offset-1 text-center">
        <h2 id="intro__title" class="beta module-title">Video Title</h2>
      </div>
    </div>
  </div>
  <!-- BEGIN MOBILE VERSION -->
  <div class="container colnoleftpadding-xs colnorightpadding-xs">
    <div class="row">
      <div class="col-xs-12 padding-reset">
        <div class="mcarousel">
          <div id="whyus-impact-carousel__container" data-carousel="" data-resolution="{{$root.deviceResolution}}" data-carousel-mobile="true" data-carousel-tablet="true" data-carousel-desktop="true" data-pagination="true" data-autoplay="false" data-carousel-go-to-slide="$parent.carouselPos" class="row module carousel no-overflow no-module-padding no-bottom-module-margin max-width-control more-than-a-job carousel-control-color-red" data-ng-init="carouselPos = 0; showVideo = [];"><div id="profile-1" class="col-xs-12 padding-reset">
            <div class="item sticky-bottom">
              <figure data-ng-init="showVideo[0] = false;">
                <div id="profile_video__wrapper" class="carousel-video-wrapper">
                  <div class="video-containing-block">
                    <div class="video-inner-wrapper">
                      <video data-video-id="4722024897001"
                        data-account="1139173452001"
                        data-player="a6771937-047d-4f5f-88e6-a697b37b5456"
                        data-embed="default"
                        class="video-js"
                        controls
                      style="width: 100%; height: 100%; position: absolute; top: 0px; bottom: 0px; right: 0px; left: 0px;"></video>
                      <div class="playlistName playlist-active">
                        Alisa
                        <br />Technology
                        <br />Developer - Associate
                      </div>                    
                    </div>
                  </div>       
                </div>
                          
              </figure>
            </div>
          </div>
          <div id="profile-1" class="col-xs-12 padding-reset">
            <div class="item sticky-bottom">
              <figure data-ng-init="showVideo[1] = false;">
                <div id="profile_video__wrapper" class="carousel-video-wrapper">
                  <div class="video-containing-block">
                    <div class="video-inner-wrapper">
                      <video data-video-id="4949216608001"
                        data-account="1139173452001"
                        data-player="a6771937-047d-4f5f-88e6-a697b37b5456"
                        data-embed="default"
                        class="video-js"
                        controls
                      style="width: 100%; height: 100%; position: absolute; top: 0px; bottom: 0px; right: 0px; left: 0px;"></video>
                      <div class="playlistName playlist-active">
                        David
                        <br />Technology
                        <br />Developer - Associate
                      </div>                       
                    </div>
                  </div>               
                </div>
                
              </figure>
            </div>
          </div>
          <div id="profile-1" class="col-xs-12 padding-reset">
            <div class="item sticky-bottom">
              <figure data-ng-init="showVideo[2] = false;">
                <div id="profile_video__wrapper" class="carousel-video-wrapper">
                  <div class="video-containing-block">
                    <div class="video-inner-wrapper">
                      <video data-video-id="4660296827001"
                        data-account="1139173452001"
                        data-player="a6771937-047d-4f5f-88e6-a697b37b5456"
                        data-embed="default"
                        class="video-js"
                        controls
                      style="width: 100%; height: 100%; position: absolute; top: 0px; bottom: 0px; right: 0px; left: 0px;"></video>
                      <div class="playlistName playlist-active">
                        Chi
                        <br />Technology
                        <br />Developer - Associate
                      </div>                       
                    </div>
                  </div>              
                </div>
                
              </figure>
            </div>
          </div>
          <div id="profile-1" class="col-xs-12 padding-reset">
            <div class="item sticky-bottom">
              <figure data-ng-init="showVideo[3] = false;">
                <div id="profile_video__wrapper" class="carousel-video-wrapper">
                  <div class="video-containing-block">
                    <div class="video-inner-wrapper">
                    <video data-video="" class="brightcove-video video-js" data-video-id="4660223419001" data-autoplay="false" data-account="1139173452001" data-player="a6771937-047d-4f5f-88e6-a697b37b5456" data-embed="default" style="width: 100%; height: 100%; position: absolute; top: 0px; bottom: 0px; right: 0px; left: 0px;"></video>
                      <div class="playlistName playlist-active">
                        Charlotte
                        <br />Technology
                        <br />Developer - Associate
                      </div>                     
                  </div>
                </div>             
              </div>
              
            </figure>
          </div>
        </div>
        <div id="profile-1" class="col-xs-12 padding-reset">
          <div class="item sticky-bottom">
            <figure data-ng-init="showVideo[4] = false;">
              <div id="profile_video__wrapper" class="carousel-video-wrapper">
                <div class="video-containing-block">
                  <div class="video-inner-wrapper">
                  <video data-video="" class="brightcove-video video-js" data-video-id="4660223387001" data-autoplay="false" data-video-id="4660223419001" data-account="1139173452001" data-player="a6771937-047d-4f5f-88e6-a697b37b5456" data-embed="default" controls="" style="width: 100%; height: 100%; position: absolute; top: 0px; bottom: 0px; right: 0px; left: 0px;"></video>
                      <div class="playlistName playlist-active">
                        Milhaus
                        <br />Technology
                        <br />Developer - Associate
                      </div>                   
                </div>
              </div>             
            </div>
            
          </figure>
        </div>
      </div>

      <div id="profile-1" class="col-xs-12 padding-reset">
          <div class="item sticky-bottom">
            <figure data-ng-init="showVideo[4] = false;">
              <div id="profile_video__wrapper" class="carousel-video-wrapper">
                <div class="video-containing-block">
                  <div class="video-inner-wrapper">
                  <video data-video="" class="brightcove-video video-js" data-video-id="4443290346001" data-autoplay="false" data-video-id="4660223419001" data-account="1139173452001" data-player="a6771937-047d-4f5f-88e6-a697b37b5456" data-embed="default" controls="" style="width: 100%; height: 100%; position: absolute; top: 0px; bottom: 0px; right: 0px; left: 0px;"></video>
                      <div class="playlistName playlist-active">
                        Milhaus
                        <br />Technology
                        <br />Developer - Associate
                      </div>                   
                </div>
              </div>          
            </div>
            
          </figure>
        </div>
      </div>
      
    <!-- END MOBILE VERSION -->

  </div>
</div>
</div>
</div>
</div>
<!-- /carousel -->
<!-- BEGIN HORIZONTAL PLAYLIST SCROLL CONTAINER DESKTOP -->
<div id="scrollContainer" class="hidden-xs">
<div class="arrow-left">&#10094;</div>
<div class="arrow-right">&#10095;</div>
<div class="playlist">

<div class="carousel-controls-morethanjob" ng-init="carouselPos = 0;">
  <div class="box playlist-box-active">
    <a class="" data-ng-class="{'is-active': carouselPos ===0 }" data-ng-click="$parent.videoCarousel = true; $parent.carouselPos = 0;carouselPos = 0; showVideo = false;">
      <div class="thumbnailPlusname">
        <div class="playlistThumbnailphoto"><img src="assets/images/dm12-playlist-thumbnail-photo.png" alt="" width="28" height="28" />
        </div>
        <div class="playlistName playlist-active">Alisa</div>
        <h4 class="playlistDept playlist-active">Technology</h4>
        <h4 class="playlistJobtitle playlist-active">Developer - Associate</h4>
    </div>
   </a>
  </div>
  <div class="box">
    <a class="" data-ng-class="{'is-active': carouselPos ===1 }" data-ng-click="$parent.videoCarousel = true; $parent.carouselPos = 1;carouselPos = 1; showVideo = false;">
      <div class="thumbnailPlusname">
        <div class="playlistThumbnailphoto"><img src="assets/images/dm12-playlist-thumbnail-photo.png" alt="" width="28" height="28" />
        </div>
        <div class="playlistName">David</div>
        <h4 class="playlistDept">Technology</h4>
        <h4 class="playlistJobtitle">Developer - Associate</h4>   
      <div class="separator"></div>
    </div>
   </a>
  </div>
  <div class="box">
    <a class="" data-ng-class="{'is-active': carouselPos ===2 }" data-ng-click="$parent.videoCarousel = true; $parent.carouselPos = 2;carouselPos = 2; showVideo = false;">
      <div class="thumbnailPlusname">
        <div class="playlistThumbnailphoto"><img src="assets/images/dm12-playlist-thumbnail-photo.png" alt="" width="28" height="28" />
        </div>
        <div class="playlistName">Chi</div>
        <h4 class="playlistDept">Technology</h4>
        <h4 class="playlistJobtitle">Developer - Associate</h4>
      <div class="separator"></div>
    </div>
   </a>
  </div>
   <div class="box">
    <a class="" data-ng-class="{'is-active': carouselPos ===3 }" data-ng-click="$parent.videoCarousel = true; $parent.carouselPos = 3;carouselPos = 3; showVideo = false;">
      <div class="thumbnailPlusname">
        <div class="playlistThumbnailphoto"><img src="assets/images/dm12-playlist-thumbnail-photo.png" alt="" width="28" height="28" />
        </div>
        <div class="playlistName">Charlotte</div>
        <h4 class="playlistDept">Technology</h4>
        <h4 class="playlistJobtitle">Developer - Associate</h4>
      <div class="separator"></div>
    </div>
   </a>
  </div>
  <div class="box">
    <a class="" data-ng-class="{'is-active': carouselPos ===4 }" data-ng-click="$parent.videoCarousel = true; $parent.carouselPos = 4;carouselPos = 4; showVideo = false;">
      <div class="thumbnailPlusname">
        <div class="playlistThumbnailphoto"><img src="assets/images/dm12-playlist-thumbnail-photo.png" alt="" width="28" height="28" />
        </div>
        <div class="playlistName">Milhaus</div>
        <h4 class="playlistDept">Technology</h4>
        <h4 class="playlistJobtitle">Developer - Associate</h4>
      <div class="separator"></div>
    </div>
   </a> 
</div>
<div class="box">
    <a class="" data-ng-class="{'is-active': carouselPos ===4 }" data-ng-click="$parent.videoCarousel = true; $parent.carouselPos = 4;carouselPos = 4; showVideo = false;">
      <div class="thumbnailPlusname">
        <div class="playlistThumbnailphoto"><img src="assets/images/dm12-playlist-thumbnail-photo.png" alt="" width="28" height="28" />
        </div>
        <div class="playlistName">Milhaus</div>
        <h4 class="playlistDept">Technology</h4>
        <h4 class="playlistJobtitle">Developer - Associate</h4>
      <div class="separator"></div>
    </div>
   </a> 
</div>

<!-- END HORIZONTAL PLAYLIST SCROLL CONTAINER DESKTOP -->

</div>
</div>
</div>
</div>

</section>
