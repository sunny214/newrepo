/**
 * @preserve FastClick: polyfill to remove click delays on browsers with touch UIs.
 *
 * @codingstandard ftlabs-jsv2
 * @copyright The Financial Times Limited [All Rights Reserved]
 * @license MIT License (see LICENSE.txt)
 */
/*!
 * Platform.js v1.3.0 <http://mths.be/platform>
 * Copyright 2010-2015 John-David Dalton <http://allyoucanleet.com/>
 * Available under MIT license <http://mths.be/mit>
 */
(function(a) {
    function i(b) {
        return typeof h[b] == "function" && (h[b] = h[b](a, d, e)), h[b]
    }

    function j(b, c, f) {
        h[b] = f ? c(a, d, e) : c
    }

    function k(a, b) {
        var d = !1,
            e = a.charAt(0).toUpperCase() + a.slice(1),
            f = c.length,
            g = b.style;
        if (typeof g[a] == "string") d = !0;
        else
            while (f--)
                if (typeof g[c[f] + e] == "string") {
                    d = !0;
                    break
                } return d
    }

    function l(a) {
        if (a)
            while (a.lastChild) a.removeChild(a.lastChild);
        return a
    }

    function m(a, c) {
        var d = typeof a[c];
        return d == "object" ? !!a[c] : !b[d]
    }
    var b = {
            "boolean": 1,
            number: 1,
            string: 1,
            "undefined": 1
        },
        c = ["Webkit", "Moz", "O", "ms", "Khtml"],
        d = m(a, "document") && a.document,
        e = d && m(d, "createElement") && d.createElement("DiV"),
        f = typeof exports == "object" && exports,
        g = typeof module == "object" && module,
        h = {};
    i.add = j, i.clearElement = l, i.cssprop = k, i.isHostType = m, i._tests = h, i.add("dom", function(a, b, c) {
        return b && c && m(a, "location") && m(b, "documentElement") && m(b, "getElementById") && m(b, "getElementsByName") && m(b, "getElementsByTagName") && m(b, "createComment") && m(b, "createElement") && m(b, "createTextNode") && m(c, "appendChild") && m(c, "insertBefore") && m(c, "removeChild") && m(c, "getAttribute") && m(c, "setAttribute") && m(c, "removeAttribute") && m(c, "style") && typeof c.style.cssText == "string"
    });
    try {
        document.execCommand("BackgroundImageCache", !1, !0)
    } catch (n) {}
    typeof define == "function" && typeof define.amd == "object" && define.amd ? define("has", [], function() {
        return i
    }) : f ? g && g.exports == f ? (g.exports = i).has = i : f.has = i : a.has = i
})(this), Number.isNaN || function(a) {
        var b = function() {
                try {
                    var a = {},
                        b = Object.defineProperty,
                        c = b(a, a, a) && b
                } catch (d) {}
                return c
            }(),
            c = a.isNaN,
            d = function(a) {
                return typeof a == "number" && c(a)
            };
        b ? b(Number, "isNaN", {
            value: d,
            configurable: !0,
            writable: !0
        }) : Number.isNaN = d
    }(this), define("isnan", function() {}), define("amd/polyfills", ["isnan"], function() {}), ! function(a) {
        "function" == typeof define && define.amd ? define("slick", ["jquery"], a) : "undefined" != typeof exports ? module.exports = a(require("jquery")) : a(jQuery)
    }(function(a) {
        var b = window.Slick || {};
        b = function() {
            function b(b, d) {
                var e, f, g = this;
                if (g.defaults = {
                        accessibility: !0,
                        adaptiveHeight: !1,
                        appendArrows: a(b),
                        appendDots: a(b),
                        arrows: !0,
                        asNavFor: null,
                        prevArrow: '<button type="button" data-role="none" class="slick-prev" aria-label="previous" tabindex="-1" role="button">Previous</button>',
                        nextArrow: '<button type="button" data-role="none" class="slick-next" aria-label="next" tabindex="-1" role="button">Next</button>',
                        autoplay: !1,
                        autoplaySpeed: 3e3,
                        centerMode: !1,
                        centerPadding: "50px",
                        cssEase: "ease",
                        customPaging: function(a, b) {
                            return '<button type="button" class="chaseanalytics-track-link" data-role="none" role="button" aria-required="false" tabindex="-1" data-pt-name="cm_' + (b + 1) + '">Slide ' + (b + 1) + "</button>"
                        },
                        dots: !1,
                        dotsClass: "slick-dots",
                        draggable: !0,
                        easing: "linear",
                        fade: !1,
                        focusOnSelect: !1,
                        infinite: !0,
                        initialSlide: 0,
                        lazyLoad: "ondemand",
                        onBeforeChange: null,
                        onAfterChange: null,
                        onInit: null,
                        onReInit: null,
                        onSetPosition: null,
                        pauseOnHover: !0,
                        pauseOnDotsHover: !1,
                        respondTo: "window",
                        responsive: null,
                        rtl: !1,
                        slide: "div",
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        speed: 500,
                        swipe: !0,
                        swipeToSlide: !1,
                        touchMove: !0,
                        touchThreshold: 5,
                        useCSS: !0,
                        variableWidth: !1,
                        vertical: !1,
                        waitForAnimate: !0
                    }, g.initials = {
                        animating: !1,
                        dragging: !1,
                        autoPlayTimer: null,
                        currentDirection: 0,
                        currentLeft: null,
                        currentSlide: 0,
                        direction: 1,
                        $dots: null,
                        listWidth: null,
                        listHeight: null,
                        loadIndex: 0,
                        $nextArrow: null,
                        $prevArrow: null,
                        slideCount: null,
                        slideWidth: null,
                        $slideTrack: null,
                        $slides: null,
                        sliding: !1,
                        slideOffset: 0,
                        swipeLeft: null,
                        $list: null,
                        touchObject: {},
                        transformsEnabled: !1
                    }, a.extend(g, g.initials), g.activeBreakpoint = null, g.animType = null, g.animProp = null, g.breakpoints = [], g.breakpointSettings = [], g.cssTransitions = !1, g.paused = !1, g.positionProp = null, g.respondTo = null, g.shouldClick = !0, g.$slider = a(b), g.$slidesCache = null, g.transformType = null, g.transitionType = null, g.windowWidth = 0, g.windowTimer = null, g.options = a.extend({}, g.defaults, d), g.currentSlide = g.options.initialSlide, g.originalSettings = g.options, e = g.options.responsive || null, e && e.length > -1) {
                    g.respondTo = g.options.respondTo || "window";
                    for (f in e) e.hasOwnProperty(f) && (g.breakpoints.push(e[f].breakpoint), g.breakpointSettings[e[f].breakpoint] = e[f].settings);
                    g.breakpoints.sort(function(a, b) {
                        return b - a
                    })
                }
                g.autoPlay = a.proxy(g.autoPlay, g), g.autoPlayClear = a.proxy(g.autoPlayClear, g), g.changeSlide = a.proxy(g.changeSlide, g), g.clickHandler = a.proxy(g.clickHandler, g), g.selectHandler = a.proxy(g.selectHandler, g), g.setPosition = a.proxy(g.setPosition, g), g.swipeHandler = a.proxy(g.swipeHandler, g), g.dragHandler = a.proxy(g.dragHandler, g), g.keyHandler = a.proxy(g.keyHandler, g), g.autoPlayIterator = a.proxy(g.autoPlayIterator, g), g.instanceUid = c++, g.htmlExpr = /^(?:\s*(<[\w\W]+>)[^>]*)$/, g.init(), g.checkResponsive()
            }
            var c = 0;
            return b
        }(), b.prototype.addSlide = function(b, c, d) {
            var e = this;
            if ("boolean" == typeof c) d = c, c = null;
            else if (0 > c || c >= e.slideCount) return !1;
            e.unload(), "number" == typeof c ? 0 === c && 0 === e.$slides.length ? a(b).appendTo(e.$slideTrack) : d ? a(b).insertBefore(e.$slides.eq(c)) : a(b).insertAfter(e.$slides.eq(c)) : d === !0 ? a(b).prependTo(e.$slideTrack) : a(b).appendTo(e.$slideTrack), e.$slides = e.$slideTrack.children(this.options.slide), e.$slideTrack.children(this.options.slide).detach(), e.$slideTrack.append(e.$slides), e.$slides.each(function(b, c) {
                a(c).attr("index", b)
            }), e.$slidesCache = e.$slides, e.reinit()
        }, b.prototype.animateSlide = function(b, c) {
            var d = {},
                e = this;
            if (1 === e.options.slidesToShow && e.options.adaptiveHeight === !0 && e.options.vertical === !1) {
                var f = e.$slides.eq(e.currentSlide).outerHeight(!0);
                e.$list.animate({
                    height: f
                }, e.options.speed)
            }
            e.options.rtl === !0 && e.options.vertical === !1 && (b = -b), e.transformsEnabled === !1 ? e.options.vertical === !1 ? e.$slideTrack.animate({
                left: b
            }, e.options.speed, e.options.easing, c) : e.$slideTrack.animate({
                top: b
            }, e.options.speed, e.options.easing, c) : e.cssTransitions === !1 ? a({
                animStart: e.currentLeft
            }).animate({
                animStart: b
            }, {
                duration: e.options.speed,
                easing: e.options.easing,
                step: function(a) {
                    e.options.vertical === !1 ? (d[e.animType] = "translate(" + a + "px, 0px)", e.$slideTrack.css(d)) : (d[e.animType] = "translate(0px," + a + "px)", e.$slideTrack.css(d))
                },
                complete: function() {
                    c && c.call()
                }
            }) : (e.applyTransition(), d[e.animType] = e.options.vertical === !1 ? "translate3d(" + b + "px, 0px, 0px)" : "translate3d(0px," + b + "px, 0px)", e.$slideTrack.css(d), c && setTimeout(function() {
                e.disableTransition(), c.call()
            }, e.options.speed))
        }, b.prototype.asNavFor = function(b) {
            var c = this,
                d = null != c.options.asNavFor ? a(c.options.asNavFor).getSlick() : null;
            null != d && d.slideHandler(b, !0)
        }, b.prototype.applyTransition = function(a) {
            var b = this,
                c = {};
            c[b.transitionType] = b.options.fade === !1 ? b.transformType + " " + b.options.speed + "ms " + b.options.cssEase : "opacity " + b.options.speed + "ms " + b.options.cssEase, b.options.fade === !1 ? b.$slideTrack.css(c) : b.$slides.eq(a).css(c)
        }, b.prototype.autoPlay = function() {
            var a = this;
            a.autoPlayTimer && clearInterval(a.autoPlayTimer), a.slideCount > a.options.slidesToShow && a.paused !== !0 && (a.autoPlayTimer = setInterval(a.autoPlayIterator, a.options.autoplaySpeed))
        }, b.prototype.autoPlayClear = function() {
            var a = this;
            a.autoPlayTimer && clearInterval(a.autoPlayTimer)
        }, b.prototype.autoPlayIterator = function() {
            var a = this;
            a.options.infinite === !1 ? 1 === a.direction ? (a.currentSlide + 1 === a.slideCount - 1 && (a.direction = 0), a.slideHandler(a.currentSlide + a.options.slidesToScroll)) : (a.currentSlide - 1 === 0 && (a.direction = 1), a.slideHandler(a.currentSlide - a.options.slidesToScroll)) : a.slideHandler(a.currentSlide + a.options.slidesToScroll)
        }, b.prototype.buildArrows = function() {
            var b = this;
            b.options.arrows === !0 && b.slideCount > b.options.slidesToShow && (b.$prevArrow = a(b.options.prevArrow), b.$nextArrow = a(b.options.nextArrow), b.htmlExpr.test(b.options.prevArrow) && b.$prevArrow.appendTo(b.options.appendArrows), b.htmlExpr.test(b.options.nextArrow) && b.$nextArrow.appendTo(b.options.appendArrows), b.options.infinite !== !0 && b.$prevArrow.addClass("slick-disabled"))
        }, b.prototype.buildDots = function() {
            var b, c, d = this;
            if (d.options.dots === !0 && d.slideCount > d.options.slidesToShow) {
                for (c = '<ul class="' + d.options.dotsClass + '">', b = 0; b <= d.getDotCount(); b += 1) c += "<li>" + d.options.customPaging.call(this, d, b) + "</li>";
                c += "</ul>", d.$dots = a(c).appendTo(d.options.appendDots), d.$dots.find("li").first().addClass("slick-active")
            }
        }, b.prototype.buildOut = function() {
            var b = this;
            b.$slides = b.$slider.children(b.options.slide + ":not(.slick-cloned)").addClass("slick-slide"), b.slideCount = b.$slides.length, b.$slides.each(function(b, c) {
                a(c).attr("index", b)
            }), b.$slidesCache = b.$slides, b.$slider.addClass("slick-slider"), b.$slideTrack = 0 === b.slideCount ? a('<div class="slick-track"/>').appendTo(b.$slider) : b.$slides.wrapAll('<div class="slick-track"/>').parent(), b.$list = b.$slideTrack.wrap('<div class="slick-list"/>').parent(), b.$slideTrack.css("opacity", 0), b.options.centerMode === !0 && (b.options.slidesToScroll = 1), a("img[data-lazy]", b.$slider).not("[src]").addClass("slick-loading"), b.setupInfinite(), b.buildArrows(), b.buildDots(), b.updateDots(), b.options.accessibility === !0 && b.$list.prop("tabIndex", 0), b.setSlideClasses("number" == typeof this.currentSlide ? this.currentSlide : 0), b.options.draggable === !0 && b.$list.addClass("draggable")
        }, b.prototype.checkResponsive = function() {
            var b, c, d, e = this,
                f = e.$slider.width(),
                g = window.innerWidth || a(window).width();
            if ("window" === e.respondTo ? d = g : "slider" === e.respondTo ? d = f : "min" === e.respondTo && (d = Math.min(g, f)), e.originalSettings.responsive && e.originalSettings.responsive.length > -1 && null !== e.originalSettings.responsive) {
                c = null;
                for (b in e.breakpoints) e.breakpoints.hasOwnProperty(b) && d < e.breakpoints[b] && (c = e.breakpoints[b]);
                null !== c ? null !== e.activeBreakpoint ? c !== e.activeBreakpoint && (e.activeBreakpoint = c, e.options = a.extend({}, e.originalSettings, e.breakpointSettings[c]), e.refresh()) : (e.activeBreakpoint = c, e.options = a.extend({}, e.originalSettings, e.breakpointSettings[c]), e.refresh()) : null !== e.activeBreakpoint && (e.activeBreakpoint = null, e.options = e.originalSettings, e.refresh())
            }
        }, b.prototype.changeSlide = function(b, c) {
            var d, e, f, g, h, j = this,
                k = a(b.target);
            switch (k.is("a") && b.preventDefault(), f = j.slideCount % j.options.slidesToScroll !== 0, d = f ? 0 : (j.slideCount - j.currentSlide) % j.options.slidesToScroll, b.data.message) {
                case "previous":
                    e = 0 === d ? j.options.slidesToScroll : j.options.slidesToShow - d, j.slideCount > j.options.slidesToShow && j.slideHandler(j.currentSlide - e, !1, c);
                    break;
                case "next":
                    e = 0 === d ? j.options.slidesToScroll : d, j.slideCount > j.options.slidesToShow && j.slideHandler(j.currentSlide + e, !1, c);
                    break;
                case "index":
                    var l = 0 === b.data.index ? 0 : b.data.index || a(b.target).parent().index() * j.options.slidesToScroll;
                    if (g = j.getNavigableIndexes(), h = 0, g[l] && g[l] === l)
                        if (l > g[g.length - 1]) l = g[g.length - 1];
                        else
                            for (var m in g) {
                                if (l < g[m]) {
                                    l = h;
                                    break
                                }
                                h = g[m]
                            }
                        j.slideHandler(l, !1, c);
                default:
                    return
            }
        }, b.prototype.clickHandler = function(a) {
            var b = this;
            b.shouldClick === !1 && (a.stopImmediatePropagation(), a.stopPropagation(), a.preventDefault())
        }, b.prototype.destroy = function() {
            var b = this;
            b.autoPlayClear(), b.touchObject = {}, a(".slick-cloned", b.$slider).remove(), b.$dots && b.$dots.remove(), b.$prevArrow && "object" != typeof b.options.prevArrow && b.$prevArrow.remove(), b.$nextArrow && "object" != typeof b.options.nextArrow && b.$nextArrow.remove(), b.$slides.parent().hasClass("slick-track") && b.$slides.unwrap().unwrap(), b.$slides.removeClass("slick-slide slick-active slick-center slick-visible").removeAttr("index").css({
                position: "",
                left: "",
                top: "",
                zIndex: "",
                opacity: "",
                width: ""
            }), b.$slider.removeClass("slick-slider"), b.$slider.removeClass("slick-initialized"), b.$list.off(".slick"), a(window).off(".slick-" + b.instanceUid), a(document).off(".slick-" + b.instanceUid)
        }, b.prototype.disableTransition = function(a) {
            var b = this,
                c = {};
            c[b.transitionType] = "", b.options.fade === !1 ? b.$slideTrack.css(c) : b.$slides.eq(a).css(c)
        }, b.prototype.fadeSlide = function(a, b, c) {
            var d = this;
            d.cssTransitions === !1 ? (d.$slides.eq(b).css({
                zIndex: 1e3
            }), d.$slides.eq(b).animate({
                opacity: 1
            }, d.options.speed, d.options.easing, c), d.$slides.eq(a).animate({
                opacity: 0
            }, d.options.speed, d.options.easing)) : (d.applyTransition(b), d.applyTransition(a), d.$slides.eq(b).css({
                opacity: 1,
                zIndex: 1e3
            }), d.$slides.eq(a).css({
                opacity: 0
            }), c && setTimeout(function() {
                d.disableTransition(b), d.disableTransition(a), c.call()
            }, d.options.speed))
        }, b.prototype.filterSlides = function(a) {
            var b = this;
            null !== a && (b.unload(), b.$slideTrack.children(this.options.slide).detach(), b.$slidesCache.filter(a).appendTo(b.$slideTrack), b.reinit())
        }, b.prototype.getCurrent = function() {
            var a = this;
            return a.currentSlide
        }, b.prototype.getDotCount = function() {
            var a = this,
                b = 0,
                c = 0,
                d = 0;
            if (a.options.infinite === !0) d = Math.ceil(a.slideCount / a.options.slidesToScroll);
            else
                for (; b < a.slideCount;) ++d, b = c + a.options.slidesToShow, c += a.options.slidesToScroll <= a.options.slidesToShow ? a.options.slidesToScroll : a.options.slidesToShow;
            return d - 1
        }, b.prototype.getLeft = function(a) {
            var b, c, d, e = this,
                f = 0;
            return e.slideOffset = 0, c = e.$slides.first().outerHeight(), e.options.infinite === !0 ? (e.slideCount > e.options.slidesToShow && (e.slideOffset = e.slideWidth * e.options.slidesToShow * -1, f = c * e.options.slidesToShow * -1), e.slideCount % e.options.slidesToScroll !== 0 && a + e.options.slidesToScroll > e.slideCount && e.slideCount > e.options.slidesToShow && (a > e.slideCount ? (e.slideOffset = (e.options.slidesToShow - (a - e.slideCount)) * e.slideWidth * -1, f = (e.options.slidesToShow - (a - e.slideCount)) * c * -1) : (e.slideOffset = e.slideCount % e.options.slidesToScroll * e.slideWidth * -1, f = e.slideCount % e.options.slidesToScroll * c * -1))) : a + e.options.slidesToShow > e.slideCount && (e.slideOffset = (a + e.options.slidesToShow - e.slideCount) * e.slideWidth, f = (a + e.options.slidesToShow - e.slideCount) * c), e.slideCount <= e.options.slidesToShow && (e.slideOffset = 0, f = 0), e.options.centerMode === !0 && e.options.infinite === !0 ? e.slideOffset += e.slideWidth * Math.floor(e.options.slidesToShow / 2) - e.slideWidth : e.options.centerMode === !0 && (e.slideOffset = 0, e.slideOffset += e.slideWidth * Math.floor(e.options.slidesToShow / 2)), b = e.options.vertical === !1 ? a * e.slideWidth * -1 + e.slideOffset : a * c * -1 + f, e.options.variableWidth === !0 && (d = e.$slideTrack.children(".slick-slide").eq(e.slideCount <= e.options.slidesToShow || e.options.infinite === !1 ? a : a + e.options.slidesToShow), b = d[0] ? -1 * d[0].offsetLeft : 0, e.options.centerMode === !0 && (d = e.$slideTrack.children(".slick-slide").eq(e.options.infinite === !1 ? a : a + e.options.slidesToShow + 1), b = d[0] ? -1 * d[0].offsetLeft : 0, b += (e.$list.width() - d.outerWidth()) / 2)), b
        }, b.prototype.getNavigableIndexes = function() {
            for (var a = this, b = 0, c = 0, d = []; b < a.slideCount;) d.push(b), b = c + a.options.slidesToScroll, c += a.options.slidesToScroll <= a.options.slidesToShow ? a.options.slidesToScroll : a.options.slidesToShow;
            return d
        }, b.prototype.getSlideCount = function() {
            var b, c = this;
            if (c.options.swipeToSlide === !0) {
                var d = null;
                return c.$slideTrack.find(".slick-slide").each(function(b, e) {
                    return e.offsetLeft + a(e).outerWidth() / 2 > -1 * c.swipeLeft ? (d = e, !1) : void 0
                }), b = Math.abs(a(d).attr("index") - c.currentSlide)
            }
            return c.options.slidesToScroll
        }, b.prototype.init = function() {
            var b = this;
            a(b.$slider).hasClass("slick-initialized") || (a(b.$slider).addClass("slick-initialized"), b.buildOut(), b.setProps(), b.startLoad(), b.loadSlider(), b.initializeEvents(), b.updateArrows(), b.updateDots()), null !== b.options.onInit && b.options.onInit.call(this, b)
        }, b.prototype.initArrowEvents = function() {
            var a = this;
            a.options.arrows === !0 && a.slideCount > a.options.slidesToShow && (a.$prevArrow.on("click.slick", {
                message: "previous"
            }, a.changeSlide), a.$nextArrow.on("click.slick", {
                message: "next"
            }, a.changeSlide))
        }, b.prototype.initDotEvents = function() {
            var b = this;
            b.options.dots === !0 && b.slideCount > b.options.slidesToShow && a("li", b.$dots).on("click.slick", {
                message: "index"
            }, b.changeSlide), b.options.dots === !0 && b.options.pauseOnDotsHover === !0 && b.options.autoplay === !0 && a("li", b.$dots).on("mouseenter.slick", function() {
                b.paused = !0, b.autoPlayClear()
            }).on("mouseleave.slick", function() {
                b.paused = !1, b.autoPlay()
            })
        }, b.prototype.initializeEvents = function() {
            var b = this;
            b.initArrowEvents(), b.initDotEvents(), b.$list.on("touchstart.slick mousedown.slick", {
                action: "start"
            }, b.swipeHandler), b.$list.on("touchmove.slick mousemove.slick", {
                action: "move"
            }, b.swipeHandler), b.$list.on("touchend.slick mouseup.slick", {
                action: "end"
            }, b.swipeHandler), b.$list.on("touchcancel.slick mouseleave.slick", {
                action: "end"
            }, b.swipeHandler), b.$list.on("click.slick", b.clickHandler), b.options.pauseOnHover === !0 && b.options.autoplay === !0 && (b.$list.on("mouseenter.slick", function() {
                b.paused = !0, b.autoPlayClear()
            }), b.$list.on("mouseleave.slick", function() {
                b.paused = !1, b.autoPlay()
            })), b.options.accessibility === !0 && b.$list.on("keydown.slick", b.keyHandler), b.options.focusOnSelect === !0 && a(b.options.slide, b.$slideTrack).on("click.slick", b.selectHandler), a(window).on("orientationchange.slick.slick-" + b.instanceUid, function() {
                b.checkResponsive(), b.setPosition()
            }), a(window).on("resize.slick.slick-" + b.instanceUid, function() {
                a(window).width() !== b.windowWidth && (clearTimeout(b.windowDelay), b.windowDelay = window.setTimeout(function() {
                    b.windowWidth = a(window).width(), b.checkResponsive(), b.setPosition()
                }, 50))
            }), a("*[draggable!=true]", b.$slideTrack).on("dragstart", function(a) {
                a.preventDefault()
            }), a(window).on("load.slick.slick-" + b.instanceUid, b.setPosition), a(document).on("ready.slick.slick-" + b.instanceUid, b.setPosition)
        }, b.prototype.initUI = function() {
            var a = this;
            a.options.arrows === !0 && a.slideCount > a.options.slidesToShow && (a.$prevArrow.show(), a.$nextArrow.show()), a.options.dots === !0 && a.slideCount > a.options.slidesToShow && a.$dots.show(), a.options.autoplay === !0 && a.autoPlay()
        }, b.prototype.keyHandler = function(a) {
            var b = this;
            37 === a.keyCode && b.options.accessibility === !0 ? b.changeSlide({
                data: {
                    message: "previous"
                }
            }) : 39 === a.keyCode && b.options.accessibility === !0 && b.changeSlide({
                data: {
                    message: "next"
                }
            })
        }, b.prototype.lazyLoad = function() {
            function b(b) {
                a("img[data-lazy]", b).each(function() {
                    var b = a(this),
                        c = a(this).attr("data-lazy");
                    b.load(function() {
                        b.animate({
                            opacity: 1
                        }, 200)
                    }).css({
                        opacity: 0
                    }).attr("src", c).removeAttr("data-lazy").removeClass("slick-loading")
                })
            }
            var c, d, e, f, g = this;
            g.options.centerMode === !0 ? g.options.infinite === !0 ? (e = g.currentSlide + (g.options.slidesToShow / 2 + 1), f = e + g.options.slidesToShow + 2) : (e = Math.max(0, g.currentSlide - (g.options.slidesToShow / 2 + 1)), f = 2 + (g.options.slidesToShow / 2 + 1) + g.currentSlide) : (e = g.options.infinite ? g.options.slidesToShow + g.currentSlide : g.currentSlide, f = e + g.options.slidesToShow, g.options.fade === !0 && (e > 0 && e--, f <= g.slideCount && f++)), c = g.$slider.find(".slick-slide").slice(e, f), b(c), g.slideCount <= g.options.slidesToShow ? (d = g.$slider.find(".slick-slide"), b(d)) : g.currentSlide >= g.slideCount - g.options.slidesToShow ? (d = g.$slider.find(".slick-cloned").slice(0, g.options.slidesToShow), b(d)) : 0 === g.currentSlide && (d = g.$slider.find(".slick-cloned").slice(-1 * g.options.slidesToShow), b(d))
        }, b.prototype.loadSlider = function() {
            var a = this;
            a.setPosition(), a.$slideTrack.css({
                opacity: 1
            }), a.$slider.removeClass("slick-loading"), a.initUI(), "progressive" === a.options.lazyLoad && a.progressiveLazyLoad()
        }, b.prototype.postSlide = function(a) {
            var b = this;
            null !== b.options.onAfterChange && b.options.onAfterChange.call(this, b, a), b.animating = !1, b.setPosition(), b.swipeLeft = null, b.options.autoplay === !0 && b.paused === !1 && b.autoPlay()
        }, b.prototype.progressiveLazyLoad = function() {
            var b, c, d = this;
            b = a("img[data-lazy]", d.$slider).length, b > 0 && (c = a("img[data-lazy]", d.$slider).first(), c.attr("src", c.attr("data-lazy")).removeClass("slick-loading").load(function() {
                c.removeAttr("data-lazy"), d.progressiveLazyLoad()
            }).error(function() {
                c.removeAttr("data-lazy"), d.progressiveLazyLoad()
            }))
        }, b.prototype.refresh = function() {
            var b = this,
                c = b.currentSlide;
            b.destroy(), a.extend(b, b.initials), b.init(), b.changeSlide({
                data: {
                    message: "index",
                    index: c
                }
            }, !0)
        }, b.prototype.reinit = function() {
            var b = this;
            b.$slides = b.$slideTrack.children(b.options.slide).addClass("slick-slide"), b.slideCount = b.$slides.length, b.currentSlide >= b.slideCount && 0 !== b.currentSlide && (b.currentSlide = b.currentSlide - b.options.slidesToScroll), b.slideCount <= b.options.slidesToShow && (b.currentSlide = 0), b.setProps(), b.setupInfinite(), b.buildArrows(), b.updateArrows(), b.initArrowEvents(), b.buildDots(), b.updateDots(), b.initDotEvents(), b.options.focusOnSelect === !0 && a(b.options.slide, b.$slideTrack).on("click.slick", b.selectHandler), b.setSlideClasses(0), b.setPosition(), null !== b.options.onReInit && b.options.onReInit.call(this, b)
        }, b.prototype.removeSlide = function(a, b, c) {
            var d = this;
            return "boolean" == typeof a ? (b = a, a = b === !0 ? 0 : d.slideCount - 1) : a = b === !0 ? --a : a, d.slideCount < 1 || 0 > a || a > d.slideCount - 1 ? !1 : (d.unload(), c === !0 ? d.$slideTrack.children().remove() : d.$slideTrack.children(this.options.slide).eq(a).remove(), d.$slides = d.$slideTrack.children(this.options.slide), d.$slideTrack.children(this.options.slide).detach(), d.$slideTrack.append(d.$slides), d.$slidesCache = d.$slides, void d.reinit())
        }, b.prototype.setCSS = function(a) {
            var b, c, d = this,
                e = {};
            d.options.rtl === !0 && (a = -a), b = "left" == d.positionProp ? a + "px" : "0px", c = "top" == d.positionProp ? a + "px" : "0px", e[d.positionProp] = a, d.transformsEnabled === !1 ? d.$slideTrack.css(e) : (e = {}, d.cssTransitions === !1 ? (e[d.animType] = "translate(" + b + ", " + c + ")", d.$slideTrack.css(e)) : (e[d.animType] = "translate3d(" + b + ", " + c + ", 0px)", d.$slideTrack.css(e)))
        }, b.prototype.setDimensions = function() {
            var b = this;
            if (b.options.vertical === !1 ? b.options.centerMode === !0 && b.$list.css({
                    padding: "0px " + b.options.centerPadding
                }) : (b.$list.height(b.$slides.first().outerHeight(!0) * b.options.slidesToShow), b.options.centerMode === !0 && b.$list.css({
                    padding: b.options.centerPadding + " 0px"
                })), b.listWidth = b.$list.width(), b.listHeight = b.$list.height(), b.options.vertical === !1 && b.options.variableWidth === !1) b.slideWidth = Math.ceil(b.listWidth / b.options.slidesToShow), b.$slideTrack.width(Math.ceil(b.slideWidth * b.$slideTrack.children(".slick-slide").length));
            else if (b.options.variableWidth === !0) {
                var c = 0;
                b.slideWidth = Math.ceil(b.listWidth / b.options.slidesToShow), b.$slideTrack.children(".slick-slide").each(function() {
                    c += Math.ceil(a(this).outerWidth(!0))
                }), b.$slideTrack.width(Math.ceil(c) + 1)
            } else b.slideWidth = Math.ceil(b.listWidth), b.$slideTrack.height(Math.ceil(b.$slides.first().outerHeight(!0) * b.$slideTrack.children(".slick-slide").length));
            var d = b.$slides.first().outerWidth(!0) - b.$slides.first().width();
            b.options.variableWidth === !1 && b.$slideTrack.children(".slick-slide").width(b.slideWidth - d)
        }, b.prototype.setFade = function() {
            var b, c = this;
            c.$slides.each(function(d, f) {
                b = c.slideWidth * d * -1, a(f).css(c.options.rtl === !0 ? {
                    position: "relative",
                    right: b,
                    top: 0,
                    zIndex: 800,
                    opacity: 0
                } : {
                    position: "relative",
                    left: b,
                    top: 0,
                    zIndex: 800,
                    opacity: 0
                })
            }), c.$slides.eq(c.currentSlide).css({
                zIndex: 900,
                opacity: 1
            })
        }, b.prototype.setHeight = function() {
            var a = this;
            if (1 === a.options.slidesToShow && a.options.adaptiveHeight === !0 && a.options.vertical === !1) {
                var b = a.$slides.eq(a.currentSlide).outerHeight(!0);
                a.$list.css("height", b)
            }
        }, b.prototype.setPosition = function() {
            var a = this;
            a.setDimensions(), a.setHeight(), a.options.fade === !1 ? a.setCSS(a.getLeft(a.currentSlide)) : a.setFade(), null !== a.options.onSetPosition && a.options.onSetPosition.call(this, a)
        }, b.prototype.setProps = function() {
            var a = this,
                b = document.body.style;
            a.positionProp = a.options.vertical === !0 ? "top" : "left", "top" === a.positionProp ? a.$slider.addClass("slick-vertical") : a.$slider.removeClass("slick-vertical"), (void 0 !== b.WebkitTransition || void 0 !== b.MozTransition || void 0 !== b.msTransition) && a.options.useCSS === !0 && (a.cssTransitions = !0), void 0 !== b.OTransform && (a.animType = "OTransform", a.transformType = "-o-transform", a.transitionType = "OTransition", void 0 === b.perspectiveProperty && void 0 === b.webkitPerspective && (a.animType = !1)), void 0 !== b.MozTransform && (a.animType = "MozTransform", a.transformType = "-moz-transform", a.transitionType = "MozTransition", void 0 === b.perspectiveProperty && void 0 === b.MozPerspective && (a.animType = !1)), void 0 !== b.webkitTransform && (a.animType = "webkitTransform", a.transformType = "-webkit-transform", a.transitionType = "webkitTransition", void 0 === b.perspectiveProperty && void 0 === b.webkitPerspective && (a.animType = !1)), void 0 !== b.msTransform && (a.animType = "msTransform", a.transformType = "-ms-transform", a.transitionType = "msTransition", void 0 === b.msTransform && (a.animType = !1)), void 0 !== b.transform && a.animType !== !1 && (a.animType = "transform", a.transformType = "transform", a.transitionType = "transition"), a.transformsEnabled = null !== a.animType && a.animType !== !1
        }, b.prototype.setSlideClasses = function(a) {
            var b, c, d, e, f = this;
            f.$slider.find(".slick-slide").removeClass("slick-active").removeClass("slick-center"), c = f.$slider.find(".slick-slide"), f.options.centerMode === !0 ? (b = Math.floor(f.options.slidesToShow / 2), f.options.infinite === !0 && (a >= b && a <= f.slideCount - 1 - b ? f.$slides.slice(a - b, a + b + 1).addClass("slick-active") : (d = f.options.slidesToShow + a, c.slice(d - b + 1, d + b + 2).addClass("slick-active")), 0 === a ? c.eq(c.length - 1 - f.options.slidesToShow).addClass("slick-center") : a === f.slideCount - 1 && c.eq(f.options.slidesToShow).addClass("slick-center")), f.$slides.eq(a).addClass("slick-center")) : a >= 0 && a <= f.slideCount - f.options.slidesToShow ? f.$slides.slice(a, a + f.options.slidesToShow).addClass("slick-active") : c.length <= f.options.slidesToShow ? c.addClass("slick-active") : (e = f.slideCount % f.options.slidesToShow, d = f.options.infinite === !0 ? f.options.slidesToShow + a : a, f.options.slidesToShow == f.options.slidesToScroll && f.slideCount - a < f.options.slidesToShow ? c.slice(d - (f.options.slidesToShow - e), d + e).addClass("slick-active") : c.slice(d, d + f.options.slidesToShow).addClass("slick-active")), "ondemand" === f.options.lazyLoad && f.lazyLoad()
        }, b.prototype.setupInfinite = function() {
            var b, c, d, e = this;
            if (e.options.fade === !0 && (e.options.centerMode = !1), e.options.infinite === !0 && e.options.fade === !1 && (c = null, e.slideCount > e.options.slidesToShow)) {
                for (d = e.options.centerMode === !0 ? e.options.slidesToShow + 1 : e.options.slidesToShow, b = e.slideCount; b > e.slideCount - d; b -= 1) c = b - 1, a(e.$slides[c]).clone(!0).attr("id", "").attr("index", c - e.slideCount).prependTo(e.$slideTrack).addClass("slick-cloned");
                for (b = 0; d > b; b += 1) c = b, a(e.$slides[c]).clone(!0).attr("id", "").attr("index", c + e.slideCount).appendTo(e.$slideTrack).addClass("slick-cloned");
                e.$slideTrack.find(".slick-cloned").find("[id]").each(function() {
                    a(this).attr("id", "")
                })
            }
        }, b.prototype.selectHandler = function(b) {
            var c = this,
                d = parseInt(a(b.target).parents(".slick-slide").attr("index"));
            return d || (d = 0), c.slideCount <= c.options.slidesToShow ? (c.$slider.find(".slick-slide").removeClass("slick-active"), c.$slides.eq(d).addClass("slick-active"), c.options.centerMode === !0 && (c.$slider.find(".slick-slide").removeClass("slick-center"), c.$slides.eq(d).addClass("slick-center")), void c.asNavFor(d)) : void c.slideHandler(d)
        }, b.prototype.slideHandler = function(a, b, c) {
            var d, e, f, g, h = null,
                i = this;
            return b = b || !1, i.animating === !0 && i.options.waitForAnimate === !0 || i.options.fade === !0 && i.currentSlide === a || i.slideCount <= i.options.slidesToShow ? void 0 : (b === !1 && i.asNavFor(a), d = a, h = i.getLeft(d), g = i.getLeft(i.currentSlide), i.currentLeft = null === i.swipeLeft ? g : i.swipeLeft, i.options.infinite === !1 && i.options.centerMode === !1 && (0 > a || a > i.getDotCount() * i.options.slidesToScroll) ? void(i.options.fade === !1 && (d = i.currentSlide, c !== !0 ? i.animateSlide(g, function() {
                i.postSlide(d)
            }) : i.postSlide(d))) : i.options.infinite === !1 && i.options.centerMode === !0 && (0 > a || a > i.slideCount - i.options.slidesToScroll) ? void(i.options.fade === !1 && (d = i.currentSlide, c !== !0 ? i.animateSlide(g, function() {
                i.postSlide(d)
            }) : i.postSlide(d))) : (i.options.autoplay === !0 && clearInterval(i.autoPlayTimer), e = 0 > d ? i.slideCount % i.options.slidesToScroll !== 0 ? i.slideCount - i.slideCount % i.options.slidesToScroll : i.slideCount + d : d >= i.slideCount ? i.slideCount % i.options.slidesToScroll !== 0 ? 0 : d - i.slideCount : d, i.animating = !0, null !== i.options.onBeforeChange && a !== i.currentSlide && i.options.onBeforeChange.call(this, i, i.currentSlide, e), f = i.currentSlide, i.currentSlide = e, i.setSlideClasses(i.currentSlide), i.updateDots(), i.updateArrows(), i.options.fade === !0 ? void(c !== !0 ? i.fadeSlide(f, e, function() {
                i.postSlide(e)
            }) : i.postSlide(e)) : void(c !== !0 ? i.animateSlide(h, function() {
                i.postSlide(e)
            }) : i.postSlide(e))))
        }, b.prototype.startLoad = function() {
            var a = this;
            a.options.arrows === !0 && a.slideCount > a.options.slidesToShow && (a.$prevArrow.hide(), a.$nextArrow.hide()), a.options.dots === !0 && a.slideCount > a.options.slidesToShow && a.$dots.hide(), a.$slider.addClass("slick-loading")
        }, b.prototype.swipeDirection = function() {
            var a, b, c, d, e = this;
            return a = e.touchObject.startX - e.touchObject.curX, b = e.touchObject.startY - e.touchObject.curY, c = Math.atan2(b, a), d = Math.round(180 * c / Math.PI), 0 > d && (d = 360 - Math.abs(d)), 45 >= d && d >= 0 ? e.options.rtl === !1 ? "left" : "right" : 360 >= d && d >= 315 ? e.options.rtl === !1 ? "left" : "right" : d >= 135 && 225 >= d ? e.options.rtl === !1 ? "right" : "left" : "vertical"
        }, b.prototype.swipeEnd = function() {
            var a = this;
            if (a.dragging = !1, a.shouldClick = a.touchObject.swipeLength > 10 ? !1 : !0, void 0 === a.touchObject.curX) return !1;
            if (a.touchObject.swipeLength >= a.touchObject.minSwipe) switch (a.swipeDirection()) {
                case "left":
                    a.slideHandler(a.currentSlide + a.getSlideCount()), a.currentDirection = 0, a.touchObject = {};
                    break;
                case "right":
                    a.slideHandler(a.currentSlide - a.getSlideCount()), a.currentDirection = 1, a.touchObject = {}
            } else a.touchObject.startX !== a.touchObject.curX && (a.slideHandler(a.currentSlide), a.touchObject = {})
        }, b.prototype.swipeHandler = function(a) {
            var b = this;
            if (!(b.options.swipe === !1 || "ontouchend" in document && b.options.swipe === !1 || b.options.draggable === !1 && -1 !== a.type.indexOf("mouse"))) switch (b.touchObject.fingerCount = a.originalEvent && void 0 !== a.originalEvent.touches ? a.originalEvent.touches.length : 1, b.touchObject.minSwipe = b.listWidth / b.options.touchThreshold, a.data.action) {
                case "start":
                    b.swipeStart(a);
                    break;
                case "move":
                    b.swipeMove(a);
                    break;
                case "end":
                    b.swipeEnd(a)
            }
        }, b.prototype.swipeMove = function(a) {
            var b, c, d, e, f = this;
            return e = void 0 !== a.originalEvent ? a.originalEvent.touches : null, !f.dragging || e && 1 !== e.length ? !1 : (b = f.getLeft(f.currentSlide), f.touchObject.curX = void 0 !== e ? e[0].pageX : a.clientX, f.touchObject.curY = void 0 !== e ? e[0].pageY : a.clientY, f.touchObject.swipeLength = Math.round(Math.sqrt(Math.pow(f.touchObject.curX - f.touchObject.startX, 2))), c = f.swipeDirection(), "vertical" !== c ? (void 0 !== a.originalEvent && f.touchObject.swipeLength > 4 && a.preventDefault(), d = (f.options.rtl === !1 ? 1 : -1) * (f.touchObject.curX > f.touchObject.startX ? 1 : -1), f.swipeLeft = f.options.vertical === !1 ? b + f.touchObject.swipeLength * d : b + f.touchObject.swipeLength * (f.$list.height() / f.listWidth) * d, f.options.fade === !0 || f.options.touchMove === !1 ? !1 : f.animating === !0 ? (f.swipeLeft = null, !1) : void f.setCSS(f.swipeLeft)) : void 0)
        }, b.prototype.swipeStart = function(a) {
            var b, c = this;
            return 1 !== c.touchObject.fingerCount || c.slideCount <= c.options.slidesToShow ? (c.touchObject = {}, !1) : (void 0 !== a.originalEvent && void 0 !== a.originalEvent.touches && (b = a.originalEvent.touches[0]), c.touchObject.startX = c.touchObject.curX = void 0 !== b ? b.pageX : a.clientX, c.touchObject.startY = c.touchObject.curY = void 0 !== b ? b.pageY : a.clientY, void(c.dragging = !0))
        }, b.prototype.unfilterSlides = function() {
            var a = this;
            null !== a.$slidesCache && (a.unload(), a.$slideTrack.children(this.options.slide).detach(), a.$slidesCache.appendTo(a.$slideTrack), a.reinit())
        }, b.prototype.unload = function() {
            var b = this;
            a(".slick-cloned", b.$slider).remove(), b.$dots && b.$dots.remove(), b.$prevArrow && "object" != typeof b.options.prevArrow && b.$prevArrow.remove(), b.$nextArrow && "object" != typeof b.options.nextArrow && b.$nextArrow.remove(), b.$slides.removeClass("slick-slide slick-active slick-visible").css("width", "")
        }, b.prototype.updateArrows = function() {
            var a, b = this;
            a = Math.floor(b.options.slidesToShow / 2), b.options.arrows === !0 && b.options.infinite !== !0 && b.slideCount > b.options.slidesToShow && (b.$prevArrow.removeClass("slick-disabled"), b.$nextArrow.removeClass("slick-disabled"), 0 === b.currentSlide ? (b.$prevArrow.addClass("slick-disabled"), b.$nextArrow.removeClass("slick-disabled")) : b.currentSlide >= b.slideCount - b.options.slidesToShow && b.options.centerMode === !1 ? (b.$nextArrow.addClass("slick-disabled"), b.$prevArrow.removeClass("slick-disabled")) : b.currentSlide > b.slideCount - b.options.slidesToShow + a && b.options.centerMode === !0 && (b.$nextArrow.addClass("slick-disabled"), b.$prevArrow.removeClass("slick-disabled")))
        }, b.prototype.updateDots = function() {
            var a = this;
            null !== a.$dots && (a.$dots.find("li").removeClass("slick-active"), a.$dots.find("li").eq(Math.floor(a.currentSlide / a.options.slidesToScroll)).addClass("slick-active"))
        }, a.fn.slick = function(a) {
            var c = this;
            return c.each(function(c, d) {
                d.slick = new b(d, a)
            })
        }, a.fn.slickAdd = function(a, b, c) {
            var d = this;
            return d.each(function(d, f) {
                f.slick.addSlide(a, b, c)
            })
        }, a.fn.slickCurrentSlide = function() {
            var a = this;
            return a.get(0).slick.getCurrent()
        }, a.fn.slickFilter = function(a) {
            var b = this;
            return b.each(function(b, c) {
                c.slick.filterSlides(a)
            })
        }, a.fn.slickGoTo = function(a, b) {
            var c = this;
            return c.each(function(c, d) {
                d.slick.changeSlide({
                    data: {
                        message: "index",
                        index: parseInt(a)
                    }
                }, b)
            })
        }, a.fn.slickNext = function() {
            var a = this;
            return a.each(function(a, b) {
                b.slick.changeSlide({
                    data: {
                        message: "next"
                    }
                })
            })
        }, a.fn.slickPause = function() {
            var a = this;
            return a.each(function(a, b) {
                b.slick.autoPlayClear(), b.slick.paused = !0
            })
        }, a.fn.slickPlay = function() {
            var a = this;
            return a.each(function(a, b) {
                b.slick.paused = !1, b.slick.autoPlay()
            })
        }, a.fn.slickPrev = function() {
            var a = this;
            return a.each(function(a, b) {
                b.slick.changeSlide({
                    data: {
                        message: "previous"
                    }
                })
            })
        }, a.fn.slickRemove = function(a, b) {
            var c = this;
            return c.each(function(c, d) {
                d.slick.removeSlide(a, b)
            })
        }, a.fn.slickRemoveAll = function() {
            var a = this;
            return a.each(function(a, b) {
                b.slick.removeSlide(null, null, !0)
            })
        }, a.fn.slickGetOption = function(a) {
            var b = this;
            return b.get(0).slick.options[a]
        }, a.fn.slickSetOption = function(a, b, c) {
            var d = this;
            return d.each(function(d, f) {
                f.slick.options[a] = b, c === !0 && (f.slick.unload(), f.slick.reinit())
            })
        }, a.fn.slickUnfilter = function() {
            var a = this;
            return a.each(function(a, b) {
                b.slick.unfilterSlides()
            })
        }, a.fn.unslick = function() {
            var a = this;
            return a.each(function(a, b) {
                b.slick && b.slick.destroy()
            })
        }, a.fn.getSlick = function() {
            var a = null,
                b = this;
            return b.each(function(b, c) {
                a = c.slick
            }), a
        }
    }), define("amd/carousel", ["jquery", "slick"], function(a) {
        var b = {
            Element: ".carousel",
            VersionA: ".carousel-version-a",
            VersionB: ".carousel-version-b",
            VersionC: ".carousel-version-c",
            VersionD: ".carousel-version-d",
            VersionE: ".carousel-version-e",
            VersionF: ".carousel-version-f",
            SlidesElement: ".carousel--slides",
            CustomPagerElement: ".carousel--custom-pager",
            CustomPagerContainerElement: ".carousel--custom-pager__container",
            CustomPagerWrapperElement: ".carousel--custom-pager__wrapper",
            CustomPagerItemElement: ".carousel--custom-pager__item",
            CustomArrowsElement: ".carousel--custom-arrows",
            CustomPrevElement: ".carousel--custom-arrows__prev .slick-prev",
            CustomNextElement: ".carousel--custom-arrows__next .slick-next",
            GlobalAutoPlaySpeed: 5e3,
            GetAutoPlay: function(a) {
                var b = a.data("autoplay");
                return b === !0 ? !0 : !1
            },
            GetStartSlide: function(a) {
                var b = a.data("start-slide");
                return b > 0 && b < 20 ? a.data("start-slide") : 0
            },
            InitializeCarousel: function(c) {
                c.addClass("visible"), c.is(b.VersionA) ? (c.find(b.SlidesElement).attr("aria-hidden", "true"), c.find(b.CustomPagerContainerElement).attr("aria-hidden", "true"), c.find(b.CustomArrowsElement).attr("aria-hidden", "true")) : c.find(b.CustomPagerWrapperElement).attr("aria-hidden", "true"), c.find("a:not(.carousel--accessible-list-item),button").attr("tabindex", "-1"), c.find(".carousel--accessible-list-item").on("focus", function(b) {
                    a(this).parent().addClass("display-accessible-text")
                }).on("focusout", function(b) {
                    a(this).parent().removeClass("display-accessible-text")
                });
                var d = c.data("tracking-name"),
                    e = setInterval(function() {
                        c.find(".slick-dots").length > 0 && (c.find(".slick-dots li button").each(function() {
                            a(this).attr("data-pt-name", d + "_" + a(this).attr("data-pt-name"))
                        }), clearInterval(e))
                    }, 200)
            },
            SetupCarousels: function(c) {
                c.each(function() {
                    var c = a(this).data("type");
                    c === "a" ? b.SetupVersionA(a(this)) : c === "b" ? b.SetupVersionB(a(this)) : c === "c" ? b.SetupVersionC(a(this)) : c === "d" ? b.SetupVersionD(a(this)) : c === "e" ? b.SetupVersionE(a(this)) : c === "f" && b.SetupVersionF(a(this))
                })
            },
            SetupVersionA: function(a) {
                var c = a.find(b.SlidesElement),
                    d = a.find(b.CustomPagerElement),
                    e = a.find(b.CustomPrevElement),
                    f = a.find(b.CustomNextElement);
                d.on("init", b.InitializeCarousel(a)), c.slick({
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    autoplay: this.GetAutoPlay(a),
                    autoplaySpeed: this.GlobalAutoPlaySpeed,
                    arrows: !1,
                    asNavFor: d,
                    initialSlide: this.GetStartSlide(a)
                }), d.slick({
                    slidesToShow: 5,
                    slidesToScroll: 1,
                    asNavFor: c,
                    arrows: !0,
                    prevArrow: e,
                    nextArrow: f,
                    dots: !0,
                    centerMode: !0,
                    centerPadding: "",
                    focusOnSelect: !1,
                    initialSlide: this.GetStartSlide(a),
                    pauseOnDotsHover: !0,
                    responsive: [{
                        breakpoint: 992,
                        settings: {
                            slidesToShow: 3
                        }
                    }, {
                        breakpoint: 568,
                        settings: {
                            slidesToShow: 3,
                            arrows: !1,
                            prevArrow: "",
                            nextArrow: ""
                        }
                    }, {
                        breakpoint: 450,
                        settings: {
                            slidesToShow: 3,
                            arrows: !1,
                            prevArrow: "",
                            nextArrow: "",
                            variableWidth: !0
                        }
                    }]
                })
            },
            SetupVersionB: function(a) {
                var c = a.find(b.CustomPagerElement),
                    d = a.find(b.CustomPrevElement),
                    e = a.find(b.CustomNextElement);
                c.on("init", b.InitializeCarousel(a)), c.slick({
                    slidesToShow: 5,
                    slidesToScroll: 1,
                    autoplay: this.GetAutoPlay(a),
                    autoplaySpeed: this.GlobalAutoPlaySpeed,
                    arrows: !0,
                    prevArrow: d,
                    nextArrow: e,
                    dots: !0,
                    centerMode: !0,
                    centerPadding: "",
                    focusOnSelect: !1,
                    initialSlide: this.GetStartSlide(a),
                    pauseOnDotsHover: !0,
                    responsive: [{
                        breakpoint: 992,
                        settings: {
                            slidesToShow: 3
                        }
                    }, {
                        breakpoint: 568,
                        settings: {
                            slidesToShow: 3,
                            arrows: !1,
                            prevArrow: "",
                            nextArrow: ""
                        }
                    }, {
                        breakpoint: 450,
                        settings: {
                            slidesToShow: 3,
                            arrows: !1,
                            prevArrow: "",
                            nextArrow: "",
                            variableWidth: !0
                        }
                    }]
                })
            },
            SetupVersionC: function(a) {
                var c = a.find(b.CustomPagerElement),
                    d = a.find(b.CustomPrevElement),
                    e = a.find(b.CustomNextElement);
                c.on("init", b.InitializeCarousel(a)), c.slick({
                    slidesToShow: 5,
                    slidesToScroll: 1,
                    autoplay: this.GetAutoPlay(a),
                    autoplaySpeed: this.GlobalAutoPlaySpeed,
                    arrows: !0,
                    prevArrow: d,
                    nextArrow: e,
                    dots: !0,
                    centerMode: !0,
                    centerPadding: "",
                    focusOnSelect: !1,
                    initialSlide: this.GetStartSlide(a),
                    pauseOnDotsHover: !0,
                    responsive: [{
                        breakpoint: 992,
                        settings: {
                            slidesToShow: 3
                        }
                    }, {
                        breakpoint: 568,
                        settings: {
                            slidesToShow: 3,
                            arrows: !1,
                            prevArrow: "",
                            nextArrow: ""
                        }
                    }, {
                        breakpoint: 450,
                        settings: {
                            slidesToShow: 3,
                            arrows: !1,
                            prevArrow: "",
                            nextArrow: "",
                            variableWidth: !0
                        }
                    }]
                })
            },
            SetupVersionD: function(a) {
                var c = a.find(b.CustomPagerElement),
                    d = a.find(b.CustomPrevElement),
                    e = a.find(b.CustomNextElement);
                c.on("init", b.InitializeCarousel(a)), c.slick({
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    autoplay: this.GetAutoPlay(a),
                    autoplaySpeed: this.GlobalAutoPlaySpeed,
                    arrows: !0,
                    prevArrow: d,
                    nextArrow: e,
                    dots: !0,
                    centerMode: !0,
                    centerPadding: "",
                    focusOnSelect: !1,


                    initialSlide: this.GetStartSlide(a),
                    pauseOnDotsHover: !0,
                    responsive: [{
                        breakpoint: 769,
                        settings: {
                            arrows: !0,
                            prevArrow: d,
                            nextArrow: e
                        }
                    }, {
                        breakpoint: 581,
                        settings: {
                            arrows: !1,
                            prevArrow: "",
                            nextArrow: ""
                        }
                    }]
                })
            },
            SetupVersionE: function(a) {
                var c = a.find(b.CustomPagerElement),
                    d = a.find(b.SlidesElement),
                    e = a.find(b.CustomPrevElement),
                    f = a.find(b.CustomNextElement);
                c.on("init", b.InitializeCarousel(a)), d.slick({
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    autoplay: this.GetAutoPlay(a),
                    autoplaySpeed: this.GlobalAutoPlaySpeed,
                    arrows: !0,
                    prevArrow: e,
                    nextArrow: f,
                    dots: !0,
                    centerMode: !0,
                    centerPadding: "",
                    focusOnSelect: !1,
                    initialSlide: this.GetStartSlide(a),
                    pauseOnDotsHover: !0,
                    responsive: [{
                        breakpoint: 768,
                        settings: {
                            arrows: !1,
                            prevArrow: "",
                            nextArrow: ""
                        }
                    }]
                })
            },
            SetupVersionF: function(a) {
                var c = a.find(b.SlidesElement),
                    d = a.find(b.CustomPagerElement),
                    e = a.find(b.CustomPrevElement),
                    f = a.find(b.CustomNextElement);
                d.on("init", b.InitializeCarousel(a)), c.slick({
                    slidesToShow: 1,
                    slidesToScroll: 1,
                    autoplay: this.GetAutoPlay(a),
                    autoplaySpeed: this.GlobalAutoPlaySpeed,
                    arrows: !1,
                    asNavFor: d,
                    initialSlide: this.GetStartSlide(a)
                }), d.slick({
                    slidesToShow: 5,
                    slidesToScroll: 1,
                    asNavFor: c,
                    arrows: !0,
                    prevArrow: e,
                    nextArrow: f,
                    dots: !0,
                    centerMode: !0,
                    centerPadding: "",
                    focusOnSelect: !1,
                    initialSlide: this.GetStartSlide(a),
                    pauseOnDotsHover: !0,
                    responsive: [{
                        breakpoint: 992,
                        settings: {
                            slidesToShow: 3
                        }
                    }, {
                        breakpoint: 568,
                        settings: {
                            slidesToShow: 3,
                            arrows: !1,
                            prevArrow: "",
                            nextArrow: ""
                        }
                    }, {
                        breakpoint: 450,
                        settings: {
                            slidesToShow: 3,
                            arrows: !1,
                            prevArrow: "",
                            nextArrow: "",
                            variableWidth: !0
                        }
                    }]
                })
            }
        };
        return {
            init: function() {
                var c = a(document),
                    d = a(b.Element);
                c.ready(function() {
                    b.SetupCarousels(d)
                });
                var e = a(".main-content--dropzone");
                e.on("Chase:FeatureAppended", function(c, d) {
                    var e = a(d),
                        f = e.children(b.Element);
                    f.length > 0 && (e.animate({
                        opacity: 1
                    }, 400), b.SetupCarousels(f))
                })
            },
            setupCarousels: function(a) {
                b.SetupCarousels(a)
            }
        }
    }), define("amd/hero", ["jquery"], function(a) {
        var b = {
            Content: ".hero__content",
            SecondaryImage: ".hero__img",
            CheckForImageDownload: function(a) {
                var c = setInterval(function() {
                    a.find("img")[0].complete && (b.VerticallyCenterHeroSecondaryImage(a), clearInterval(c))
                }, 200)
            },
            FindHeroWithSecondaryImage: function(c) {
                c.each(function() {
                    b.CheckForImageDownload(a(this))
                })
            },
            VerticallyCenterHeroSecondaryImage: function(a) {
                var c = a.siblings(b.Content),
                    d = a.find("img");
                a.attr("style", ""), d.attr("style", ""), c.height() > a.height() && (a.css("height", c.height()), d.css({
                    position: "relative",
                    top: "50%",
                    "margin-top": -(d.height() / 2)
                }))
            }
        };
        return {
            init: function() {
                var c = a(".main-content--dropzone"),
                    d = a(b.SecondaryImage);
                b.FindHeroWithSecondaryImage(d), a(window).on("resize", function() {
                    d && b.FindHeroWithSecondaryImage(d)
                }), c.on("Chase:FeatureAppended", function(c, d) {
                    var e = a(d),
                        f = e.find(b.SecondaryImage);
                    f.length > 0 && b.CheckForImageDownload(f)
                })
            },
            checkForImageDownload: function(a) {
                b.CheckForImageDownload(a)
            }
        }
    }), ! function(a) {
        a.fn.hoverIntent = function(b, c, d) {
            var f = {
                interval: 100,
                sensitivity: 6,
                timeout: 0
            };
            f = "object" == typeof b ? a.extend(f, b) : a.isFunction(c) ? a.extend(f, {
                over: b,
                out: c,
                selector: d
            }) : a.extend(f, {
                over: b,
                out: b,
                selector: c
            });
            var g, h, i, j, k = function(a) {
                    g = a.pageX, h = a.pageY
                },
                l = function(b, c) {
                    return c.hoverIntent_t = clearTimeout(c.hoverIntent_t), Math.sqrt((i - g) * (i - g) + (j - h) * (j - h)) < f.sensitivity ? (a(c).off("mousemove.hoverIntent", k), c.hoverIntent_s = !0, f.over.apply(c, [b])) : (i = g, j = h, c.hoverIntent_t = setTimeout(function() {
                        l(b, c)
                    }, f.interval), void 0)
                },
                m = function(a, b) {
                    return b.hoverIntent_t = clearTimeout(b.hoverIntent_t), b.hoverIntent_s = !1, f.out.apply(b, [a])
                },
                n = function(b) {
                    var c = a.extend({}, b),
                        d = this;
                    d.hoverIntent_t && (d.hoverIntent_t = clearTimeout(d.hoverIntent_t)), "mouseenter" === b.type ? (i = c.pageX, j = c.pageY, a(d).on("mousemove.hoverIntent", k), d.hoverIntent_s || (d.hoverIntent_t = setTimeout(function() {
                        l(c, d)
                    }, f.interval))) : (a(d).off("mousemove.hoverIntent", k), d.hoverIntent_s && (d.hoverIntent_t = setTimeout(function() {
                        m(c, d)
                    }, f.timeout)))
                };
            return this.on({
                "mouseenter.hoverIntent": n,
                "mouseleave.hoverIntent": n
            }, f.selector)
        }
    }(jQuery), define("hover-intent", function() {}), define("amd/sidemenu", ["jquery"], function(a) {
        var b = {
            PrimaryLink: ".sidemenu__menu__section--primary--link",
            ProductMenu: ".sidemenu__menu__section--secondary--product--links",
            ProductLink: ".sidemenu__menu__section--secondary--product--link",
            ProductContainer: ".sidemenu__menu__section--secondary--product--link__container",
            ClearSearchTerm: ".sidemenu__menu__search__close",
            SearchTerm: ".sidemenu__menu__search__term",
            SearchTermForm: ".sidemenu__menu__search__form",
            Menu: ".sidemenu__menu",
            ClearSearch: function() {
                a(b.SearchTerm).val("")
            },
            SlideProductList: function(b) {
                var c = "-" + b.width() + "px";
                b.children().find(this.ProductContainer).css("left", c), b.children().find(this.ProductContainer).each(function(b) {
                    a(this).delay(100 * b).animate({
                        left: 0
                    }, 300)
                })
            },
            SetupSearchBarEvents: function(c) {
                a(b.SearchTermForm).on("submit", function(b) {
                    b.preventDefault();
                    var c = a.map(a(this).serializeArray(), function(a) {
                        return [a.name, window.encodeURIComponent(a.value)].join("=")
                    }).join("&");
                    window.location.href = a(this).attr("action") + "?" + c
                })
            }
        };
        return {
            init: function(c) { 
                var d = a(window),
                    e = a(b.SearchTerm);
                d.on("click", function(c) {
                    var d = a(c.target);
                    d.is(b.ClearSearchTerm) && b.ClearSearch()
                });
                if (c) {
                    var f = a(".browser-message").height() + "px";
                    a(b.Menu).css({
                        "padding-bottom": f
                    })
                }
                e.on("focusin", function() {
                    a(b.ClearSearchTerm).addClass("active")
                }).on("focusout", function() {
                    a(b.ClearSearchTerm).removeClass("active")
                }), b.SetupSearchBarEvents(b.oldIEBrowser)
            },
            SlideCurrentProductList: function() {
                b.SlideProductList(a(b.ProductMenu))
            },
            HomePageLinkVariations: b.HomePageLinkVariations
        }
    }), define("amd/header", ["jquery", "amd/sidemenu", "hover-intent"], function(a, b) {
        var c = {
            HeaderElement: "[data-feature=header]",
            /*: ".header__black-linear-bg",*/
            HeaderBlackBg: ".header__black-bg",
            HeaderBlueBg: ".header__blue-bg",
            HeaderDropDownClickElement: ".header__section--dropdown",
            HeaderDropDownSectionElement: ".header__section--dropdown__tiles",
            HeaderDropDownSectionElementEachTile: ".header__section--dropdown__tile",
            HeaderDropDownSectionTitleLinkElement: ".header__section--dropdown__tile--link",
            HeaderDropDownSectionTitleIconElement: ".header__section--dropdown__tile--icon",
            HeaderDropDownTitleElement: ".header__section--dropdown__title",
            HeaderDropDownTitleLinkElement: ".header__section--dropdown__title__link",
            HeaderDropDownSubSectionRowElement: ".header__section--dropdown--sub-section__row",
            HeaderLogoContainerElement: ".header__section--center--link",
            HeaderLogoTextElement: ".header__section--center .chase-text",
            HeaderLogoIconElement: ".header__section--center .chase-logo-icon",
            HeaderSearchClickElement: ".header__section--search",
            HeaderSearchBarElement: ".header__section--search__bar",
            HeaderSearchBarContainerElement: ".header__section--search__bar__container",
            HeaderSearchBarFormElement: ".header__section--search__bar__form",
            HeaderSearchInputElement: ".header__section--search__bar--search-input",
            HeaderSearchCloseElement: ".header__section--search__bar--search-close-icon",
            HeaderSearchSubmitElement: ".header__section--search__bar--search-icon",
            SignInWrapperElement: ".signin-module__wrapper",
            LoginButtonElement: ".header__section--link.login",
            GeoModuleElement: ".geo-module",
            CarouselElement: ".carousel",
            headerAnimate: ".headerAnimate",
			HeroElement: ".hero",
            SideMenuElement: ".sidemenu",
            SideMenuLinksElement: ".sidemenu__menu__section--primary--link a",
            SideMenuOverlayElement: ".sidemenu__overlay",
            SideMenuClickElement: ".header__section--sidemenu",
            SideMenuCloseElement: ".sidemenu__menu__close a",
            SideMenuPrimaryActiveLinkElement: ".sidemenu__menu__section--primary--link:first a",
            SideMenuWidth: "270px",
            SideMenuAnimation: {
                duration: 550,
                queue: !1
            },
            SubHeaderElement: ".topic__wrapper__header",
            DropdownTiles: ".header__section--dropdown__tiles",
            MainElement: "#main",
            MainContentElement: ".main-content",
            DropIconsDown: function(b) {
                if (!this.oldIEBrowser) b.children().css({
                    top: "-10px",
                    opacity: "0"
                }), b.children().each(function(b) {
                    a(this).delay(100 * b).animate({
                        top: "0",
                        opacity: "1"
                    }, 300)
                });
                else {
                    var c = this;
                    b.children().each(function() {
                        var b = a(this).find(c.HeaderDropDownSectionTitleIconElement),
                            d = b.clone();
                        b.remove(), a(this).prepend(d)
                    })
                }
            },
            CloseSideMenu: function() {
                a(c.SideMenuElement).stop().animate({
                    left: "-" + this.SideMenuWidth
                }, this.SideMenuAnimation).removeClass("open"), a(c.SideMenuOverlayElement).addClass("closed"), a(c.SideMenuCloseElement).addClass("close-animation"), setTimeout(function() {
                    a(c.SideMenuElement).addClass("closed"), a(c.SideMenuCloseElement).removeClass("close-animation")
                }, 550), a("html,body").css({
                    overflow: "auto"
                }), a(c.SideMenuClickElement).find(".accessible-text").text("Show the Side Menu.")
            },
            OpenSideMenu: function() {
                a(c.SideMenuElement).removeClass("closed"), a(c.SideMenuElement).stop().animate({
                    left: 0
                }, this.SideMenuAnimation).addClass("open"), a(c.SideMenuOverlayElement).removeClass("closed"), a("html,body").css({
                    overflow: "hidden"
                }), a(c.SideMenuClickElement).find(".accessible-text").text("Hide the Side Menu."), b.SlideCurrentProductList()
            },
            UpdateSideMenuWidth: function() {
                var b = 270;
                a(c.SideMenuElement).width() >= b && (this.SideMenuWidth = a(c.SideMenuElement).width() + "px")
            },
            CloseSearchBar: function(b) {
                a(c.HeaderSearchClickElement).removeClass("hide"), a(c.HeaderElement).removeClass("open"), a(c.HeaderSearchBarElement).removeClass("open"), b && a(c.HeaderElement).hasClass("black") && c.FadeBackgroundToBlack(), a(c.HeaderSearchClickElement).removeAttr("aria-hidden").find(".accessible-text").text("Show Search.")
            },
            OpenSearchBar: function() {
                a(c.HeaderElement).hasClass("black-linear") && c.FadeBackgroundToBlack(), a(c.HeaderSearchClickElement).addClass("hide"), a(c.HeaderElement).addClass("open"), a(c.HeaderSearchBarElement).addClass("open");
                if (this.oldIEBrowser) {
                    var b = a(c.HeaderSearchBarContainerElement),
                        d = b.find(c.HeaderSearchBarFormElement),
                        e = d.clone();
                    d.remove(), b.append(e), this.SetupSearchBarEvents(this.oldIEBrowser)
                }
                a(c.HeaderSearchClickElement).attr("aria-hidden", !0).find(".accessible-text").text("Hide Search.")
            },
            ClearSearch: function() {
                a(c.HeaderSearchInputElement).val(""), a(c.HeaderSearchInputElement).focus()
            },
            SetupSearchBarEvents: function(b) {
                a(c.HeaderSearchInputElement).on("focusin", function(d) {
                    if (b) {
                        var e = a(c.HeaderSearchBarFormElement),
                            f = e.find(c.HeaderSearchCloseElement),
                            g = f.clone();
                        f.remove(), e.append(g)
                    }
                    a(c.HeaderSearchCloseElement).addClass("active")
                }).on("focusout", function(d) {
                    b && a(d.target).attr("value", ""), a(c.HeaderSearchCloseElement).removeClass("active")
                }), a(c.HeaderSearchBarFormElement).on("submit", function(b) {
                    b.preventDefault();
                    var c = a.map(a(this).serializeArray(), function(a) {
                        return [a.name, window.encodeURIComponent(a.value)].join("=")
                    }).join("&");
                    window.location.href = a(this).attr("action") + "?" + c
                })
            },
            CloseDropDown: function(b) {
                b && a(c.HeaderElement).hasClass("black") && c.FadeBackgroundToBlack(), a(c.HeaderElement).removeClass("hover-intent open-dropdown"), a(c.HeaderDropDownClickElement).removeClass("hover-intent"), a(c.HeaderDropDownSectionElement).removeClass("hover-intent"), a(c.HeaderDropDownTitleElement).find(".accessible-text").text("Open Drop Down.")
            },
            GetFirstFeatureHeight: function() {
                var b = a(c.HeaderElement),
                    d = b.data("header-transition-override");
                if (!d) {
                    var f = [this.HeroElement, this.CarouselElement, this.GeoModuleElement, this.SubHeaderElement, this.headerAnimate],
                        g = f.join(","),
                        h = a(this.MainContentElement);
                    return h.find(g).height()
                }
                d = parseInt(d);
                if (!Number.isNaN(d)) {
                    var e = a(window).height();
                    return Math.floor(e * (d / 100))
                }
                window.console && console.log("[Header] Transition Override Invalid.")
            },
            /*FadeBackgroundToBlack: function() {
			
		    a(c.HeaderBlackBg).hasClass("hide") && (a(c.HeaderElement).addClass("black").removeClass("blue black-linear"), a(c.HeaderBlackBg).fadeIn(function() {
                    a(this).removeClass("hide")
                }), a(c.HeaderBlueBg).fadeOut(function() {
                    a(this).addClass("hide")
                }), a(c.HeaderBlackLinearBg).fadeOut(function() {
                    a(this).addClass("hide")
                }))
			
                a(c.HeaderBlackLinearBg).hasClass("hide") && (a(c.HeaderElement).hasClass("open") ? (a(c.HeaderElement).addClass("black").removeClass("blue black-linear"), a(c.HeaderBlackBg).removeClass("hide").show(), a(c.HeaderBlueBg).fadeOut(function() {
                    a(this).addClass("hide")
                }), a(c.HeaderBlackLinearBg).fadeOut(function() {
                    a(this).addClass("hide")
                })) : (a(c.HeaderElement).addClass("black-linear").removeClass("blue black"), a(c.HeaderBlackBg).fadeOut(function() {
                    a(this).addClass("hide")
                }), a(c.HeaderBlueBg).fadeOut(function() {
                    a(this).addClass("hide")
                }), a(c.HeaderBlackLinearBg).fadeIn(function() {
                    a(this).removeClass("hide")
                })))
            },*/
            FadeBackgroundToBlack: function() {
                a(c.HeaderBlackBg).hasClass("hide") && (a(c.HeaderElement).addClass("black").removeClass("blue black-linear"), a(c.HeaderBlackBg).fadeIn(function() {
                    a(this).removeClass("hide")
                }), a(c.HeaderBlueBg).fadeOut(function() {
                    a(this).addClass("hide")
                })/*, a(c.HeaderBlackLinearBg).fadeOut(function() {
                    a(this).addClass("hide")
                })*/
				)
            },
            FadeBackgroundToBlue: function() {
                a(c.HeaderBlueBg).hasClass("hide") && (a(c.HeaderElement).hasClass("open") ? (a(c.HeaderElement).addClass("blue").removeClass("black black-linear"), a(c.HeaderBlueBg).removeClass("hide").show(), a(c.HeaderBlackBg).fadeOut(function() {
                    a(this).addClass("hide")
                })/*, a(c.HeaderBlackLinearBg).fadeOut(function() {
                    a(this).addClass("hide")
                })*/) : (a(c.HeaderElement).addClass("blue").removeClass("black black-linear")/*, a(c.HeaderBlackLinearBg).fadeOut(function() {
                    a(this).addClass("hide")
                })*/, a(c.HeaderBlackBg).fadeOut(function() {
                    a(this).addClass("hide")
                }), a(c.HeaderBlueBg).fadeIn(function() {
                    a(this).removeClass("hide")
                })))
            }
        };
        return {
            init: function(b) {
                c.oldIEBrowser = b;
                var d = a(window),
                    e = a(document);
                c.UpdateSideMenuWidth(), e.on("click", function(b) {
                    var d = a(b.target),
                        e = a(c.HeaderElement),
                        f = a(c.SideMenuElement),
                        g = a(c.HeaderSearchBarElement);
                    d.is(c.SideMenuClickElement) ? f.hasClass("open") ? (c.CloseSideMenu(), b.preventDefault()) : (e.hasClass("hover-intent") && c.CloseDropDown(!0), c.OpenSideMenu(), a(c.SideMenuLinksElement).first().focus(), b.preventDefault()) : d.is(c.SideMenuCloseElement) ? (c.CloseSideMenu(), b.preventDefault()) : d.is(c.HeaderSearchClickElement) ? (e.hasClass("hover-intent") && c.CloseDropDown(), c.OpenSearchBar(), setTimeout(function() {
                        a(c.HeaderSearchInputElement).focus()
                    }, 50), b.preventDefault()) : d.is(c.HeaderSearchCloseElement) ? c.ClearSearch() : (f.is(".open") && d.parents(c.SideMenuElement).length === 0 && (c.CloseSideMenu(), a(c.SideMenuClickElement).focus()), g.is(".open") && d.parents(c.HeaderSearchBarElement).length === 0 && c.CloseSearchBar(!0), e.is(".open-dropdown") && d.parents(c.HeaderElement).length === 0 && (a(c.HeaderElement).hasClass("black") && c.FadeBackgroundToBlack(), c.CloseDropDown(), k = !1))
                });
                var f = a(c.HeaderLogoTextElement),
                    g = f.width(),
                    h = 150,
                    i = 0,
                    j = !1;
                d.on("scroll", function(b) {
                    var e = a(c.HeaderElement);
                    if (!j) {
                        var k = c.GeoModuleElement + "," + c.CarouselElement + "," + c.HeroElement + "," + c.headerAnimate,
                            l = a(c.MainElement).find(k).first();
                        l.length > 0 && (i = Math.ceil(l.offset().top + l.height() - e.height()), i > 0 && (j = !0))
                    }
                    var m = a(c.HeaderBlackBg),
                        n = a(c.HeaderBlueBg),
                        o = d.scrollTop(),
                        p = a(c.HeaderSearchBarElement);
                    e.length === 1 && (e.offset().top + e.height() > c.GetFirstFeatureHeight() ? c.FadeBackgroundToBlue() : c.FadeBackgroundToBlack()), i > 0 && o > i ? a(c.LoginButtonElement).addClass("stuck") : i > 0 && o < i && a(c.LoginButtonElement).removeClass("stuck");
                    if (p.is(".open")) {
                        var q = a("body").data("device");
                        q !== "mobile" && q !== "tablet" && !navigator.userAgent.match(/iPad|iPhone|Android|BlackBerry|Windows Phone|webOS/i) && c.CloseSearchBar()
                    }
                    if (o <= 0) f.width("auto").removeClass("hidden hiding");
                    else if (o > 0 && o < h) {
                        var r = g - o > 6 ? g - o : 6;
                        f.width(r).removeClass("hidden").addClass("hiding")
                    } else f.width("0").removeClass("hiding").addClass("hidden")
                });
                var k = !1,
                    l = function(b) {
                        var d = a(this).parents(c.HeaderElement),
                            e = a(this).parents(c.HeaderDropDownClickElement),
                            f = a(this).parent().find(c.HeaderDropDownSectionElement),
                            g = a(c.HeaderSearchBarElement),
                            h = a(c.SideMenuElement);
                        g.is(".open") && c.CloseSearchBar(), h.is(".open") && c.CloseSideMenu();
                        if (d.is(".open-dropdown")) return a(c.HeaderElement).hasClass("black") && c.FadeBackgroundToBlack(), c.CloseDropDown(), k = !1, !1;
                        a(c.HeaderElement).hasClass("black-linear") && c.FadeBackgroundToBlack(), d.addClass("hover-intent open-dropdown"), a(c.HeaderDropDownClickElement).removeClass("hover-intent"), e.addClass("hover-intent"), a(c.HeaderDropDownSectionElement).removeClass("hover-intent"), f.addClass("hover-intent"), k || (c.DropIconsDown(a(c.HeaderDropDownSubSectionRowElement + ".open")), k = !0), a(c.HeaderDropDownTitleElement).find(".accessible-text").text("Close Drop Down."), b.preventDefault()
                    };
                "ontouchstart" in window ? a(c.HeaderDropDownTitleLinkElement).on("click", l) : (a(c.HeaderDropDownTitleLinkElement).on("click", l), a(c.HeaderDropDownTitleElement).is(":visible") && (a(c.HeaderDropDownTitleElement).hoverIntent(function() {
                    var b = a(this).parents(c.HeaderElement),
                        d = a(this).parents(c.HeaderDropDownClickElement),
                        e = a(this).find(c.HeaderDropDownSectionElement),
                        f = a(c.HeaderSearchBarElement),
                        g = a(c.SideMenuElement);
                    f.is(".open") && c.CloseSearchBar(), g.is(".open") && c.CloseSideMenu(), a(c.HeaderElement).hasClass("black-linear") && c.FadeBackgroundToBlack(), b.addClass("hover-intent open-dropdown"), a(c.HeaderDropDownClickElement).removeClass("hover-intent"), d.addClass("hover-intent"), a(c.HeaderDropDownSectionElement).removeClass("hover-intent"), e.addClass("hover-intent"), k || (c.DropIconsDown(a(c.HeaderDropDownSubSectionRowElement + ".open")), window.CHASE && window.CHASE.analytics && window.CHASE.analytics.trackHoverLoad && CHASE.analytics.trackHoverLoad("hd_hover", "hd_exploreproducts"), k = !0), a(c.HeaderDropDownTitleElement).find(".accessible-text").text("Close Drop Down.")
                }), a(c.MainElement + "," + c.SignInWrapperElement).on("mousemove", function(b) {
                    a(c.HeaderElement).hasClass("open-dropdown") && (a(c.HeaderElement).hasClass("black") && c.FadeBackgroundToBlack(), c.CloseDropDown(), k = !1)
                }))), c.SetupSearchBarEvents(c.oldIEBrowser), e.on("keydown", function(b) {
                    var d = a(b.target),
                        e = a(c.HeaderDropDownSubSectionRowElement).children(),
                        f = e.last();
                    if (b.keyCode === 13) d.is(c.SideMenuClickElement) ? (a(c.SideMenuElement).hasClass("open") ? c.CloseSideMenu() : (c.OpenSideMenu(), a(c.SideMenuPrimaryActiveLinkElement).focus()), b.preventDefault()) : d.is(c.SideMenuCloseElement) ? (c.CloseSideMenu(), a(c.SideMenuClickElement).focus(), b.preventDefault()) : d.is(c.HeaderSearchClickElement) ? (c.OpenSearchBar(), setTimeout(function() {
                        a(c.HeaderSearchInputElement).focus()
                    }, 50), b.preventDefault()) : d.is(c.HeaderDropDownTitleLinkElement) && (a(c.HeaderDropDownTitleLinkElement).click(), b.preventDefault());
                    else if (b.keyCode === 27) a(c.SideMenuElement).hasClass("open") ? (c.CloseSideMenu(), a(c.SideMenuClickElement).focus(), b.preventDefault()) : a(c.HeaderElement).hasClass("open-dropdown") ? (c.CloseDropDown(), a(c.HeaderDropDownTitleLinkElement).focus(), b.preventDefault()) : a(c.HeaderElement).hasClass("open") && (c.CloseSearchBar(), a(c.HeaderSearchClickElement).focus(), b.preventDefault());
                    else if (b.keyCode === 32) {
                        var g = a(c.LoginButtonElement + " a");
                        g.is(":focus") && (window.location.href = g.attr("href"), b.preventDefault())
                    } else {
                        if (b.which === 9 && b.shiftKey) return;
                        b.keyCode === 9 && a(c.HeaderElement).hasClass("open-dropdown") && f.find("a").is(":focus") && (a(c.HeaderDropDownTitleLinkElement).focus(), b.preventDefault())
                    }
                }), a(c.SideMenuClickElement + ",#skipToMainContent").on("focusin", function(b) {
                    a(c.SideMenuElement).is(".open") && a(c.SideMenuCloseElement).focus()
                })
            }
        }
    }), define("amd/mosaic", ["jquery"], function(a) {
        var b = {
            VersionB: ".mosaic.mosaic-version-b",
            Tiles: ".mosaic__tile",
            LastTileImage: ".mosaic__tile:visible:last [data-picture] span img",
            CheckForImageDownloadBeforeEqualizeHeights: function(a) {
                if (a.length > 0) var c = setInterval(function() {
                    a.find(b.LastTileImage)[0].complete && (b.EqualizeHeights(a.find(b.Tiles)), clearInterval(c))
                }, 200)
            },
            EqualizeHeights: function(b) {
                if (a(b).length > 0) {
                    var c = 0,
                        d = 0,
                        e = new Array,
                        f, g = 0;
                    a(b).each(function() {
                        f = a(this), a(f).height("auto"), g = f.position().top;
                        if (d != g) {
                            for (var b = 0; b < e.length; b++) e[b].height(c);
                            e.length = 0, d = g, c = f.height(), e.push(f)
                        } else e.push(f), c = c < f.height() ? f.height() : c;
                        for (var b = 0; b < e.length; b++) e[b].height(c)
                    })
                }
            }
        };
        return {
            init: function() {
                var c = a(window),
                    d = a(".main-content--dropzone"),
                    e = ".footer__module-footer__section--tile",
                    f = b.VersionB + " .mosaic__tile",
                    g = !1;
                c.load(function(c) {
                    a(b.VersionB).length > 0 && b.EqualizeHeights(f), b.EqualizeHeights(e)
                }), b.EqualizeHeights(e), c.on("resize", function(c) {
                    b.CheckForImageDownloadBeforeEqualizeHeights(a(b.VersionB)), b.EqualizeHeights(e), g = !1
                }), d.on("Chase:FeatureAppended", function(c, d) {
                    var e = a(d),
                        f = e.children(b.VersionB);
                    f.length > 0 && b.CheckForImageDownloadBeforeEqualizeHeights(f)
                }), c.on("scroll", function(d) {
                    if (!g) {
                        var e = c.scrollTop();
                        a(b.VersionB).length > 0 && a(b.VersionB).offset().top - 500 < e && (b.EqualizeHeights(f), g = !0)
                    }
                })
            },
            checkForImageDownloadBeforeEqualizeHeights: function(a) {
                b.CheckForImageDownloadBeforeEqualizeHeights(a)
            }
        }
    }), define("amd/video", ["jquery"], function(a) {
        var b = {
            Selector: "[data-video]",
            OriginXDataSelector: "video-origin-x",
            OriginYDataSelector: "video-origin-y",
            SetStyles: function() {
                var b = a(this.Selector);
                if (b.length > 0) {
                    var c = "",
                        d = b.data(this.OriginXDataSelector),
                        e = b.data(this.OriginYDataSelector),
                        f = this.CalculateScale(b.height());
                    d !== undefined && e !== undefined && (c += this.GenerateOriginSelector(d, e)), c += this.GenerateScaleSelector(f), b.attr("style", c)
                }
            },
            CalculateScale: function(b) {
                var c = 1,
                    d = 16 / 9,
                    e = a(window).width() / b;
                return d < e ? c = e / d : e < d && (c = d / e), this.RoundNumber(c)
            },
            GenerateOriginSelector: function(a, b) {
                return "-webkit-transform-origin: " + a + " " + b + ";" + "-ms-transform-origin: " + a + " " + b + ";" + "transform-origin: " + a + " " + b + ";"
            },
            GenerateScaleSelector: function(a) {
                return "-webkit-transform: scale(" + a + ");" + "-ms-transform: scale(" + a + ");" + "transform: scale(" + a + ");"
            },
            RoundNumber: function(a) {
                return +a.toFixed(2) + .01
            }
        };
        return {
            init: function() {
                var c = a(window);
                b.SetStyles(), c.on("resize", function(c) {
                    a(b.Selector).length > 0 && b.SetStyles()
                })
            }
        }
    }), ! function(a, b, c) {
        function d(a, c) {
            this.wrapper = "string" == typeof a ? b.querySelector(a) : a, this.scroller = this.wrapper.children[0], this.scrollerStyle = this.scroller.style, this.options = {
                resizeScrollbars: !0,
                mouseWheelSpeed: 20,
                snapThreshold: .334,
                startX: 0,
                startY: 0,
                scrollY: !0,
                directionLockThreshold: 5,
                momentum: !0,
                bounce: !0,
                bounceTime: 600,
                bounceEasing: "",
                preventDefault: !0,
                preventDefaultException: {
                    tagName: /^(INPUT|TEXTAREA|BUTTON|SELECT)$/
                },
                HWCompositing: !0,
                useTransition: !0,
                useTransform: !0
            };
            for (var d in c) this.options[d] = c[d];
            this.translateZ = this.options.HWCompositing && h.hasPerspective ? " translateZ(0)" : "", this.options.useTransition = h.hasTransition && this.options.useTransition, this.options.useTransform = h.hasTransform && this.options.useTransform, this.options.eventPassthrough = this.options.eventPassthrough === !0 ? "vertical" : this.options.eventPassthrough, this.options.preventDefault = !this.options.eventPassthrough && this.options.preventDefault, this.options.scrollY = "vertical" == this.options.eventPassthrough ? !1 : this.options.scrollY, this.options.scrollX = "horizontal" == this.options.eventPassthrough ? !1 : this.options.scrollX, this.options.freeScroll = this.options.freeScroll && !this.options.eventPassthrough, this.options.directionLockThreshold = this.options.eventPassthrough ? 0 : this.options.directionLockThreshold, this.options.bounceEasing = "string" == typeof this.options.bounceEasing ? h.ease[this.options.bounceEasing] || h.ease.circular : this.options.bounceEasing, this.options.resizePolling = void 0 === this.options.resizePolling ? 60 : this.options.resizePolling, this.options.tap === !0 && (this.options.tap = "tap"), "scale" == this.options.shrinkScrollbars && (this.options.useTransition = !1), this.options.invertWheelDirection = this.options.invertWheelDirection ? -1 : 1, this.x = 0, this.y = 0, this.directionX = 0, this.directionY = 0, this._events = {}, this._init(), this.refresh(), this.scrollTo(this.options.startX, this.options.startY), this.enable()
        }

        function e(a, c, d) {
            var e = b.createElement("div"),
                f = b.createElement("div");
            return d === !0 && (e.style.cssText = "position:absolute;z-index:9999", f.style.cssText = "-webkit-box-sizing:border-box;-moz-box-sizing:border-box;box-sizing:border-box;position:absolute;background:rgba(0,0,0,0.5);border:1px solid rgba(255,255,255,0.9);border-radius:3px"), f.className = "iScrollIndicator", "h" == a ? (d === !0 && (e.style.cssText += ";height:7px;left:2px;right:2px;bottom:0", f.style.height = "100%"), e.className = "iScrollHorizontalScrollbar") : (d === !0 && (e.style.cssText += ";width:7px;bottom:2px;top:2px;right:1px", f.style.width = "100%"), e.className = "iScrollVerticalScrollbar"), e.style.cssText += ";overflow:hidden", c || (e.style.pointerEvents = "none"), e.appendChild(f), e
        }

        function f(c, d) {
            this.wrapper = "string" == typeof d.el ? b.querySelector(d.el) : d.el, this.wrapperStyle = this.wrapper.style, this.indicator = this.wrapper.children[0], this.indicatorStyle = this.indicator.style, this.scroller = c, this.options = {
                listenX: !0,
                listenY: !0,
                interactive: !1,
                resize: !0,
                defaultScrollbars: !1,
                shrink: !1,
                fade: !1,
                speedRatioX: 0,
                speedRatioY: 0
            };
            for (var e in d) this.options[e] = d[e];
            this.sizeRatioX = 1, this.sizeRatioY = 1, this.maxPosX = 0, this.maxPosY = 0, this.options.interactive && (this.options.disableTouch || (h.addEvent(this.indicator, "touchstart", this), h.addEvent(a, "touchend", this)), this.options.disablePointer || (h.addEvent(this.indicator, h.prefixPointerEvent("pointerdown"), this), h.addEvent(a, h.prefixPointerEvent("pointerup"), this)), this.options.disableMouse || (h.addEvent(this.indicator, "mousedown", this), h.addEvent(a, "mouseup", this))), this.options.fade && (this.wrapperStyle[h.style.transform] = this.scroller.translateZ, this.wrapperStyle[h.style.transitionDuration] = h.isBadAndroid ? "0.001s" : "0ms", this.wrapperStyle.opacity = "0")
        }
        var g = a.requestAnimationFrame || a.webkitRequestAnimationFrame || a.mozRequestAnimationFrame || a.oRequestAnimationFrame || a.msRequestAnimationFrame || function(b) {
                a.setTimeout(b, 1e3 / 60)
            },
            h = function() {
                function d(a) {
                    return g === !1 ? !1 : "" === g ? a : g + a.charAt(0).toUpperCase() + a.substr(1)
                }
                var e = {},
                    f = b.createElement("div").style,
                    g = function() {
                        for (var a, b = ["t", "webkitT", "MozT", "msT", "OT"], c = 0, d = b.length; d > c; c++)
                            if (a = b[c] + "ransform", a in f) return b[c].substr(0, b[c].length - 1);
                        return !1
                    }();
                e.getTime = Date.now || function() {
                    return (new Date).getTime()
                }, e.extend = function(a, b) {
                    for (var c in b) a[c] = b[c]
                }, e.addEvent = function(a, b, c, d) {
                    a.addEventListener(b, c, !!d)
                }, e.removeEvent = function(a, b, c, d) {
                    a.removeEventListener(b, c, !!d)
                }, e.prefixPointerEvent = function(b) {
                    return a.MSPointerEvent ? "MSPointer" + b.charAt(9).toUpperCase() + b.substr(10) : b
                }, e.momentum = function(a, b, d, e, f, g) {
                    var h, i, j = a - b,
                        k = c.abs(j) / d;
                    return g = void 0 === g ? 6e-4 : g, h = a + k * k / (2 * g) * (0 > j ? -1 : 1), i = k / g, e > h ? (h = f ? e - f / 2.5 * (k / 8) : e, j = c.abs(h - a), i = j / k) : h > 0 && (h = f ? f / 2.5 * (k / 8) : 0, j = c.abs(a) + h, i = j / k), {
                        destination: c.round(h),
                        duration: i
                    }
                };
                var h = d("transform");
                return e.extend(e, {
                    hasTransform: h !== !1,
                    hasPerspective: d("perspective") in f,
                    hasTouch: "ontouchstart" in a,
                    hasPointer: a.PointerEvent || a.MSPointerEvent,
                    hasTransition: d("transition") in f
                }), e.isBadAndroid = /Android /.test(a.navigator.appVersion) && !/Chrome\/\d/.test(a.navigator.appVersion), e.extend(e.style = {}, {
                    transform: h,
                    transitionTimingFunction: d("transitionTimingFunction"),
                    transitionDuration: d("transitionDuration"),
                    transitionDelay: d("transitionDelay"),
                    transformOrigin: d("transformOrigin")
                }), e.hasClass = function(a, b) {
                    var c = new RegExp("(^|\\s)" + b + "(\\s|$)");
                    return c.test(a.className)
                }, e.addClass = function(a, b) {
                    if (!e.hasClass(a, b)) {
                        var c = a.className.split(" ");
                        c.push(b), a.className = c.join(" ")
                    }
                }, e.removeClass = function(a, b) {
                    if (e.hasClass(a, b)) {
                        var c = new RegExp("(^|\\s)" + b + "(\\s|$)", "g");
                        a.className = a.className.replace(c, " ")
                    }
                }, e.offset = function(a) {
                    for (var b = -a.offsetLeft, c = -a.offsetTop; a = a.offsetParent;) b -= a.offsetLeft, c -= a.offsetTop;
                    return {
                        left: b,
                        top: c
                    }
                }, e.preventDefaultException = function(a, b) {
                    for (var c in b)
                        if (b[c].test(a[c])) return !0;
                    return !1
                }, e.extend(e.eventType = {}, {
                    touchstart: 1,
                    touchmove: 1,
                    touchend: 1,
                    mousedown: 2,
                    mousemove: 2,
                    mouseup: 2,
                    pointerdown: 3,
                    pointermove: 3,
                    pointerup: 3,
                    MSPointerDown: 3,
                    MSPointerMove: 3,
                    MSPointerUp: 3
                }), e.extend(e.ease = {}, {
                    quadratic: {
                        style: "cubic-bezier(0.25, 0.46, 0.45, 0.94)",
                        fn: function(a) {
                            return a * (2 - a)
                        }
                    },
                    circular: {
                        style: "cubic-bezier(0.1, 0.57, 0.1, 1)",
                        fn: function(a) {
                            return c.sqrt(1 - --a * a)
                        }
                    },
                    back: {
                        style: "cubic-bezier(0.175, 0.885, 0.32, 1.275)",
                        fn: function(a) {
                            var b = 4;
                            return (a -= 1) * a * ((b + 1) * a + b) + 1
                        }
                    },
                    bounce: {
                        style: "",
                        fn: function(a) {
                            return (a /= 1) < 1 / 2.75 ? 7.5625 * a * a : 2 / 2.75 > a ? 7.5625 * (a -= 1.5 / 2.75) * a + .75 : 2.5 / 2.75 > a ? 7.5625 * (a -= 2.25 / 2.75) * a + .9375 : 7.5625 * (a -= 2.625 / 2.75) * a + .984375
                        }
                    },

                    elastic: {
                        style: "",
                        fn: function(a) {
                            var b = .22,
                                d = .4;
                            return 0 === a ? 0 : 1 == a ? 1 : d * c.pow(2, -10 * a) * c.sin(2 * (a - b / 4) * c.PI / b) + 1
                        }
                    }
                }), e.tap = function(a, c) {
                    var d = b.createEvent("Event");
                    d.initEvent(c, !0, !0), d.pageX = a.pageX, d.pageY = a.pageY, a.target.dispatchEvent(d)
                }, e.click = function(a) {
                    var c, d = a.target;
                    /(SELECT|INPUT|TEXTAREA)/i.test(d.tagName) || (c = b.createEvent("MouseEvents"), c.initMouseEvent("click", !0, !0, a.view, 1, d.screenX, d.screenY, d.clientX, d.clientY, a.ctrlKey, a.altKey, a.shiftKey, a.metaKey, 0, null), c._constructed = !0, d.dispatchEvent(c))
                }, e
            }();
        d.prototype = {
            version: "5.1.3",
            _init: function() {
                this._initEvents(), (this.options.scrollbars || this.options.indicators) && this._initIndicators(), this.options.mouseWheel && this._initWheel(), this.options.snap && this._initSnap(), this.options.keyBindings && this._initKeys()
            },
            destroy: function() {
                this._initEvents(!0), this._execEvent("destroy")
            },
            _transitionEnd: function(a) {
                a.target == this.scroller && this.isInTransition && (this._transitionTime(), this.resetPosition(this.options.bounceTime) || (this.isInTransition = !1, this._execEvent("scrollEnd")))
            },
            _start: function(a) {
                if (!(1 != h.eventType[a.type] && 0 !== a.button || !this.enabled || this.initiated && h.eventType[a.type] !== this.initiated)) {
                    !this.options.preventDefault || h.isBadAndroid || h.preventDefaultException(a.target, this.options.preventDefaultException) || a.preventDefault();
                    var b, d = a.touches ? a.touches[0] : a;
                    this.initiated = h.eventType[a.type], this.moved = !1, this.distX = 0, this.distY = 0, this.directionX = 0, this.directionY = 0, this.directionLocked = 0, this._transitionTime(), this.startTime = h.getTime(), this.options.useTransition && this.isInTransition ? (this.isInTransition = !1, b = this.getComputedPosition(), this._translate(c.round(b.x), c.round(b.y)), this._execEvent("scrollEnd")) : !this.options.useTransition && this.isAnimating && (this.isAnimating = !1, this._execEvent("scrollEnd")), this.startX = this.x, this.startY = this.y, this.absStartX = this.x, this.absStartY = this.y, this.pointX = d.pageX, this.pointY = d.pageY, this._execEvent("beforeScrollStart")
                }
            },
            _move: function(a) {
                if (this.enabled && h.eventType[a.type] === this.initiated) {
                    this.options.preventDefault && a.preventDefault();
                    var b, d, e, f, g = a.touches ? a.touches[0] : a,
                        i = g.pageX - this.pointX,
                        j = g.pageY - this.pointY,
                        k = h.getTime();
                    if (this.pointX = g.pageX, this.pointY = g.pageY, this.distX += i, this.distY += j, e = c.abs(this.distX), f = c.abs(this.distY), !(k - this.endTime > 300 && 10 > e && 10 > f)) {
                        if (this.directionLocked || this.options.freeScroll || (this.directionLocked = e > f + this.options.directionLockThreshold ? "h" : f >= e + this.options.directionLockThreshold ? "v" : "n"), "h" == this.directionLocked) {
                            if ("vertical" == this.options.eventPassthrough) a.preventDefault();
                            else if ("horizontal" == this.options.eventPassthrough) return void(this.initiated = !1);
                            j = 0
                        } else if ("v" == this.directionLocked) {
                            if ("horizontal" == this.options.eventPassthrough) a.preventDefault();
                            else if ("vertical" == this.options.eventPassthrough) return void(this.initiated = !1);
                            i = 0
                        }
                        i = this.hasHorizontalScroll ? i : 0, j = this.hasVerticalScroll ? j : 0, b = this.x + i, d = this.y + j, (b > 0 || b < this.maxScrollX) && (b = this.options.bounce ? this.x + i / 3 : b > 0 ? 0 : this.maxScrollX), (d > 0 || d < this.maxScrollY) && (d = this.options.bounce ? this.y + j / 3 : d > 0 ? 0 : this.maxScrollY), this.directionX = i > 0 ? -1 : 0 > i ? 1 : 0, this.directionY = j > 0 ? -1 : 0 > j ? 1 : 0, this.moved || this._execEvent("scrollStart"), this.moved = !0, this._translate(b, d), k - this.startTime > 300 && (this.startTime = k, this.startX = this.x, this.startY = this.y)
                    }
                }
            },
            _end: function(a) {
                if (this.enabled && h.eventType[a.type] === this.initiated) {
                    this.options.preventDefault && !h.preventDefaultException(a.target, this.options.preventDefaultException) && a.preventDefault();
                    var b, d, e = (a.changedTouches ? a.changedTouches[0] : a, h.getTime() - this.startTime),
                        f = c.round(this.x),
                        g = c.round(this.y),
                        i = c.abs(f - this.startX),
                        j = c.abs(g - this.startY),
                        k = 0,
                        l = "";
                    if (this.isInTransition = 0, this.initiated = 0, this.endTime = h.getTime(), !this.resetPosition(this.options.bounceTime)) {
                        if (this.scrollTo(f, g), !this.moved) return this.options.tap && h.tap(a, this.options.tap), this.options.click && h.click(a), void this._execEvent("scrollCancel");
                        if (this._events.flick && 200 > e && 100 > i && 100 > j) return void this._execEvent("flick");
                        if (this.options.momentum && 300 > e && (b = this.hasHorizontalScroll ? h.momentum(this.x, this.startX, e, this.maxScrollX, this.options.bounce ? this.wrapperWidth : 0, this.options.deceleration) : {
                                destination: f,
                                duration: 0
                            }, d = this.hasVerticalScroll ? h.momentum(this.y, this.startY, e, this.maxScrollY, this.options.bounce ? this.wrapperHeight : 0, this.options.deceleration) : {
                                destination: g,
                                duration: 0
                            }, f = b.destination, g = d.destination, k = c.max(b.duration, d.duration), this.isInTransition = 1), this.options.snap) {
                            var m = this._nearestSnap(f, g);
                            this.currentPage = m, k = this.options.snapSpeed || c.max(c.max(c.min(c.abs(f - m.x), 1e3), c.min(c.abs(g - m.y), 1e3)), 300), f = m.x, g = m.y, this.directionX = 0, this.directionY = 0, l = this.options.bounceEasing
                        }
                        return f != this.x || g != this.y ? ((f > 0 || f < this.maxScrollX || g > 0 || g < this.maxScrollY) && (l = h.ease.quadratic), void this.scrollTo(f, g, k, l)) : void this._execEvent("scrollEnd")
                    }
                }
            },
            _resize: function() {
                var a = this;
                clearTimeout(this.resizeTimeout), this.resizeTimeout = setTimeout(function() {
                    a.refresh()
                }, this.options.resizePolling)
            },
            resetPosition: function(a) {
                var b = this.x,
                    c = this.y;
                return a = a || 0, !this.hasHorizontalScroll || this.x > 0 ? b = 0 : this.x < this.maxScrollX && (b = this.maxScrollX), !this.hasVerticalScroll || this.y > 0 ? c = 0 : this.y < this.maxScrollY && (c = this.maxScrollY), b == this.x && c == this.y ? !1 : (this.scrollTo(b, c, a, this.options.bounceEasing), !0)
            },
            disable: function() {
                this.enabled = !1
            },
            enable: function() {
                this.enabled = !0
            },
            refresh: function() {
                this.wrapper.offsetHeight, this.wrapperWidth = this.wrapper.clientWidth, this.wrapperHeight = this.wrapper.clientHeight, this.scrollerWidth = this.scroller.offsetWidth, this.scrollerHeight = this.scroller.offsetHeight, this.maxScrollX = this.wrapperWidth - this.scrollerWidth, this.maxScrollY = this.wrapperHeight - this.scrollerHeight, this.hasHorizontalScroll = this.options.scrollX && this.maxScrollX < 0, this.hasVerticalScroll = this.options.scrollY && this.maxScrollY < 0, this.hasHorizontalScroll || (this.maxScrollX = 0, this.scrollerWidth = this.wrapperWidth), this.hasVerticalScroll || (this.maxScrollY = 0, this.scrollerHeight = this.wrapperHeight), this.endTime = 0, this.directionX = 0, this.directionY = 0, this.wrapperOffset = h.offset(this.wrapper), this._execEvent("refresh"), this.resetPosition()
            },
            on: function(a, b) {
                this._events[a] || (this._events[a] = []), this._events[a].push(b)
            },
            off: function(a, b) {
                if (this._events[a]) {
                    var c = this._events[a].indexOf(b);
                    c > -1 && this._events[a].splice(c, 1)
                }
            },
            _execEvent: function(a) {
                if (this._events[a]) {
                    var b = 0,
                        c = this._events[a].length;
                    if (c)
                        for (; c > b; b++) this._events[a][b].apply(this, [].slice.call(arguments, 1))
                }
            },
            scrollBy: function(a, b, c, d) {
                a = this.x + a, b = this.y + b, c = c || 0, this.scrollTo(a, b, c, d)
            },
            scrollTo: function(a, b, c, d) {
                d = d || h.ease.circular, this.isInTransition = this.options.useTransition && c > 0, !c || this.options.useTransition && d.style ? (this._transitionTimingFunction(d.style), this._transitionTime(c), this._translate(a, b)) : this._animate(a, b, c, d.fn)
            },
            scrollToElement: function(a, b, d, e, f) {
                if (a = a.nodeType ? a : this.scroller.querySelector(a)) {
                    var g = h.offset(a);
                    g.left -= this.wrapperOffset.left, g.top -= this.wrapperOffset.top, d === !0 && (d = c.round(a.offsetWidth / 2 - this.wrapper.offsetWidth / 2)), e === !0 && (e = c.round(a.offsetHeight / 2 - this.wrapper.offsetHeight / 2)), g.left -= d || 0, g.top -= e || 0, g.left = g.left > 0 ? 0 : g.left < this.maxScrollX ? this.maxScrollX : g.left, g.top = g.top > 0 ? 0 : g.top < this.maxScrollY ? this.maxScrollY : g.top, b = void 0 === b || null === b || "auto" === b ? c.max(c.abs(this.x - g.left), c.abs(this.y - g.top)) : b, this.scrollTo(g.left, g.top, b, f)
                }
            },
            _transitionTime: function(a) {
                if (a = a || 0, this.scrollerStyle[h.style.transitionDuration] = a + "ms", !a && h.isBadAndroid && (this.scrollerStyle[h.style.transitionDuration] = "0.001s"), this.indicators)
                    for (var b = this.indicators.length; b--;) this.indicators[b].transitionTime(a)
            },
            _transitionTimingFunction: function(a) {
                if (this.scrollerStyle[h.style.transitionTimingFunction] = a, this.indicators)
                    for (var b = this.indicators.length; b--;) this.indicators[b].transitionTimingFunction(a)
            },
            _translate: function(a, b) {
                if (this.options.useTransform ? this.scrollerStyle[h.style.transform] = "translate(" + a + "px," + b + "px)" + this.translateZ : (a = c.round(a), b = c.round(b), this.scrollerStyle.left = a + "px", this.scrollerStyle.top = b + "px"), this.x = a, this.y = b, this.indicators)
                    for (var d = this.indicators.length; d--;) this.indicators[d].updatePosition()
            },
            _initEvents: function(b) {

                var c = b ? h.removeEvent : h.addEvent,
                    d = this.options.bindToWrapper ? this.wrapper : a;
                c(a, "orientationchange", this), c(a, "resize", this), this.options.click && c(this.wrapper, "click", this, !0), this.options.disableMouse || (c(this.wrapper, "mousedown", this), c(d, "mousemove", this), c(d, "mousecancel", this), c(d, "mouseup", this)), h.hasPointer && !this.options.disablePointer && (c(this.wrapper, h.prefixPointerEvent("pointerdown"), this), c(d, h.prefixPointerEvent("pointermove"), this), c(d, h.prefixPointerEvent("pointercancel"), this), c(d, h.prefixPointerEvent("pointerup"), this)), h.hasTouch && !this.options.disableTouch && (c(this.wrapper, "touchstart", this), c(d, "touchmove", this), c(d, "touchcancel", this), c(d, "touchend", this)), c(this.scroller, "transitionend", this), c(this.scroller, "webkitTransitionEnd", this), c(this.scroller, "oTransitionEnd", this), c(this.scroller, "MSTransitionEnd", this)
            },
            getComputedPosition: function() {
                var b, c, d = a.getComputedStyle(this.scroller, null);
                return this.options.useTransform ? (d = d[h.style.transform].split(")")[0].split(", "), b = +(d[12] || d[4]), c = +(d[13] || d[5])) : (b = +d.left.replace(/[^-\d.]/g, ""), c = +d.top.replace(/[^-\d.]/g, "")), {
                    x: b,
                    y: c
                }
            },
            _initIndicators: function() {
                function a(a) {
                    for (var b = h.indicators.length; b--;) a.call(h.indicators[b])
                }
                var b, c = this.options.interactiveScrollbars,
                    d = "string" != typeof this.options.scrollbars,
                    g = [],
                    h = this;
                this.indicators = [], this.options.scrollbars && (this.options.scrollY && (b = {
                    el: e("v", c, this.options.scrollbars),
                    interactive: c,
                    defaultScrollbars: !0,
                    customStyle: d,
                    resize: this.options.resizeScrollbars,
                    shrink: this.options.shrinkScrollbars,
                    fade: this.options.fadeScrollbars,
                    listenX: !1
                }, this.wrapper.appendChild(b.el), g.push(b)), this.options.scrollX && (b = {
                    el: e("h", c, this.options.scrollbars),
                    interactive: c,
                    defaultScrollbars: !0,
                    customStyle: d,
                    resize: this.options.resizeScrollbars,
                    shrink: this.options.shrinkScrollbars,
                    fade: this.options.fadeScrollbars,
                    listenY: !1
                }, this.wrapper.appendChild(b.el), g.push(b))), this.options.indicators && (g = g.concat(this.options.indicators));
                for (var i = g.length; i--;) this.indicators.push(new f(this, g[i]));
                this.options.fadeScrollbars && (this.on("scrollEnd", function() {
                    a(function() {
                        this.fade()
                    })
                }), this.on("scrollCancel", function() {
                    a(function() {
                        this.fade()
                    })
                }), this.on("scrollStart", function() {
                    a(function() {
                        this.fade(1)
                    })
                }), this.on("beforeScrollStart", function() {
                    a(function() {
                        this.fade(1, !0)
                    })
                })), this.on("refresh", function() {
                    a(function() {
                        this.refresh()
                    })
                }), this.on("destroy", function() {
                    a(function() {
                        this.destroy()
                    }), delete this.indicators
                })
            },
            _initWheel: function() {
                h.addEvent(this.wrapper, "wheel", this), h.addEvent(this.wrapper, "mousewheel", this), h.addEvent(this.wrapper, "DOMMouseScroll", this), this.on("destroy", function() {
                    h.removeEvent(this.wrapper, "wheel", this), h.removeEvent(this.wrapper, "mousewheel", this), h.removeEvent(this.wrapper, "DOMMouseScroll", this)
                })
            },
            _wheel: function(a) {
                if (this.enabled) {
                    a.preventDefault(), a.stopPropagation();
                    var b, d, e, f, g = this;
                    if (void 0 === this.wheelTimeout && g._execEvent("scrollStart"), clearTimeout(this.wheelTimeout), this.wheelTimeout = setTimeout(function() {
                            g._execEvent("scrollEnd"), g.wheelTimeout = void 0
                        }, 400), "deltaX" in a) 1 === a.deltaMode ? (b = -a.deltaX * this.options.mouseWheelSpeed, d = -a.deltaY * this.options.mouseWheelSpeed) : (b = -a.deltaX, d = -a.deltaY);
                    else if ("wheelDeltaX" in a) b = a.wheelDeltaX / 120 * this.options.mouseWheelSpeed, d = a.wheelDeltaY / 120 * this.options.mouseWheelSpeed;
                    else if ("wheelDelta" in a) b = d = a.wheelDelta / 120 * this.options.mouseWheelSpeed;
                    else {
                        if (!("detail" in a)) return;
                        b = d = -a.detail / 3 * this.options.mouseWheelSpeed
                    }
                    if (b *= this.options.invertWheelDirection, d *= this.options.invertWheelDirection, this.hasVerticalScroll || (b = d, d = 0), this.options.snap) return e = this.currentPage.pageX, f = this.currentPage.pageY, b > 0 ? e-- : 0 > b && e++, d > 0 ? f-- : 0 > d && f++, void this.goToPage(e, f);
                    e = this.x + c.round(this.hasHorizontalScroll ? b : 0), f = this.y + c.round(this.hasVerticalScroll ? d : 0), e > 0 ? e = 0 : e < this.maxScrollX && (e = this.maxScrollX), f > 0 ? f = 0 : f < this.maxScrollY && (f = this.maxScrollY), this.scrollTo(e, f, 0)
                }
            },
            _initSnap: function() {
                this.currentPage = {}, "string" == typeof this.options.snap && (this.options.snap = this.scroller.querySelectorAll(this.options.snap)), this.on("refresh", function() {
                    var a, b, d, e, f, g, h = 0,
                        i = 0,
                        j = 0,
                        k = this.options.snapStepX || this.wrapperWidth,
                        l = this.options.snapStepY || this.wrapperHeight;
                    if (this.pages = [], this.wrapperWidth && this.wrapperHeight && this.scrollerWidth && this.scrollerHeight) {
                        if (this.options.snap === !0)
                            for (d = c.round(k / 2), e = c.round(l / 2); j > -this.scrollerWidth;) {
                                for (this.pages[h] = [], a = 0, f = 0; f > -this.scrollerHeight;) this.pages[h][a] = {
                                    x: c.max(j, this.maxScrollX),
                                    y: c.max(f, this.maxScrollY),
                                    width: k,
                                    height: l,
                                    cx: j - d,
                                    cy: f - e
                                }, f -= l, a++;
                                j -= k, h++
                            } else
                                for (g = this.options.snap, a = g.length, b = -1; a > h; h++)(0 === h || g[h].offsetLeft <= g[h - 1].offsetLeft) && (i = 0, b++), this.pages[i] || (this.pages[i] = []), j = c.max(-g[h].offsetLeft, this.maxScrollX), f = c.max(-g[h].offsetTop, this.maxScrollY), d = j - c.round(g[h].offsetWidth / 2), e = f - c.round(g[h].offsetHeight / 2), this.pages[i][b] = {
                                    x: j,
                                    y: f,
                                    width: g[h].offsetWidth,
                                    height: g[h].offsetHeight,
                                    cx: d,
                                    cy: e
                                }, j > this.maxScrollX && i++;
                        this.goToPage(this.currentPage.pageX || 0, this.currentPage.pageY || 0, 0), this.options.snapThreshold % 1 === 0 ? (this.snapThresholdX = this.options.snapThreshold, this.snapThresholdY = this.options.snapThreshold) : (this.snapThresholdX = c.round(this.pages[this.currentPage.pageX][this.currentPage.pageY].width * this.options.snapThreshold), this.snapThresholdY = c.round(this.pages[this.currentPage.pageX][this.currentPage.pageY].height * this.options.snapThreshold))
                    }
                }), this.on("flick", function() {
                    var a = this.options.snapSpeed || c.max(c.max(c.min(c.abs(this.x - this.startX), 1e3), c.min(c.abs(this.y - this.startY), 1e3)), 300);
                    this.goToPage(this.currentPage.pageX + this.directionX, this.currentPage.pageY + this.directionY, a)
                })
            },
            _nearestSnap: function(a, b) {
                if (!this.pages.length) return {
                    x: 0,
                    y: 0,
                    pageX: 0,
                    pageY: 0
                };
                var d = 0,
                    e = this.pages.length,
                    f = 0;
                if (c.abs(a - this.absStartX) < this.snapThresholdX && c.abs(b - this.absStartY) < this.snapThresholdY) return this.currentPage;
                for (a > 0 ? a = 0 : a < this.maxScrollX && (a = this.maxScrollX), b > 0 ? b = 0 : b < this.maxScrollY && (b = this.maxScrollY); e > d; d++)
                    if (a >= this.pages[d][0].cx) {
                        a = this.pages[d][0].x;
                        break
                    }
                for (e = this.pages[d].length; e > f; f++)
                    if (b >= this.pages[0][f].cy) {
                        b = this.pages[0][f].y;
                        break
                    }
                return d == this.currentPage.pageX && (d += this.directionX, 0 > d ? d = 0 : d >= this.pages.length && (d = this.pages.length - 1), a = this.pages[d][0].x), f == this.currentPage.pageY && (f += this.directionY, 0 > f ? f = 0 : f >= this.pages[0].length && (f = this.pages[0].length - 1), b = this.pages[0][f].y), {
                    x: a,
                    y: b,
                    pageX: d,
                    pageY: f
                }
            },
            goToPage: function(a, b, d, e) {
                e = e || this.options.bounceEasing, a >= this.pages.length ? a = this.pages.length - 1 : 0 > a && (a = 0), b >= this.pages[a].length ? b = this.pages[a].length - 1 : 0 > b && (b = 0);
                var f = this.pages[a][b].x,
                    g = this.pages[a][b].y;
                d = void 0 === d ? this.options.snapSpeed || c.max(c.max(c.min(c.abs(f - this.x), 1e3), c.min(c.abs(g - this.y), 1e3)), 300) : d, this.currentPage = {
                    x: f,
                    y: g,
                    pageX: a,
                    pageY: b
                }, this.scrollTo(f, g, d, e)
            },
            next: function(a, b) {
                var c = this.currentPage.pageX,
                    d = this.currentPage.pageY;
                c++, c >= this.pages.length && this.hasVerticalScroll && (c = 0, d++), this.goToPage(c, d, a, b)
            },
            prev: function(a, b) {
                var c = this.currentPage.pageX,
                    d = this.currentPage.pageY;
                c--, 0 > c && this.hasVerticalScroll && (c = 0, d--), this.goToPage(c, d, a, b)
            },
            _initKeys: function() {
                var b, c = {
                    pageUp: 33,
                    pageDown: 34,
                    end: 35,
                    home: 36,
                    left: 37,
                    up: 38,
                    right: 39,
                    down: 40
                };
                if ("object" == typeof this.options.keyBindings)
                    for (b in this.options.keyBindings) "string" == typeof this.options.keyBindings[b] && (this.options.keyBindings[b] = this.options.keyBindings[b].toUpperCase().charCodeAt(0));
                else this.options.keyBindings = {};
                for (b in c) this.options.keyBindings[b] = this.options.keyBindings[b] || c[b];
                h.addEvent(a, "keydown", this), this.on("destroy", function() {
                    h.removeEvent(a, "keydown", this)
                })
            },
            _key: function(a) {
                if (this.enabled) {
                    var b, d = this.options.snap,
                        e = d ? this.currentPage.pageX : this.x,
                        f = d ? this.currentPage.pageY : this.y,
                        g = h.getTime(),
                        i = this.keyTime || 0,
                        j = .25;
                    switch (this.options.useTransition && this.isInTransition && (b = this.getComputedPosition(), this._translate(c.round(b.x), c.round(b.y)), this.isInTransition = !1), this.keyAcceleration = 200 > g - i ? c.min(this.keyAcceleration + j, 50) : 0, a.keyCode) {
                        case this.options.keyBindings.pageUp:
                            this.hasHorizontalScroll && !this.hasVerticalScroll ? e += d ? 1 : this.wrapperWidth : f += d ? 1 : this.wrapperHeight;
                            break;
                        case this.options.keyBindings.pageDown:
                            this.hasHorizontalScroll && !this.hasVerticalScroll ? e -= d ? 1 : this.wrapperWidth : f -= d ? 1 : this.wrapperHeight;
                            break;
                        case this.options.keyBindings.end:
                            e = d ? this.pages.length - 1 : this.maxScrollX, f = d ? this.pages[0].length - 1 : this.maxScrollY;
                            break;
                        case this.options.keyBindings.home:
                            e = 0, f = 0;
                            break;
                        case this.options.keyBindings.left:
                            e += d ? -1 : 5 + this.keyAcceleration >> 0;
                            break;
                        case this.options.keyBindings.up:
                            f += d ? 1 : 5 + this.keyAcceleration >> 0;
                            break;
                        case this.options.keyBindings.right:
                            e -= d ? -1 : 5 + this.keyAcceleration >> 0;
                            break;
                        case this.options.keyBindings.down:
                            f -= d ? 1 : 5 + this.keyAcceleration >> 0;
                            break;
                        default:
                            return
                    }
                    if (d) return void this.goToPage(e, f);
                    e > 0 ? (e = 0, this.keyAcceleration = 0) : e < this.maxScrollX && (e = this.maxScrollX, this.keyAcceleration = 0), f > 0 ? (f = 0, this.keyAcceleration = 0) : f < this.maxScrollY && (f = this.maxScrollY, this.keyAcceleration = 0), this.scrollTo(e, f, 0), this.keyTime = g
                }
            },
            _animate: function(a, b, c, d) {
                function e() {
                    var m, q, u, v = h.getTime();
                    return v >= l ? (f.isAnimating = !1, f._translate(a, b), void(f.resetPosition(f.options.bounceTime) || f._execEvent("scrollEnd"))) : (v = (v - k) / c, u = d(v), m = (a - i) * u + i, q = (b - j) * u + j, f._translate(m, q), void(f.isAnimating && g(e)))
                }
                var f = this,
                    i = this.x,
                    j = this.y,
                    k = h.getTime(),
                    l = k + c;
                this.isAnimating = !0, e()
            },
            handleEvent: function(a) {
                switch (a.type) {
                    case "touchstart":
                    case "pointerdown":
                    case "MSPointerDown":
                    case "mousedown":
                        this._start(a);
                        break;
                    case "touchmove":
                    case "pointermove":
                    case "MSPointerMove":
                    case "mousemove":
                        this._move(a);
                        break;
                    case "touchend":
                    case "pointerup":
                    case "MSPointerUp":
                    case "mouseup":
                    case "touchcancel":
                    case "pointercancel":
                    case "MSPointerCancel":
                    case "mousecancel":
                        this._end(a);
                        break;
                    case "orientationchange":
                    case "resize":
                        this._resize();
                        break;
                    case "transitionend":
                    case "webkitTransitionEnd":
                    case "oTransitionEnd":
                    case "MSTransitionEnd":
                        this._transitionEnd(a);
                        break;
                    case "wheel":
                    case "DOMMouseScroll":
                    case "mousewheel":
                        this._wheel(a);
                        break;
                    case "keydown":
                        this._key(a);
                        break;
                    case "click":
                        a._constructed || (a.preventDefault(), a.stopPropagation())
                }
            }
        }, f.prototype = {
            handleEvent: function(a) {
                switch (a.type) {
                    case "touchstart":
                    case "pointerdown":
                    case "MSPointerDown":
                    case "mousedown":
                        this._start(a);
                        break;
                    case "touchmove":
                    case "pointermove":
                    case "MSPointerMove":
                    case "mousemove":
                        this._move(a);
                        break;
                    case "touchend":
                    case "pointerup":
                    case "MSPointerUp":
                    case "mouseup":
                    case "touchcancel":
                    case "pointercancel":
                    case "MSPointerCancel":
                    case "mousecancel":
                        this._end(a)
                }
            },
            destroy: function() {
                this.options.interactive && (h.removeEvent(this.indicator, "touchstart", this), h.removeEvent(this.indicator, h.prefixPointerEvent("pointerdown"), this), h.removeEvent(this.indicator, "mousedown", this), h.removeEvent(a, "touchmove", this), h.removeEvent(a, h.prefixPointerEvent("pointermove"), this), h.removeEvent(a, "mousemove", this), h.removeEvent(a, "touchend", this), h.removeEvent(a, h.prefixPointerEvent("pointerup"), this), h.removeEvent(a, "mouseup", this)), this.options.defaultScrollbars && this.wrapper.parentNode.removeChild(this.wrapper)
            },
            _start: function(b) {
                var c = b.touches ? b.touches[0] : b;
                b.preventDefault(), b.stopPropagation(), this.transitionTime(), this.initiated = !0, this.moved = !1, this.lastPointX = c.pageX, this.lastPointY = c.pageY, this.startTime = h.getTime(), this.options.disableTouch || h.addEvent(a, "touchmove", this), this.options.disablePointer || h.addEvent(a, h.prefixPointerEvent("pointermove"), this), this.options.disableMouse || h.addEvent(a, "mousemove", this), this.scroller._execEvent("beforeScrollStart")
            },
            _move: function(a) {
                var b, c, d, e, f = a.touches ? a.touches[0] : a;
                h.getTime(), this.moved || this.scroller._execEvent("scrollStart"), this.moved = !0, b = f.pageX - this.lastPointX, this.lastPointX = f.pageX, c = f.pageY - this.lastPointY, this.lastPointY = f.pageY, d = this.x + b, e = this.y + c, this._pos(d, e), a.preventDefault(), a.stopPropagation()
            },
            _end: function(b) {
                if (this.initiated) {
                    if (this.initiated = !1, b.preventDefault(), b.stopPropagation(), h.removeEvent(a, "touchmove", this), h.removeEvent(a, h.prefixPointerEvent("pointermove"), this), h.removeEvent(a, "mousemove", this), this.scroller.options.snap) {
                        var d = this.scroller._nearestSnap(this.scroller.x, this.scroller.y),
                            e = this.options.snapSpeed || c.max(c.max(c.min(c.abs(this.scroller.x - d.x), 1e3), c.min(c.abs(this.scroller.y - d.y), 1e3)), 300);
                        (this.scroller.x != d.x || this.scroller.y != d.y) && (this.scroller.directionX = 0, this.scroller.directionY = 0, this.scroller.currentPage = d, this.scroller.scrollTo(d.x, d.y, e, this.scroller.options.bounceEasing))
                    }
                    this.moved && this.scroller._execEvent("scrollEnd")
                }
            },
            transitionTime: function(a) {
                a = a || 0, this.indicatorStyle[h.style.transitionDuration] = a + "ms", !a && h.isBadAndroid && (this.indicatorStyle[h.style.transitionDuration] = "0.001s")
            },
            transitionTimingFunction: function(a) {
                this.indicatorStyle[h.style.transitionTimingFunction] = a
            },
            refresh: function() {
                this.transitionTime(), this.indicatorStyle.display = this.options.listenX && !this.options.listenY ? this.scroller.hasHorizontalScroll ? "block" : "none" : this.options.listenY && !this.options.listenX ? this.scroller.hasVerticalScroll ? "block" : "none" : this.scroller.hasHorizontalScroll || this.scroller.hasVerticalScroll ? "block" : "none", this.scroller.hasHorizontalScroll && this.scroller.hasVerticalScroll ? (h.addClass(this.wrapper, "iScrollBothScrollbars"), h.removeClass(this.wrapper, "iScrollLoneScrollbar"), this.options.defaultScrollbars && this.options.customStyle && (this.options.listenX ? this.wrapper.style.right = "8px" : this.wrapper.style.bottom = "8px")) : (h.removeClass(this.wrapper, "iScrollBothScrollbars"), h.addClass(this.wrapper, "iScrollLoneScrollbar"), this.options.defaultScrollbars && this.options.customStyle && (this.options.listenX ? this.wrapper.style.right = "2px" : this.wrapper.style.bottom = "2px")), this.wrapper.offsetHeight, this.options.listenX && (this.wrapperWidth = this.wrapper.clientWidth, this.options.resize ? (this.indicatorWidth = c.max(c.round(this.wrapperWidth * this.wrapperWidth / (this.scroller.scrollerWidth || this.wrapperWidth || 1)), 8), this.indicatorStyle.width = this.indicatorWidth + "px") : this.indicatorWidth = this.indicator.clientWidth, this.maxPosX = this.wrapperWidth - this.indicatorWidth, "clip" == this.options.shrink ? (this.minBoundaryX = -this.indicatorWidth + 8, this.maxBoundaryX = this.wrapperWidth - 8) : (this.minBoundaryX = 0, this.maxBoundaryX = this.maxPosX), this.sizeRatioX = this.options.speedRatioX || this.scroller.maxScrollX && this.maxPosX / this.scroller.maxScrollX), this.options.listenY && (this.wrapperHeight = this.wrapper.clientHeight, this.options.resize ? (this.indicatorHeight = c.max(c.round(this.wrapperHeight * this.wrapperHeight / (this.scroller.scrollerHeight || this.wrapperHeight || 1)), 8), this.indicatorStyle.height = this.indicatorHeight + "px") : this.indicatorHeight = this.indicator.clientHeight, this.maxPosY = this.wrapperHeight - this.indicatorHeight, "clip" == this.options.shrink ? (this.minBoundaryY = -this.indicatorHeight + 8, this.maxBoundaryY = this.wrapperHeight - 8) : (this.minBoundaryY = 0, this.maxBoundaryY = this.maxPosY), this.maxPosY = this.wrapperHeight - this.indicatorHeight, this.sizeRatioY = this.options.speedRatioY || this.scroller.maxScrollY && this.maxPosY / this.scroller.maxScrollY), this.updatePosition()
            },
            updatePosition: function() {
                var a = this.options.listenX && c.round(this.sizeRatioX * this.scroller.x) || 0,
                    b = this.options.listenY && c.round(this.sizeRatioY * this.scroller.y) || 0;
                this.options.ignoreBoundaries || (a < this.minBoundaryX ? ("scale" == this.options.shrink && (this.width = c.max(this.indicatorWidth + a, 8), this.indicatorStyle.width = this.width + "px"), a = this.minBoundaryX) : a > this.maxBoundaryX ? "scale" == this.options.shrink ? (this.width = c.max(this.indicatorWidth - (a - this.maxPosX), 8), this.indicatorStyle.width = this.width + "px", a = this.maxPosX + this.indicatorWidth - this.width) : a = this.maxBoundaryX : "scale" == this.options.shrink && this.width != this.indicatorWidth && (this.width = this.indicatorWidth, this.indicatorStyle.width = this.width + "px"), b < this.minBoundaryY ? ("scale" == this.options.shrink && (this.height = c.max(this.indicatorHeight + 3 * b, 8), this.indicatorStyle.height = this.height + "px"), b = this.minBoundaryY) : b > this.maxBoundaryY ? "scale" == this.options.shrink ? (this.height = c.max(this.indicatorHeight - 3 * (b - this.maxPosY), 8), this.indicatorStyle.height = this.height + "px", b = this.maxPosY + this.indicatorHeight - this.height) : b = this.maxBoundaryY : "scale" == this.options.shrink && this.height != this.indicatorHeight && (this.height = this.indicatorHeight, this.indicatorStyle.height = this.height + "px")), this.x = a, this.y = b, this.scroller.options.useTransform ? this.indicatorStyle[h.style.transform] = "translate(" + a + "px," + b + "px)" + this.scroller.translateZ : (this.indicatorStyle.left = a + "px", this.indicatorStyle.top = b + "px")
            },
            _pos: function(a, b) {
                0 > a ? a = 0 : a > this.maxPosX && (a = this.maxPosX), 0 > b ? b = 0 : b > this.maxPosY && (b = this.maxPosY), a = this.options.listenX ? c.round(a / this.sizeRatioX) : this.scroller.x, b = this.options.listenY ? c.round(b / this.sizeRatioY) : this.scroller.y, this.scroller.scrollTo(a, b)
            },
            fade: function(a, b) {
                if (!b || this.visible) {
                    clearTimeout(this.fadeTimeout), this.fadeTimeout = null;
                    var c = a ? 250 : 500,
                        d = a ? 0 : 300;
                    a = a ? "1" : "0", this.wrapperStyle[h.style.transitionDuration] = c + "ms", this.fadeTimeout = setTimeout(function(a) {
                        this.wrapperStyle.opacity = a, this.visible = +a
                    }.bind(this, a), d)
                }
            }
        }, d.utils = h, "undefined" != typeof module && module.exports ? module.exports = d : a.IScroll = d
    }(window, document, Math), define("iscroll", function() {}),
    function() {
        function a(b, d) {
            function f(a, b) {
                return function() {
                    return a.apply(b, arguments)
                }
            }
            var e;
            d = d || {}, this.trackingClick = !1, this.trackingClickStart = 0, this.targetElement = null, this.touchStartX = 0, this.touchStartY = 0, this.lastTouchIdentifier = 0, this.touchBoundary = d.touchBoundary || 10, this.layer = b, this.tapDelay = d.tapDelay || 200, this.tapTimeout = d.tapTimeout || 700;
            if (a.notNeeded(b)) return;
            var g = ["onMouse", "onClick", "onTouchStart", "onTouchMove", "onTouchEnd", "onTouchCancel"],
                h = this;
            for (var i = 0, j = g.length; i < j; i++) h[g[i]] = f(h[g[i]], h);
            c && (b.addEventListener("mouseover", this.onMouse, !0), b.addEventListener("mousedown", this.onMouse, !0), b.addEventListener("mouseup", this.onMouse, !0)), b.addEventListener("click", this.onClick, !0), b.addEventListener("touchstart", this.onTouchStart, !1), b.addEventListener("touchmove", this.onTouchMove, !1), b.addEventListener("touchend", this.onTouchEnd, !1), b.addEventListener("touchcancel", this.onTouchCancel, !1), Event.prototype.stopImmediatePropagation || (b.removeEventListener = function(a, c, d) {
                var e = Node.prototype.removeEventListener;
                a === "click" ? e.call(b, a, c.hijacked || c, d) : e.call(b, a, c, d)
            }, b.addEventListener = function(a, c, d) {
                var e = Node.prototype.addEventListener;
                a === "click" ? e.call(b, a, c.hijacked || (c.hijacked = function(a) {
                    a.propagationStopped || c(a)
                }), d) : e.call(b, a, c, d)
            }), typeof b.onclick == "function" && (e = b.onclick, b.addEventListener("click", function(a) {
                e(a)
            }, !1), b.onclick = null)
        }
        var b = navigator.userAgent.indexOf("Windows Phone") >= 0,
            c = navigator.userAgent.indexOf("Android") > 0 && !b,
            d = /iP(ad|hone|od)/.test(navigator.userAgent) && !b,
            e = d && /OS 4_\d(_\d)?/.test(navigator.userAgent),
            f = d && /OS [6-7]_\d/.test(navigator.userAgent),
            g = navigator.userAgent.indexOf("BB10") > 0;
        a.prototype.needsClick = function(a) {
            switch (a.nodeName.toLowerCase()) {
                case "button":
                case "select":
                case "textarea":
                    if (a.disabled) return !0;
                    break;
                case "input":
                    if (d && a.type === "file" || a.disabled) return !0;
                    break;
                case "label":
                case "iframe":
                case "video":
                    return !0
            }
            return /\bneedsclick\b/.test(a.className)
        }, a.prototype.needsFocus = function(a) {
            switch (a.nodeName.toLowerCase()) {
                case "textarea":
                    return !0;
                case "select":
                    return !c;
                case "input":
                    switch (a.type) {
                        case "button":
                        case "checkbox":
                        case "file":
                        case "image":
                        case "radio":
                        case "submit":
                            return !1
                    }
                    return !a.disabled && !a.readOnly;
                default:
                    return /\bneedsfocus\b/.test(a.className)
            }
        }, a.prototype.sendClick = function(a, b) {
            var c, d;
            document.activeElement && document.activeElement !== a && document.activeElement.blur(), d = b.changedTouches[0], c = document.createEvent("MouseEvents"), c.initMouseEvent(this.determineEventType(a), !0, !0, window, 1, d.screenX, d.screenY, d.clientX, d.clientY, !1, !1, !1, !1, 0, null), c.forwardedTouchEvent = !0, a.dispatchEvent(c)
        }, a.prototype.determineEventType = function(a) {
            return c && a.tagName.toLowerCase() === "select" ? "mousedown" : "click"
        }, a.prototype.focus = function(a) {
            var b;
            d && a.setSelectionRange && a.type.indexOf("date") !== 0 && a.type !== "time" && a.type !== "month" ? (b = a.value.length, a.setSelectionRange(b, b)) : a.focus()
        }, a.prototype.updateScrollParent = function(a) {
            var b, c;
            b = a.fastClickScrollParent;
            if (!b || !b.contains(a)) {
                c = a;
                do {
                    if (c.scrollHeight > c.offsetHeight) {
                        b = c, a.fastClickScrollParent = c;
                        break
                    }
                    c = c.parentElement
                } while (c)
            }
            b && (b.fastClickLastScrollTop = b.scrollTop)
        }, a.prototype.getTargetElementFromEventTarget = function(a) {
            return a.nodeType === Node.TEXT_NODE ? a.parentNode : a
        }, a.prototype.onTouchStart = function(a) {
            var b, c, f;
            if (a.targetTouches.length > 1) return !0;
            b = this.getTargetElementFromEventTarget(a.target), c = a.targetTouches[0];
            if (d) {
                f = window.getSelection();
                if (f.rangeCount && !f.isCollapsed) return !0;
                if (!e) {
                    if (c.identifier && c.identifier === this.lastTouchIdentifier) return a.preventDefault(), !1;
                    this.lastTouchIdentifier = c.identifier, this.updateScrollParent(b)
                }
            }
            return this.trackingClick = !0, this.trackingClickStart = a.timeStamp, this.targetElement = b, this.touchStartX = c.pageX, this.touchStartY = c.pageY, a.timeStamp - this.lastClickTime < this.tapDelay && a.preventDefault(), !0
        }, a.prototype.touchHasMoved = function(a) {
            var b = a.changedTouches[0],
                c = this.touchBoundary;
            return Math.abs(b.pageX - this.touchStartX) > c || Math.abs(b.pageY - this.touchStartY) > c ? !0 : !1
        }, a.prototype.onTouchMove = function(a) {
            if (!this.trackingClick) return !0;
            if (this.targetElement !== this.getTargetElementFromEventTarget(a.target) || this.touchHasMoved(a)) this.trackingClick = !1, this.targetElement = null;
            return !0
        }, a.prototype.findControl = function(a) {
            return a.control !== undefined ? a.control : a.htmlFor ? document.getElementById(a.htmlFor) : a.querySelector("button, input:not([type=hidden]), keygen, meter, output, progress, select, textarea")
        }, a.prototype.onTouchEnd = function(a) {
            var b, g, h, i, j, k = this.targetElement;
            if (!this.trackingClick) return !0;
            if (a.timeStamp - this.lastClickTime < this.tapDelay) return this.cancelNextClick = !0, !0;
            if (a.timeStamp - this.trackingClickStart > this.tapTimeout) return !0;
            this.cancelNextClick = !1, this.lastClickTime = a.timeStamp, g = this.trackingClickStart, this.trackingClick = !1, this.trackingClickStart = 0, f && (j = a.changedTouches[0], k = document.elementFromPoint(j.pageX - window.pageXOffset, j.pageY - window.pageYOffset) || k, k.fastClickScrollParent = this.targetElement.fastClickScrollParent), h = k.tagName.toLowerCase();
            if (h === "label") {
                b = this.findControl(k);
                if (b) {
                    this.focus(k);
                    if (c) return !1;
                    k = b
                }
            } else if (this.needsFocus(k)) {
                if (a.timeStamp - g > 100 || d && window.top !== window && h === "input") return this.targetElement = null, !1;
                this.focus(k), this.sendClick(k, a);
                if (!d || h !== "select") this.targetElement = null, a.preventDefault();
                return !1
            }
            if (d && !e) {
                i = k.fastClickScrollParent;
                if (i && i.fastClickLastScrollTop !== i.scrollTop) return !0
            }
            return this.needsClick(k) || (a.preventDefault(), this.sendClick(k, a)), !1
        }, a.prototype.onTouchCancel = function() {
            this.trackingClick = !1, this.targetElement = null
        }, a.prototype.onMouse = function(a) {
            return this.targetElement ? a.forwardedTouchEvent ? !0 : a.cancelable ? !this.needsClick(this.targetElement) || this.cancelNextClick ? (a.stopImmediatePropagation ? a.stopImmediatePropagation() : a.propagationStopped = !0, a.stopPropagation(), a.preventDefault(), !1) : !0 : !0 : !0
        }, a.prototype.onClick = function(a) {
            var b;
            return this.trackingClick ? (this.targetElement = null, this.trackingClick = !1, !0) : a.target.type === "submit" && a.detail === 0 ? !0 : (b = this.onMouse(a), b || (this.targetElement = null), b)
        }, a.prototype.destroy = function() {
            var a = this.layer;
            c && (a.removeEventListener("mouseover", this.onMouse, !0), a.removeEventListener("mousedown", this.onMouse, !0), a.removeEventListener("mouseup", this.onMouse, !0)), a.removeEventListener("click", this.onClick, !0), a.removeEventListener("touchstart", this.onTouchStart, !1), a.removeEventListener("touchmove", this.onTouchMove, !1), a.removeEventListener("touchend", this.onTouchEnd, !1), a.removeEventListener("touchcancel", this.onTouchCancel, !1)
        }, a.notNeeded = function(a) {

            var b, d, e, f;
            if (typeof window.ontouchstart == "undefined") return !0;
            d = +(/Chrome\/([0-9]+)/.exec(navigator.userAgent) || [, 0])[1];
            if (d) {
                if (!c) return !0;
                b = document.querySelector("meta[name=viewport]");
                if (b) {
                    if (b.content.indexOf("user-scalable=no") !== -1) return !0;
                    if (d > 31 && document.documentElement.scrollWidth <= window.outerWidth) return !0
                }
            }
            if (g) {
                e = navigator.userAgent.match(/Version\/([0-9]*)\.([0-9]*)/);
                if (e[1] >= 10 && e[2] >= 3) {
                    b = document.querySelector("meta[name=viewport]");
                    if (b) {
                        if (b.content.indexOf("user-scalable=no") !== -1) return !0;
                        if (document.documentElement.scrollWidth <= window.outerWidth) return !0
                    }
                }
            }
            if (a.style.msTouchAction === "none" || a.style.touchAction === "manipulation") return !0;
            f = +(/Firefox\/([0-9]+)/.exec(navigator.userAgent) || [, 0])[1];
            if (f >= 27) {
                b = document.querySelector("meta[name=viewport]");
                if (b && (b.content.indexOf("user-scalable=no") !== -1 || document.documentElement.scrollWidth <= window.outerWidth)) return !0
            }
            return a.style.touchAction === "none" || a.style.touchAction === "manipulation" ? !0 : !1
        }, a.attach = function(b, c) {
            return new a(b, c)
        }, typeof define == "function" && typeof define.amd == "object" && define.amd ? define("vendor/fastclick", [], function() {
            return a
        }) : typeof module != "undefined" && module.exports ? (module.exports = a.attach, module.exports.FastClick = a) : window.FastClick = a
    }(),
    function() {
        var a = typeof self == "object" && self.self === self && self || typeof global == "object" && global.global === global && global || this,
            b = a._,
            c = Array.prototype,
            d = Object.prototype,
            e = c.push,
            f = c.slice,
            g = d.toString,
            h = d.hasOwnProperty,
            i = Array.isArray,
            j = Object.keys,
            k = Object.create,
            l = function() {},
            m = function(a) {
                if (a instanceof m) return a;
                if (!(this instanceof m)) return new m(a);
                this._wrapped = a
            };
        typeof exports != "undefined" ? (typeof module != "undefined" && module.exports && (exports = module.exports = m), exports._ = m) : a._ = m, m.VERSION = "1.8.3";
        var n = function(a, b, c) {
                if (b === void 0) return a;
                switch (c == null ? 3 : c) {
                    case 1:
                        return function(c) {
                            return a.call(b, c)
                        };
                    case 3:
                        return function(c, d, e) {
                            return a.call(b, c, d, e)
                        };
                    case 4:
                        return function(c, d, e, f) {
                            return a.call(b, c, d, e, f)
                        }
                }
                return function() {
                    return a.apply(b, arguments)
                }
            },
            o = function(a, b, c) {
                return a == null ? m.identity : m.isFunction(a) ? n(a, b, c) : m.isObject(a) ? m.matcher(a) : m.property(a)
            };
        m.iteratee = function(a, b) {
            return o(a, b, Infinity)
        };
        var p = function(a, b) {
                return b = b == null ? a.length - 1 : +b,
                    function() {
                        var c = Math.max(arguments.length - b, 0),
                            d = Array(c);
                        for (var e = 0; e < c; e++) d[e] = arguments[e + b];
                        switch (b) {
                            case 0:
                                return a.call(this, d);
                            case 1:
                                return a.call(this, arguments[0], d);
                            case 2:
                                return a.call(this, arguments[0], arguments[1], d)
                        }
                        var f = Array(b + 1);
                        for (e = 0; e < b; e++) f[e] = arguments[e];
                        return f[b] = d, a.apply(this, f)
                    }
            },
            q = function(a) {
                if (!m.isObject(a)) return {};
                if (k) return k(a);
                l.prototype = a;
                var b = new l;
                return l.prototype = null, b
            },
            r = function(a) {
                return function(b) {
                    return b == null ? void 0 : b[a]
                }
            },
            s = Math.pow(2, 53) - 1,
            t = r("length"),
            u = function(a) {
                var b = t(a);
                return typeof b == "number" && b >= 0 && b <= s
            };
        m.each = m.forEach = function(a, b, c) {
            b = n(b, c);
            var d, e;
            if (u(a))
                for (d = 0, e = a.length; d < e; d++) b(a[d], d, a);
            else {
                var f = m.keys(a);
                for (d = 0, e = f.length; d < e; d++) b(a[f[d]], f[d], a)
            }
            return a
        }, m.map = m.collect = function(a, b, c) {
            b = o(b, c);
            var d = !u(a) && m.keys(a),
                e = (d || a).length,
                f = Array(e);
            for (var g = 0; g < e; g++) {
                var h = d ? d[g] : g;
                f[g] = b(a[h], h, a)
            }
            return f
        };
        var v = function(a) {
            var b = function(b, c, d, e) {
                var f = !u(b) && m.keys(b),
                    g = (f || b).length,
                    h = a > 0 ? 0 : g - 1;
                e || (d = b[f ? f[h] : h], h += a);
                for (; h >= 0 && h < g; h += a) {
                    var i = f ? f[h] : h;
                    d = c(d, b[i], i, b)
                }
                return d
            };
            return function(a, c, d, e) {
                var f = arguments.length >= 3;
                return b(a, n(c, e, 4), d, f)
            }
        };
        m.reduce = m.foldl = m.inject = v(1), m.reduceRight = m.foldr = v(-1), m.find = m.detect = function(a, b, c) {
            var d;
            u(a) ? d = m.findIndex(a, b, c) : d = m.findKey(a, b, c);
            if (d !== void 0 && d !== -1) return a[d]
        }, m.filter = m.select = function(a, b, c) {
            var d = [];
            return b = o(b, c), m.each(a, function(a, c, e) {
                b(a, c, e) && d.push(a)
            }), d
        }, m.reject = function(a, b, c) {
            return m.filter(a, m.negate(o(b)), c)
        }, m.every = m.all = function(a, b, c) {
            b = o(b, c);
            var d = !u(a) && m.keys(a),
                e = (d || a).length;
            for (var f = 0; f < e; f++) {
                var g = d ? d[f] : f;
                if (!b(a[g], g, a)) return !1
            }
            return !0
        }, m.some = m.any = function(a, b, c) {
            b = o(b, c);
            var d = !u(a) && m.keys(a),
                e = (d || a).length;
            for (var f = 0; f < e; f++) {
                var g = d ? d[f] : f;
                if (b(a[g], g, a)) return !0
            }
            return !1
        }, m.contains = m.includes = m.include = function(a, b, c, d) {
            u(a) || (a = m.values(a));
            if (typeof c != "number" || d) c = 0;
            return m.indexOf(a, b, c) >= 0
        }, m.invoke = p(function(a, b, c) {
            var d = m.isFunction(b);
            return m.map(a, function(a) {
                var e = d ? b : a[b];
                return e == null ? e : e.apply(a, c)
            })
        }), m.pluck = function(a, b) {
            return m.map(a, m.property(b))
        }, m.where = function(a, b) {
            return m.filter(a, m.matcher(b))
        }, m.findWhere = function(a, b) {
            return m.find(a, m.matcher(b))
        }, m.max = function(a, b, c) {
            var d = -Infinity,
                e = -Infinity,
                f, g;
            if (b == null || typeof b == "number" && typeof a[0] != "object" && a != null) {
                a = u(a) ? a : m.values(a);
                for (var h = 0, i = a.length; h < i; h++) f = a[h], f > d && (d = f)
            } else b = o(b, c), m.each(a, function(a, c, f) {
                g = b(a, c, f);
                if (g > e || g === -Infinity && d === -Infinity) d = a, e = g
            });
            return d
        }, m.min = function(a, b, c) {
            var d = Infinity,
                e = Infinity,
                f, g;
            if (b == null || typeof b == "number" && typeof a[0] != "object" && a != null) {
                a = u(a) ? a : m.values(a);
                for (var h = 0, i = a.length; h < i; h++) f = a[h], f < d && (d = f)
            } else b = o(b, c), m.each(a, function(a, c, f) {
                g = b(a, c, f);
                if (g < e || g === Infinity && d === Infinity) d = a, e = g
            });
            return d
        }, m.shuffle = function(a) {
            return m.sample(a, Infinity)
        }, m.sample = function(a, b, c) {
            if (b == null || c) return u(a) || (a = m.values(a)), a[m.random(a.length - 1)];
            var d = u(a) ? m.clone(a) : m.values(a),
                e = t(d);
            b = Math.max(Math.min(b, e), 0);
            var f = e - 1;
            for (var g = 0; g < b; g++) {
                var h = m.random(g, f),
                    i = d[g];
                d[g] = d[h], d[h] = i
            }
            return d.slice(0, b)
        }, m.sortBy = function(a, b, c) {
            var d = 0;
            return b = o(b, c), m.pluck(m.map(a, function(a, c, e) {
                return {
                    value: a,
                    index: d++,
                    criteria: b(a, c, e)
                }
            }).sort(function(a, b) {
                var c = a.criteria,
                    d = b.criteria;
                if (c !== d) {
                    if (c > d || c === void 0) return 1;
                    if (c < d || d === void 0) return -1
                }
                return a.index - b.index
            }), "value")
        };
        var w = function(a, b) {
            return function(c, d, e) {
                var f = b ? [
                    [],
                    []
                ] : {};
                return d = o(d, e), m.each(c, function(b, e) {
                    var g = d(b, e, c);
                    a(f, b, g)
                }), f
            }
        };
        m.groupBy = w(function(a, b, c) {
            m.has(a, c) ? a[c].push(b) : a[c] = [b]
        }), m.indexBy = w(function(a, b, c) {
            a[c] = b
        }), m.countBy = w(function(a, b, c) {
            m.has(a, c) ? a[c]++ : a[c] = 1
        }), m.toArray = function(a) {
            return a ? m.isArray(a) ? f.call(a) : u(a) ? m.map(a, m.identity) : m.values(a) : []
        }, m.size = function(a) {
            return a == null ? 0 : u(a) ? a.length : m.keys(a).length
        }, m.partition = w(function(a, b, c) {
            a[c ? 0 : 1].push(b)
        }, !0), m.first = m.head = m.take = function(a, b, c) {
            return a == null ? void 0 : b == null || c ? a[0] : m.initial(a, a.length - b)
        }, m.initial = function(a, b, c) {
            return f.call(a, 0, Math.max(0, a.length - (b == null || c ? 1 : b)))
        }, m.last = function(a, b, c) {
            return a == null ? void 0 : b == null || c ? a[a.length - 1] : m.rest(a, Math.max(0, a.length - b))
        }, m.rest = m.tail = m.drop = function(a, b, c) {
            return f.call(a, b == null || c ? 1 : b)
        }, m.compact = function(a) {
            return m.filter(a, m.identity)
        };
        var x = function(a, b, c, d) {
            d = d || [];
            var e = d.length;
            for (var f = 0, g = t(a); f < g; f++) {
                var h = a[f];
                if (u(h) && (m.isArray(h) || m.isArguments(h)))
                    if (b) {
                        var i = 0,
                            j = h.length;
                        while (i < j) d[e++] = h[i++]
                    } else x(h, b, c, d), e = d.length;
                else c || (d[e++] = h)
            }
            return d
        };
        m.flatten = function(a, b) {
            return x(a, b, !1)
        }, m.without = p(function(a, b) {
            return m.difference(a, b)
        }), m.uniq = m.unique = function(a, b, c, d) {
            m.isBoolean(b) || (d = c, c = b, b = !1), c != null && (c = o(c, d));
            var e = [],
                f = [];
            for (var g = 0, h = t(a); g < h; g++) {
                var i = a[g],
                    j = c ? c(i, g, a) : i;
                b ? ((!g || f !== j) && e.push(i), f = j) : c ? m.contains(f, j) || (f.push(j), e.push(i)) : m.contains(e, i) || e.push(i)
            }
            return e
        }, m.union = p(function(a) {
            return m.uniq(x(a, !0, !0))
        }), m.intersection = function(a) {
            var b = [],
                c = arguments.length;
            for (var d = 0, e = t(a); d < e; d++) {
                var f = a[d];
                if (m.contains(b, f)) continue;
                var g;
                for (g = 1; g < c; g++)
                    if (!m.contains(arguments[g], f)) break;
                g === c && b.push(f)
            }
            return b
        }, m.difference = p(function(a, b) {
            return b = x(b, !0, !0), m.filter(a, function(a) {
                return !m.contains(b, a)
            })
        }), m.unzip = function(a) {
            var b = a && m.max(a, t).length || 0,
                c = Array(b);
            for (var d = 0; d < b; d++) c[d] = m.pluck(a, d);
            return c
        }, m.zip = p(m.unzip), m.object = function(a, b) {
            var c = {};
            for (var d = 0, e = t(a); d < e; d++) b ? c[a[d]] = b[d] : c[a[d][0]] = a[d][1];
            return c
        };
        var y = function(a) {
            return function(b, c, d) {
                c = o(c, d);
                var e = t(b),
                    f = a > 0 ? 0 : e - 1;
                for (; f >= 0 && f < e; f += a)
                    if (c(b[f], f, b)) return f;
                return -1
            }
        };
        m.findIndex = y(1), m.findLastIndex = y(-1), m.sortedIndex = function(a, b, c, d) {
            c = o(c, d, 1);
            var e = c(b),
                f = 0,
                g = t(a);
            while (f < g) {
                var h = Math.floor((f + g) / 2);
                c(a[h]) < e ? f = h + 1 : g = h
            }
            return f
        };
        var z = function(a, b, c) {
            return function(d, e, g) {
                var h = 0,
                    i = t(d);
                if (typeof g == "number") a > 0 ? h = g >= 0 ? g : Math.max(g + i, h) : i = g >= 0 ? Math.min(g + 1, i) : g + i + 1;
                else if (c && g && i) return g = c(d, e), d[g] === e ? g : -1;
                if (e !== e) return g = b(f.call(d, h, i), m.isNaN), g >= 0 ? g + h : -1;
                for (g = a > 0 ? h : i - 1; g >= 0 && g < i; g += a)
                    if (d[g] === e) return g;
                return -1
            }
        };
        m.indexOf = z(1, m.findIndex, m.sortedIndex), m.lastIndexOf = z(-1, m.findLastIndex), m.range = function(a, b, c) {
            b == null && (b = a || 0, a = 0), c = c || 1;
            var d = Math.max(Math.ceil((b - a) / c), 0),
                e = Array(d);
            for (var f = 0; f < d; f++, a += c) e[f] = a;
            return e
        }, m.chunk = function(a, b) {
            if (b == null || b < 1) return [];
            var c = [],
                d = 0,
                e = a.length;
            while (d < e) c.push(f.call(a, d, d += b));
            return c
        };
        var A = function(a, b, c, d, e) {
            if (d instanceof b) {
                var f = q(a.prototype),
                    g = a.apply(f, e);
                return m.isObject(g) ? g : f
            }
            return a.apply(c, e)
        };
        m.bind = p(function(a, b, c) {
            if (!m.isFunction(a)) throw new TypeError("Bind must be called on a function");
            var d = p(function(e) {
                return A(a, d, b, this, c.concat(e))
            });
            return d
        }), m.partial = p(function(a, b) {
            var c = m.partial.placeholder,
                d = function() {
                    var e = 0,
                        f = b.length,
                        g = Array(f);
                    for (var h = 0; h < f; h++) g[h] = b[h] === c ? arguments[e++] : b[h];
                    while (e < arguments.length) g.push(arguments[e++]);
                    return A(a, d, this, this, g)
                };
            return d
        }), m.partial.placeholder = m, m.bindAll = p(function(a, b) {
            b = x(b, !1, !1);
            var c = b.length;
            if (c < 1) throw new Error("bindAll must be passed function names");
            while (c--) {
                var d = b[c];
                a[d] = m.bind(a[d], a)
            }
        }), m.memoize = function(a, b) {
            var c = function(d) {
                var e = c.cache,
                    f = "" + (b ? b.apply(this, arguments) : d);
                return m.has(e, f) || (e[f] = a.apply(this, arguments)), e[f]
            };
            return c.cache = {}, c
        }, m.delay = p(function(a, b, c) {
            return setTimeout(function() {
                return a.apply(null, c)
            }, b)
        }), m.defer = m.partial(m.delay, m, 1), m.throttle = function(a, b, c) {
            var d, e, f, g = null,
                h = 0;
            c || (c = {});
            var i = function() {
                h = c.leading === !1 ? 0 : m.now(), g = null, f = a.apply(d, e), g || (d = e = null)
            };
            return function() {
                var j = m.now();
                !h && c.leading === !1 && (h = j);
                var k = b - (j - h);
                return d = this, e = arguments, k <= 0 || k > b ? (g && (clearTimeout(g), g = null), h = j, f = a.apply(d, e), g || (d = e = null)) : !g && c.trailing !== !1 && (g = setTimeout(i, k)), f
            }
        }, m.debounce = function(a, b, c) {
            var d, e, f, g, h, i = function() {
                var j = m.now() - g;
                j < b && j >= 0 ? d = setTimeout(i, b - j) : (d = null, c || (h = a.apply(f, e), d || (f = e = null)))
            };
            return function() {
                f = this, e = arguments, g = m.now();
                var j = c && !d;
                return d || (d = setTimeout(i, b)), j && (h = a.apply(f, e), f = e = null), h
            }
        }, m.wrap = function(a, b) {
            return m.partial(b, a)
        }, m.negate = function(a) {
            return function() {
                return !a.apply(this, arguments)
            }
        }, m.compose = function() {
            var a = arguments,
                b = a.length - 1;
            return function() {
                var c = b,
                    d = a[b].apply(this, arguments);
                while (c--) d = a[c].call(this, d);
                return d
            }
        }, m.after = function(a, b) {
            return function() {
                if (--a < 1) return b.apply(this, arguments)
            }
        }, m.before = function(a, b) {
            var c;
            return function() {
                return --a > 0 && (c = b.apply(this, arguments)), a <= 1 && (b = null), c
            }
        }, m.once = m.partial(m.before, 2), m.restArgs = p;
        var B = !{
                toString: null
            }.propertyIsEnumerable("toString"),
            C = ["valueOf", "isPrototypeOf", "toString", "propertyIsEnumerable", "hasOwnProperty", "toLocaleString"],
            D = function(a, b) {
                var c = C.length,
                    e = a.constructor,
                    f = m.isFunction(e) && e.prototype || d,
                    g = "constructor";
                m.has(a, g) && !m.contains(b, g) && b.push(g);
                while (c--) g = C[c], g in a && a[g] !== f[g] && !m.contains(b, g) && b.push(g)
            };
        m.keys = function(a) {
            if (!m.isObject(a)) return [];
            if (j) return j(a);
            var b = [];
            for (var c in a) m.has(a, c) && b.push(c);
            return B && D(a, b), b
        }, m.allKeys = function(a) {
            if (!m.isObject(a)) return [];
            var b = [];
            for (var c in a) b.push(c);
            return B && D(a, b), b
        }, m.values = function(a) {
            var b = m.keys(a),
                c = b.length,
                d = Array(c);
            for (var e = 0; e < c; e++) d[e] = a[b[e]];
            return d
        }, m.mapObject = function(a, b, c) {
            b = o(b, c);
            var d = m.keys(a),
                e = d.length,
                f = {};
            for (var g = 0; g < e; g++) {
                var h = d[g];
                f[h] = b(a[h], h, a)
            }
            return f
        }, m.pairs = function(a) {
            var b = m.keys(a),
                c = b.length,
                d = Array(c);
            for (var e = 0; e < c; e++) d[e] = [b[e], a[b[e]]];
            return d
        }, m.invert = function(a) {
            var b = {},
                c = m.keys(a);
            for (var d = 0, e = c.length; d < e; d++) b[a[c[d]]] = c[d];
            return b
        }, m.functions = m.methods = function(a) {
            var b = [];
            for (var c in a) m.isFunction(a[c]) && b.push(c);
            return b.sort()
        };
        var E = function(a, b) {
            return function(c) {
                var d = arguments.length;
                b && (c = Object(c));
                if (d < 2 || c == null) return c;
                for (var e = 1; e < d; e++) {
                    var f = arguments[e],
                        g = a(f),
                        h = g.length;
                    for (var i = 0; i < h; i++) {
                        var j = g[i];
                        if (!b || c[j] === void 0) c[j] = f[j]
                    }
                }
                return c
            }
        };
        m.extend = E(m.allKeys), m.extendOwn = m.assign = E(m.keys), m.findKey = function(a, b, c) {
            b = o(b, c);
            var d = m.keys(a),
                e;
            for (var f = 0, g = d.length; f < g; f++) {
                e = d[f];
                if (b(a[e], e, a)) return e
            }
        };
        var F = function(a, b, c) {
            return b in c
        };
        m.pick = p(function(a, b) {
            var c = {},
                d = b[0];
            if (a == null) return c;
            m.isFunction(d) ? (b.length > 1 && (d = n(d, b[1])), b = m.allKeys(a)) : (d = F, b = x(b, !1, !1), a = Object(a));
            for (var e = 0, f = b.length; e < f; e++) {
                var g = b[e],
                    h = a[g];
                d(h, g, a) && (c[g] = h)
            }
            return c
        }), m.omit = p(function(a, b) {
            var c = b[0],
                d;
            return m.isFunction(c) ? (c = m.negate(c), b.length > 1 && (d = b[1])) : (b = m.map(x(b, !1, !1), String), c = function(a, c) {
                return !m.contains(b, c)
            }), m.pick(a, c, d)
        }), m.defaults = E(m.allKeys, !0), m.create = function(a, b) {
            var c = q(a);
            return b && m.extendOwn(c, b), c
        }, m.clone = function(a) {
            return m.isObject(a) ? m.isArray(a) ? a.slice() : m.extend({}, a) : a
        }, m.tap = function(a, b) {
            return b(a), a
        }, m.isMatch = function(a, b) {
            var c = m.keys(b),
                d = c.length;
            if (a == null) return !d;
            var e = Object(a);
            for (var f = 0; f < d; f++) {
                var g = c[f];
                if (b[g] !== e[g] || !(g in e)) return !1
            }
            return !0
        };
        var G, H;
        G = function(a, b, c, d) {
            if (a === b) return a !== 0 || 1 / a === 1 / b;
            if (a == null || b == null) return a === b;
            if (a !== a) return b !== b;
            var e = typeof a;
            return e !== "function" && e !== "object" && typeof b != "object" ? !1 : H(a, b, c, d)
        }, H = function(a, b, c, d) {
            a instanceof m && (a = a._wrapped), b instanceof m && (b = b._wrapped);
            var e = g.call(a);
            if (e !== g.call(b)) return !1;
            switch (e) {
                case "[object RegExp]":
                case "[object String]":
                    return "" + a == "" + b;
                case "[object Number]":
                    if (+a !== +a) return +b !== +b;
                    return +a === 0 ? 1 / +a === 1 / b : +a === +b;
                case "[object Date]":
                case "[object Boolean]":
                    return +a === +b
            }
            var f = e === "[object Array]";
            if (!f) {
                if (typeof a != "object" || typeof b != "object") return !1;
                var h = a.constructor,
                    i = b.constructor;
                if (h !== i && !(m.isFunction(h) && h instanceof h && m.isFunction(i) && i instanceof i) && "constructor" in a && "constructor" in b) return !1
            }
            c = c || [], d = d || [];
            var j = c.length;
            while (j--)
                if (c[j] === a) return d[j] === b;
            c.push(a), d.push(b);
            if (f) {
                j = a.length;
                if (j !== b.length) return !1;
                while (j--)
                    if (!G(a[j], b[j], c, d)) return !1
            } else {
                var k = m.keys(a),
                    l;
                j = k.length;
                if (m.keys(b).length !== j) return !1;
                while (j--) {
                    l = k[j];
                    if (!m.has(b, l) || !G(a[l], b[l], c, d)) return !1
                }
            }
            return c.pop(), d.pop(), !0
        }, m.isEqual = function(a, b) {
            return G(a, b)
        }, m.isEmpty = function(a) {
            return a == null ? !0 : u(a) && (m.isArray(a) || m.isString(a) || m.isArguments(a)) ? a.length === 0 : m.keys(a).length === 0
        }, m.isElement = function(a) {
            return !!a && a.nodeType === 1
        }, m.isArray = i || function(a) {
            return g.call(a) === "[object Array]"
        }, m.isObject = function(a) {
            var b = typeof a;
            return b === "function" || b === "object" && !!a
        }, m.each(["Arguments", "Function", "String", "Number", "Date", "RegExp", "Error"], function(a) {
            m["is" + a] = function(b) {
                return g.call(b) === "[object " + a + "]"
            }
        }), m.isArguments(arguments) || (m.isArguments = function(a) {
            return m.has(a, "callee")
        });
        var I = a.document && a.document.childNodes;
        typeof /./ != "function" && typeof Int8Array != "object" && typeof I != "function" && (m.isFunction = function(a) {
            return typeof a == "function" || !1
        }), m.isFinite = function(a) {
            return isFinite(a) && !isNaN(parseFloat(a))
        }, m.isNaN = function(a) {
            return m.isNumber(a) && isNaN(a)
        }, m.isBoolean = function(a) {
            return a === !0 || a === !1 || g.call(a) === "[object Boolean]"
        }, m.isNull = function(a) {
            return a === null
        }, m.isUndefined = function(a) {
            return a === void 0
        }, m.has = function(a, b) {
            return a != null && h.call(a, b)
        }, m.noConflict = function() {
            return a._ = b, this
        }, m.identity = function(a) {
            return a
        }, m.constant = function(a) {
            return function() {
                return a
            }
        }, m.noop = function() {}, m.property = r, m.propertyOf = function(a) {
            return a == null ? function() {} : function(b) {
                return a[b]
            }
        }, m.matcher = m.matches = function(a) {
            return a = m.extendOwn({}, a),
                function(b) {
                    return m.isMatch(b, a)
                }
        }, m.times = function(a, b, c) {
            var d = Array(Math.max(0, a));
            b = n(b, c, 1);
            for (var e = 0; e < a; e++) d[e] = b(e);
            return d
        }, m.random = function(a, b) {
            return b == null && (b = a, a = 0), a + Math.floor(Math.random() * (b - a + 1))
        }, m.now = Date.now || function() {
            return (new Date).getTime()
        };
        var J = {
                "&": "&amp;",
                "<": "&lt;",
                ">": "&gt;",
                '"': "&quot;",
                "'": "&#x27;",
                "`": "&#x60;"
            },
            K = m.invert(J),
            L = function(a) {
                var b = function(b) {
                        return a[b]
                    },
                    c = "(?:" + m.keys(a).join("|") + ")",
                    d = RegExp(c),
                    e = RegExp(c, "g");
                return function(a) {
                    return a = a == null ? "" : "" + a, d.test(a) ? a.replace(e, b) : a
                }
            };
        m.escape = L(J), m.unescape = L(K), m.result = function(a, b, c) {
            var d = a == null ? void 0 : a[b];
            return d === void 0 && (d = c), m.isFunction(d) ? d.call(a) : d
        };
        var M = 0;
        m.uniqueId = function(a) {
            var b = ++M + "";
            return a ? a + b : b
        }, m.templateSettings = {
            evaluate: /<%([\s\S]+?)%>/g,
            interpolate: /<%=([\s\S]+?)%>/g,
            escape: /<%-([\s\S]+?)%>/g
        };
        var N = /(.)^/,
            O = {
                "'": "'",
                "\\": "\\",
                "\r": "r",
                "\n": "n",
                "\u2028": "u2028",
                "\u2029": "u2029"
            },
            P = /\\|'|\r|\n|\u2028|\u2029/g,
            Q = function(a) {
                return "\\" + O[a]
            };
        m.template = function(a, b, c) {
            !b && c && (b = c), b = m.defaults({}, b, m.templateSettings);
            var d = RegExp([(b.escape || N).source, (b.interpolate || N).source, (b.evaluate || N).source].join("|") + "|$", "g"),
                e = 0,
                f = "__p+='";
            a.replace(d, function(b, c, d, g, h) {
                return f += a.slice(e, h).replace(P, Q), e = h + b.length, c ? f += "'+\n((__t=(" + c + "))==null?'':_.escape(__t))+\n'" : d ? f += "'+\n((__t=(" + d + "))==null?'':__t)+\n'" : g && (f += "';\n" + g + "\n__p+='"), b
            }), f += "';\n", b.variable || (f = "with(obj||{}){\n" + f + "}\n"), f = "var __t,__p='',__j=Array.prototype.join,print=function(){__p+=__j.call(arguments,'');};\n" + f + "return __p;\n";
            var g;
            try {
                g = new Function(b.variable || "obj", "_", f)
            } catch (h) {
                throw h.source = f, h
            }
            var i = function(a) {
                    return g.call(this, a, m)
                },
                j = b.variable || "obj";
            return i.source = "function(" + j + "){\n" + f + "}", i
        }, m.chain = function(a) {
            var b = m(a);
            return b._chain = !0, b
        };
        var R = function(a, b) {
            return a._chain ? m(b).chain() : b
        };
        m.mixin = function(a) {
            m.each(m.functions(a), function(b) {
                var c = m[b] = a[b];
                m.prototype[b] = function() {
                    var a = [this._wrapped];
                    return e.apply(a, arguments), R(this, c.apply(m, a))
                }
            })
        }, m.mixin(m), m.each(["pop", "push", "reverse", "shift", "sort", "splice", "unshift"], function(a) {
            var b = c[a];
            m.prototype[a] = function() {
                var c = this._wrapped;
                return b.apply(c, arguments), (a === "shift" || a === "splice") && c.length === 0 && delete c[0], R(this, c)
            }
        }), m.each(["concat", "join", "slice"], function(a) {
            var b = c[a];
            m.prototype[a] = function() {
                return R(this, b.apply(this._wrapped, arguments))
            }
        }), m.prototype.value = function() {
            return this._wrapped
        }, m.prototype.valueOf = m.prototype.toJSON = m.prototype.value, m.prototype.toString = function() {
            return "" + this._wrapped
        }, typeof define == "function" && define.amd && define("underscore", [], function() {
            return m
        })
    }(), define("amd/oldie", ["jquery"], function(a) {
        var b = {
            HeroVersion0: ".hero.hero-version-0",
            HeroVersion0PlayBtn: ".hero--play-btn",
            HeroVersion0BgImg: ".hero__primary-background-image",
            SignInRemeberMeCheckbox: ".jpui.checkbox.user-remember",
            SignInRememberMeLabel: ".signin--remember-me",
            CloneAndAppendNode: function(a, b) {
                var c = b.clone();
                b.remove(), a.append(c)
            }
        };
        return {
            init: function() {
                var c = a(document);
                b.CloneAndAppendNode(a(b.HeroVersion0), a(b.HeroVersion0 + " " + b.HeroVersion0BgImg)), b.CloneAndAppendNode(a(b.HeroVersion0), a(b.HeroVersion0 + " " + b.HeroVersion0PlayBtn)), c.on("click", function(c) {
                    var d = a(c.target);
                    if (d.is(b.SignInRememberMeLabel) || d.is(b.SignInRemeberMeCheckbox)) {
                        var e = a(b.SignInRemeberMeCheckbox);
                        e.hasClass("checked") ? a(b.SignInRemeberMeCheckbox).removeClass("checked").prop("checked", !1) : a(b.SignInRemeberMeCheckbox).addClass("checked").prop("checked")
                    }
                })
            }
        }
    }), define("amd/speedbump", ["jquery", "content/conf/appsconfig/clientconfig"], function(a, b) {
        var c = {
            Default: "[data-speedbump-type=default]",
            Spanish: "[data-speedbump-type=spanish]",
            CancelElement: ".speedbump__inner--links__cancel",
            ProceedElement: ".speedbump__inner--links__proceed",
            WrapperElement: ".speedbump__wrapper",
            DefaultHAT: "<span class='accessible-text'>(Opens Overlay)</span>",
            SpanishHAT: "<span class='accessible-text'>(abre superposiciÃ³n)</span>",
            ExternalLinks: "a[href^='http']:not(.spanish-speedbump-link)",
            SpanishLinks: ".spanish-speedbump-link",
            ActiveLink: "",
            WhiteList: [],
            GetQueryParams: function() {
                var a = document.location.search.replace("?", ""),
                    b = {};
                if (a) {
                    var c = a.split("&");
                    for (var d = 0; d < c.length; d++) {
                        var e = c[d].split("=");
                        b[e[0]] = e[1]
                    }
                }
                return b
            },
            InsertHiddenAccessibleTextIntoLink: function(a, b) {
                var c = a.attr("href"),
                    d = !1;
                if (c) {
                    for (var e = 0; e < this.WhiteList.length; e++)
                        if (c.indexOf(this.WhiteList[e]) >= 0) {
                            d = !0;
                            break
                        }
                    d || a.append(b), d = !1
                }
            },
            InsertHiddenAccessibleTextIntoLinks: function(b) {
                var c = this,
                    d = b ? b : a("body");
                d.find(c.ExternalLinks).each(function() {
                    c.InsertHiddenAccessibleTextIntoLink(a(this), c.DefaultHAT)
                }), d.find(c.SpanishLinks).each(function() {
                    c.InsertHiddenAccessibleTextIntoLink(a(this), c.SpanishHAT)
                })
            },
            IsLinkInWhiteList: function(a) {
                var b = a.attr("href");
                if (b)
                    for (var c = 0; c < this.WhiteList.length; c++)
                        if (b.toLowerCase().indexOf(this.WhiteList[c]) >= 0) return !0;
                return !1
            },
            IsDefaultModalOpen: function() {
                return a(this.Default).parents(this.WrapperElement).hasClass("visible")
            },
            IsSpanishModalOpen: function() {
                return a(this.Spanish).parents(this.WrapperElement).hasClass("visible")
            },
            OpenDefaultModal: function(b) {
                a(this.Spanish).parents(this.WrapperElement).removeClass("visible"), a(this.Default).parents(this.WrapperElement).addClass("visible"), a(this.Default).find(this.ProceedElement).focus(), b && b.preventDefault()
            },
            OpenSpanishModal: function(b) {
                a(this.Default).parents(this.WrapperElement).removeClass("visible"), a(this.Spanish).parents(this.WrapperElement).addClass("visible"), a(this.Spanish).find(this.ProceedElement).focus(), b && b.preventDefault()
            },
            SetSpeedBumpWhiteList: function() {
                if (b)
                    if (b.whiteListedDomains) {
                        var a = b.whiteListedDomains.toLowerCase().split(",");
                        for (var d = 0; d < a.length; d++) a[d].indexOf(".") === 0 && (a[d] = a[d].slice(1, a[d].length));
                        c.WhiteList = a
                    } else console.error("SpeedBump Error: Client config white list is " + b.whiteListedDomains);
                else console.error("SpeedBump Error: Missing client config.")
            },
            SetupModalEvents: function(b, c) {
                var d = this;
                b.find(d.CancelElement).on("click", function(b) {
                    a(this).parents(d.WrapperElement).removeClass("visible"), d.ActiveLink.focus(), b.preventDefault()
                }), b.find(d.ProceedElement).on("click", function(b) {
                    var e = d.ActiveLink.attr("href");
                    e && (window.open(e, c), a(this).parents(d.WrapperElement).removeClass("visible"), d.ActiveLink.focus()), b.preventDefault()
                })
            }
        };
        return {
            init: function() {
                var b = a(document),
                    d = a("body"),
                    e = a(".main-content--dropzone"),
                    f = a(c.Default),
                    g = a(c.Spanish);
                c.SetSpeedBumpWhiteList(), c.InsertHiddenAccessibleTextIntoLinks(), c.SetupModalEvents(g, "_self"), c.SetupModalEvents(f, "_blank"), d.on("click", function(b) {
                    var d = a(b.target).is("a") ? a(b.target) : a(b.target).parents("a");
                    d.is(c.SpanishLinks) ? (c.ActiveLink = d, c.OpenSpanishModal(b)) : d.is(c.ExternalLinks) && (c.IsLinkInWhiteList(d) || (c.ActiveLink = d, c.OpenDefaultModal(b)))
                }), a(document).on("keydown", function(a) {
                    if (c.IsDefaultModalOpen() || c.IsSpanishModalOpen()) {
                        var b = c.IsDefaultModalOpen() ? f : g,
                            d = b.find(c.CancelElement),
                            e = b.find(c.ProceedElement);
                        if (a.keyCode === 9) e.is(":focus") ? (d.focus(), a.preventDefault()) : d.is(":focus") && (e.focus(), a.preventDefault());
                        else if (a.keyCode === 27) b.parents(c.WrapperElement).removeClass("visible"), c.ActiveLink.focus();
                        else if (a.keyCode === 32)
                            if (e.is(":focus")) {
                                var h = c.ActiveLink.attr("href");
                                h && (window.open(h, b.is(c.Default) ? "_blank" : "_self"), b.parents(c.WrapperElement).removeClass("visible"), c.ActiveLink.focus()), a.preventDefault()
                            } else d.is(":focus") && (b.parents(c.WrapperElement).removeClass("visible"), c.ActiveLink.focus(), a.preventDefault())
                    }
                }), e.on("Chase:FeatureAppended", function(b, d) {
                    var e = a(d);
                    e && c.InsertHiddenAccessibleTextIntoLinks(e)
                })
            },
            execute: function(b, d) {
                var e = a(c.Default),
                    f = a(c.Spanish);
                d.is(c.SpanishLinks) ? (c.ActiveLink = d, c.OpenSpanishModal(b)) : d.is(c.ExternalLinks) && (c.IsLinkInWhiteList(d) || (c.ActiveLink = d, c.OpenDefaultModal(b)))
            },
            initInterstitial: function() {
                var b = a(c.Spanish),
                    d = b.find(c.CancelElement),
                    e = b.find(c.ProceedElement);
                c.OpenSpanishModal(), d.on("click", function(a) {
                    window.history.back(), a.preventDefault()
                }), e.on("click", function(a) {
                    var b = c.GetQueryParams();
                    b.url ? window.location.href = decodeURIComponent(b.url) : window.console && console.error("SpeedBump Interstitial Error: Incorrect URL [" + b.url + "]"), a.preventDefault()
                }), a(document).on("keydown", function(a) {
                    a.keyCode === 9 ? e.is(":focus") ? (d.focus(), a.preventDefault()) : d.is(":focus") && (e.focus(), a.preventDefault()) : a.keyCode === 32 && (e.is(":focus") ? (e.click(), a.preventDefault()) : d.is(":focus") && d.click())
                })
            }
        }
    }), define("amd/ada", ["jquery"], function(a) {
        var b = {
            DataAccessibleText: "a[data-accessible-text]",
            ReplaceDataAccessibleText: function(b) {
                a(b).find(this.DataAccessibleText).each(function() {
                    var b = a(this).data("accessible-text"),
                        c = "<span class='accessible-text'>" + b + "</span>";
                    a(this).append(c)
                })
            }
        };
        return {
            init: function() {
                b.ReplaceDataAccessibleText(a("body"));
                var c = a(".main-content--dropzone");
                c.on("Chase:FeatureAppended", function(c, d) {
                    b.ReplaceDataAccessibleText(a(d))
                })
            }
        }
    }), define("amd/xfs", ["content/conf/appsconfig/clientconfig"], function(a) {
        var b = {
            init: function() {
                var c = b.getHostnameFromURL(document.referrer),
                    d = a.XFSWhiteListedDomains ? a.XFSWhiteListedDomains : "",
                    e = !0,
                    f = d.split(",");
                for (var g = 0; g < f.length; g++)
                    if (c && c.indexOf(f[g]) !== -1) {
                        e = !1;
                        break
                    }
                e && (top.location = self.location)
            },
            getHostnameFromURL: function(a) {
                var b = a.split("/")[2];
                return b
            }
        };
        return b
    }), define("amd/utils", ["jquery"], function(a) {
        return {
            linkHandler: function(b, c) {
                var d = a(b).closest("a").attr("href"),
                    e, f = a("<a>", {
                        href: d
                    })[0];
                switch (c) {
                    case "protocol":
                        e = f.protocol;
                        break;
                    case "host":
                        e = f.hostname;
                        break;
                    case "port":
                        e = f.port;
                        break;
                    case "origin":
                        e = f.origin;
                        break;
                    case "path":
                        e = f.pathname;
                        break;
                    case "query":
                        e = f.search;
                        break;
                    case "hash":
                        e = f.hash;
                        break;
                    default:
                        e = f
                }
                return e
            },
            isElementInViewport: function(b) {
                var c = a.param(b),
                    d;
                typeof jQuery == "function" && b instanceof jQuery && (d = b[0]);
                var e = d.getBoundingClientRect(),
                    f = a.param(e);
                return e.top >= 0 && e.left >= 0 && e.bottom <= (window.innerHeight || document.documentElement.clientHeight) && e.right <= (window.innerWidth || document.documentElement.clientWidth)
            },
            isString: function(b) {
                return a.type(b) === "string"
            }
        }
    }), define("amd/gif", ["jquery", "amd/utils"], function(a, b) {
        var c = {
            Element: ".play-gif",
            Debounce: function(a, b, c) {
                var d;
                return function() {
                    function h() {
                        c || a.apply(f, g), d = null
                    }
                    var f = this,
                        g = arguments;
                    d ? clearTimeout(d) : c && a.apply(f, g), d = setTimeout(h, b || 100)
                }
            },
            PlayGif: function(a) {
                var b = "?a=",
                    c = Math.floor(Math.random() * 100) + 1,
                    d = a.attr("src");
                d.indexOf(b) > -1 ? a.attr("src", d.slice(0, d.indexOf(b)) + b + c) : a.attr("src", d + b + c)
            }
        };
        return {
            init: function() {
                var d = a(window),
                    e = a(c.Element);
                if (e.length > 0) {
                    var f = [],
                        g = d.height();
                    d.on("scroll", c.Debounce(function() {
                        var g = d.scrollTop();
                        e.each(function(d) {
                            if (b.isElementInViewport(a(this))) {
                                if (f[d] === undefined || f[d] === !1) c.PlayGif(a(this)), f[d] = !0
                            } else f[d] = !1
                        })
                    }, 200))
                }
            }
        }
    }), define("amd/sub-header", ["jquery", "amd/utils", "iscroll"], function(a, b) {
        var c = {
            element: ".sub-header",
            nav: ".sub-header__nav",
            navGradientLeft: ".sub-header__nav--gradient--left",
            navGradientRight: ".sub-header__nav--gradient--right",
            navWrapper: ".sub-header__nav-wrapper",
            navItem: ".sub-header__nav--item",
            topicWrapperContent: ".topic__wrapper__content",
            topicSection: ".topic--section",
            anchorFunctionality: !0,
            firstNavItem: "",
            scrollerOptions: {
                mouseWheel: !1,
                scrollX: !0,
                scrollY: !0,
                click: !0,
                tap: !0
            },
		
            sectionOffsets: [],
            getCurrentSectionId: function(b) {
		//alert(g.length);	
                var d = c.firstNavItem;
                if (b && c.sectionOffsets.length > 0) a.each(c.sectionOffsets, function(a, e) {
                    if (b >= e.top && b <= e.bottom) return d = e.id, !1;
                    if (a === c.sectionOffsets.length - 1 && b > e.bottom) return d = e.id, !1
                });
                else {
                    var e = document.getElementById("main"),
                        f = e.dataset.subheaderActive;
                    a(c.navItem).find(".category-" + f).parent().addClass("active"), d = a(".active").children().attr("href")
                }
                return d || (d = c.firstNavItem), d
            },
            getHeight: function(a) {
                if (a.length > 0) return c.getBoundingClientRectHeightSupport || (typeof document.documentElement.getBoundingClientRect().height != "undefined" ? c.getBoundingClientRectHeightSupport = !0 : c.getBoundingClientRectHeightSupport = !1), c.getBoundingClientRectHeightSupport ? a[0].getBoundingClientRect().height : a.outerHeight(!0)
            },
            getWidth: function(a) {
                if (a.length > 0) return c.getBoundingClientRectWidthSupport || (typeof document.documentElement.getBoundingClientRect().width != "undefined" ? c.getBoundingClientRectWidthSupport = !0 : c.getBoundingClientRectWidthSupport = !1), c.getBoundingClientRectWidthSupport ? a[0].getBoundingClientRect().width : a.outerWidth(!0)
            },
            getPosition: function() {
			
                var b = a(".header.header-version-b"),
                    c = a(window).scrollTop() + b.height();
			  
                return c
            },
            getSubNavID: function(b) {
                var d = a(".header.header-version-b"),
                    e = "#SubHeaderDuplicate",
                    f = "#SubHeaderDuplicate",
                    g;
                return b || c.getPosition(), b > d.height() ? g = f : g = e, g
            },
            presisted: function(b) {
                var d = a(".header.header-version-b"),
                    e = "#SubHeaderDuplicate",
                    f = "#SubHeaderDuplicate";
                b || c.getPosition();
                var g = c.getCurrentSectionId(b),
                    h = c.getSubNavID(b),
                    i = new IScroll(h, c.scrollerOptions);
                a(h).addClass("fade-background"), setTimeout(function() {
                    i.refresh()
                }, 4), c.scrollToNavItem(i, g), c.anchorFunctionality && a(document).find(f) && c.smoothScrollTo(g), c.setSideGradients([e, f])
            },
            init: function(b) {
			
                var d = a(window),
                    e = a(".header.header-version-b"),
                    f = e.find(c.navWrapper),
                    g = a(c.element),
                    h = g.find(c.nav),
                    i = g.find(c.navWrapper),
                    j = d.scrollTop(),
                    k = j + e.height(); 
			   
                if (g.length > 0 && !b) {
			  
                    var l = h.find(c.navItem).first().find("a"),
                        m = !1,
                        n, o = h.offset().top,
                        p;
                    c.firstNavItem = l.attr("href"), c.setAnchorFunctionality(), c.setNavWidth(), e.append(i.clone().hide()), f = e.find(c.navWrapper);
                    var q = "SubHeaderDuplicate",
                        r = "SubHeaderDuplicate";
                    i.attr("id", q), f.attr("id", r), p = new IScroll("#" + q, c.scrollerOptions), f.length > 0 && (n = new IScroll("#" + r, c.scrollerOptions)), c.setSideGradients([i, f]), c.presisted(k), a(c.navItem).on("click", "a", function(b) {
                        var d = a(this).attr("href");
                        c.anchorFunctionality && c.setActiveNavItem(d), c.disableNavActiveState = !0, c.anchorFunctionality && (c.smoothScrollTo(d), b.preventDefault()), c.setSideGradients([i, f])
                    });
                    var s = c.isMobileSubHeaderView(),
                        t = !0;
                    d.on("scroll", function(b) {
                        var g = d.scrollTop();
                        m || (c.setSectionOffsets(), m = !0);
                        var h = g + e.height() + 1;
                        e.find(c.navWrapper).is(":visible") && (h += e.find(c.navWrapper).height()), a("body").hasClass("detail") && c.presisted(), c.setSideGradients([i, f]);
                        if (h >= o)
                            if (g > 0) {
                                f.show(), t && (s || setTimeout(function() {
                                    f.addClass("fade-background")
                                }, 0)), i.hide(), t && setTimeout(function() {
                                    f.length > 0 && (n.refresh(), t = !1)
                                }, 0);
                                if (c.anchorFunctionality) {
                                    var j = c.getCurrentSectionId(h);
                                    c.disableNavActiveState || (c.setActiveNavItem(j), f.length > 0 && c.scrollToNavItem(n, j))
                                } else c.presisted()
                            } else f.hide(), i.show(), c.presisted();
                        else f.is(":visible") && (f.hide(), s || f.removeClass("fade-background"), i.show(), t = !0)
                    }), d.on("resize", function(a) {
                        o = h.offset().top, f.hide(), i.show(), c.setNavWidth(), c.anchorFunctionality && (c.setSectionOffsets(), m = !1), t = !0, s || f.removeClass("fade-background"), c.removeSideGradients([i, f]), s = c.isMobileSubHeaderView()
                    })
                }
            },
            isMobileSubHeaderView: function() {
                return typeof window.matchMedia == "function" && window.matchMedia("(min-width: 992px)").matches ? !1 : !0
            },
            isVisible: function(a) {
                return b.isElementInViewport(a) && a.is(":visible")
            },
            removeSideGradients: function(b) {
                c.isMobileSubHeaderView() && a.each(b, function() {
                    a(this).removeClass("show-left-gradient show-right-gradient")
                })
            },
            scrollToNavItem: function(a, b) {
                var c = '[href="' + b + '"]';
                try {
                    a.scrollToElement(c, 750, !0, !0, IScroll.utils.ease.circular)
                } catch (d) {
                    console.error("Scroll to Nav Item Failed! " + d)
                }
            },
            setAnchorFunctionality: function() {
                c.firstNavItem.indexOf("#") !== 0 && (c.anchorFunctionality = !1)
            },
            setActiveNavItem: function(b) {
                if (b) {
                    var d = a(".header.header-version-b"),
                        e = c.navWrapper + " " + c.navItem + " a",
                        f = d.find(e),
                        g = a(e),
                        h = "[href='" + b + "']";
                    a(c.navItem).removeClass("active"), f.filter(h).parent().addClass("active"), g.filter(h).parent().addClass("active")
                }
            },
            setNavWidth: function() {
                var b = a(".header.header-version-b"),
                    d = b.find(c.nav),
                    e = a(c.element),
                    f = e.find(c.nav),
                    g = 0;
                f.find(c.navItem).each(function() {
                    g += Math.ceil(c.getWidth(a(this)))
                }), g += 5, c.navWidth = g, f.css({
                    width: g + "px",
                    opacity: "1"
                }), d.css({
                    width: g + "px",
                    opacity: "1"
                })
            },
            setSectionOffsets: function() {
                var b = a(c.topicWrapperContent);
                c.sectionOffsets = [], b.find(c.topicSection).each(function() {
                    if (a(this).attr("id")) {
                        var b = a(this).offset().top,
                            d = b + c.getHeight(a(this));
                        c.sectionOffsets.push({
                            id: "#" + a(this).attr("id"),
                            top: b,
                            bottom: d
                        })
                    }
                })
            },
            setSideGradients: function(b) {
			//alert("!!!");
                if (c.isMobileSubHeaderView()) {
                    var d, e, f;
                    a.each(b, function() {
                        e = a(this).find(c.navItem), a(this).is(":visible") && (d = e.first(), f = e.last(), (!c.isVisible(d) || !c.isVisible(f)) && a(this).addClass("show-left-gradient").addClass("show-right-gradient"), c.isVisible(d) && a(this).removeClass("show-left-gradient"), c.isVisible(f) && a(this).removeClass("show-right-gradient"))
                    })
                }
            },
            smoothScrollTo: function(b) {
                var d = a(".header.header-version-b"),
                    e = d.height(),
                    f = d.find(c.navWrapper).height(),
                    g = Math.round(a(b).offset().top),
                    h = g - e - f;
                a("html,body").animate({
                    scrollTop: h
                }, 750, function() {
                    c.disableNavActiveState && (c.disableNavActiveState = !1), a(b).focus()
                })
            }
        };
        return {
            init: function(a) {
                c.init(a)
            },
            lazyInit: function(b) {
                var d = a(c.topicWrapperContent),
                    e = d.find("img");
                if (e.length === 0) c.init(b);
                else var f = setInterval(function() {
                    e.last()[0].complete && (c.init(b), clearInterval(f))
                }, 100)
            }
        }
    }),
    function() {
        function m(a) {
            return a = String(a), a.charAt(0).toUpperCase() + a.slice(1)
        }

        function n(a, b, c) {
            var d = {
                6.4: "10",
                6.3: "8.1",
                6.2: "8",
                6.1: "Server 2008 R2 / 7",
                "6.0": "Server 2008 / Vista",
                5.2: "Server 2003 / XP 64-bit",
                5.1: "XP",
                5.01: "2000 SP1",
                "5.0": "2000",
                "4.0": "NT",
                "4.90": "ME"
            };
            return b && c && /^Win/i.test(a) && (d = d[0, /[\d.]+$/.exec(a)]) && (a = "Windows " + d), a = String(a), b && c && (a = a.replace(RegExp(b, "i"), c)), a = p(a.replace(/ ce$/i, " CE").replace(/\bhpw/i, "web").replace(/\bMacintosh\b/, "Mac OS").replace(/_PowerPC\b/i, " OS").replace(/\b(OS X) [^ \d]+/i, "$1").replace(/\bMac (OS X)\b/, "$1").replace(/\/(\d)/, " $1").replace(/_/g, ".").replace(/(?: BePC|[ .]*fc[ \d.]+)$/i, "").replace(/\bx86\.64\b/gi, "x86_64").replace(/\b(Windows Phone) OS\b/, "$1").split(" on ")[0]), a
        }

        function o(a, b) {
            var c = -1,
                d = a ? a.length : 0;
            if (typeof d == "number" && d > -1 && d <= g)
                while (++c < d) b(a[c], c, a);
            else q(a, b)
        }

        function p(a) {
            return a = v(a), /^(?:webOS|i(?:OS|P))/.test(a) ? a : m(a)
        }

        function q(a, b) {
            for (var c in a) k.call(a, c) && b(a[c], c, a)
        }

        function r(a) {
            return a == null ? m(a) : l.call(a).slice(8, -1)
        }

        function s(a, b) {
            var c = a != null ? typeof a[b] : "number";
            return !/^(?:boolean|number|string|undefined)$/.test(c) && (c == "object" ? !!a[b] : !0)
        }

        function t(a) {
            return String(a).replace(/([ -])(?!$)/g, "$1?")
        }

        function u(a, b) {
            var c = null;
            return o(a, function(d, e) {
                c = b(c, d, e, a)
            }), c
        }

        function v(a) {
            return String(a).replace(/^ +| +$/g, "")
        }

        function w(a) {
            function T(b) {
                return u(b, function(b, c) {
                    return b || RegExp("\\b" + (c.pattern || t(c)) + "\\b", "i").exec(a) && (c.label || c)
                })
            }

            function U(b) {
                return u(b, function(b, c, d) {
                    return b || (c[Q] || c[0, /^[a-z]+(?: +[a-z]+\b)*/i.exec(Q)] || RegExp("\\b" + t(d) + "(?:\\b|\\w*\\d)", "i").exec(a)) && d
                })
            }

            function V(b) {
                return u(b, function(b, c) {
                    return b || RegExp("\\b" + (c.pattern || t(c)) + "\\b", "i").exec(a) && (c.label || c)
                })
            }

            function W(b) {
                return u(b, function(b, c) {
                    var d = c.pattern || t(c);
                    return !b && (b = RegExp("\\b" + d + "(?:/[\\d.]+|[ \\w.]*)", "i").exec(a)) && (b = n(b, d, c.label || c)), b
                })
            }

            function X(b) {
                return u(b, function(b, c) {
                    var d = c.pattern || t(c);
                    return !b && (b = RegExp("\\b" + d + " *\\d+[.\\w_]*", "i").exec(a) || RegExp("\\b" + d + "(?:; *(?:[a-z]+[_-])?[a-z]+\\d+|[^ ();-]*)", "i").exec(a)) && ((b = String(c.label && !RegExp(d, "i").test(c.label) ? c.label : b).split("/"))[1] && !/[\d.]+/.test(b[0]) && (b[0] += " " + b[1]), c = c.label || c, b = p(b[0].replace(RegExp(d, "i"), c).replace(RegExp("; *(?:" + c + "[_-])?", "i"), " ").replace(RegExp("(" + c + ")[-_.]?(\\w)", "i"), "$1 $2"))), b
                })
            }

            function Y(b) {
                return u(b, function(b, c) {
                    return b || (RegExp(c + "(?:-[\\d.]+/|(?: for [\\w-]+)?[ /-])([\\d.]+[^ ();/_-]*)", "i").exec(a) || 0)[1] || null
                })
            }

            function Z() {
                return this.description || ""
            }
            var d = b,
                e = a && typeof a == "object" && r(a) != "String";
            e && (d = a, a = null);
            var f = d.navigator || {},
                g = f.userAgent || "";
            a || (a = g);
            var j = e || i == c,
                k = e ? !!f.likeChrome : /\bChrome\b/.test(a) && !/internal|\n/i.test(l.toString()),
                m = "Object",
                o = e ? m : "ScriptBridgingProxyObject",
                x = e ? m : "Environment",
                y = e && d.java ? "JavaPackage" : r(d.java),
                z = e ? m : "RuntimeObject",
                A = /\bJava/.test(y) && d.java,
                B = A && r(d.environment) == x,
                C = A ? "a" : "Î±",
                D = A ? "b" : "Î²",
                E = d.document || {},
                F = d.operamini || d.opera,
                G = h.test(G = e && F ? F["[[Class]]"] : r(F)) ? G : F = null,
                H, I = a,
                J = [],
                K = null,
                L = a == g,
                M = L && F && typeof F.version == "function" && F.version(),
                N, O = T(["Trident", {
                    label: "WebKit",
                    pattern: "AppleWebKit"
                }, "iCab", "Presto", "NetFront", "Tasman", "KHTML", "Gecko"]),
                P = V(["Adobe AIR", "Arora", "Avant Browser", "Breach", "Camino", "Epiphany", "Fennec", "Flock", "Galeon", "GreenBrowser", "iCab", "Iceweasel", {
                    label: "SRWare Iron",
                    pattern: "Iron"
                }, "K-Meleon", "Konqueror", "Lunascape", "Maxthon", "Midori", "Nook Browser", "PhantomJS", "Raven", "Rekonq", "RockMelt", "SeaMonkey", {
                    label: "Silk",
                    pattern: "(?:Cloud9|Silk-Accelerated)"
                }, "Sleipnir", "SlimBrowser", "Sunrise", "Swiftfox", "WebPositive", "Opera Mini", {
                    label: "Opera Mini",
                    pattern: "OPiOS"
                }, "Opera", {
                    label: "Opera",
                    pattern: "OPR"
                }, "Chrome", {
                    label: "Chrome Mobile",
                    pattern: "(?:CriOS|CrMo)"
                }, {
                    label: "Firefox",
                    pattern: "(?:Firefox|Minefield)"
                }, {
                    label: "IE",
                    pattern: "IEMobile"
                }, {
                    label: "IE",
                    pattern: "MSIE"
                }, "Safari"]),
                Q = X([{
                    label: "BlackBerry",
                    pattern: "BB10"
                }, "BlackBerry", {
                    label: "Galaxy S",
                    pattern: "GT-I9000"
                }, {
                    label: "Galaxy S2",
                    pattern: "GT-I9100"
                }, {
                    label: "Galaxy S3",
                    pattern: "GT-I9300"
                }, {
                    label: "Galaxy S4",
                    pattern: "GT-I9500"
                }, "Google TV", "Lumia", "iPad", "iPod", "iPhone", "Kindle", {
                    label: "Kindle Fire",
                    pattern: "(?:Cloud9|Silk-Accelerated)"
                }, "Nook", "PlayBook", "PlayStation 4", "PlayStation 3", "PlayStation Vita", "TouchPad", "Transformer", {
                    label: "Wii U",
                    pattern: "WiiU"
                }, "Wii", "Xbox One", {
                    label: "Xbox 360",
                    pattern: "Xbox"
                }, "Xoom"]),
                R = U({
                    Apple: {
                        iPad: 1,
                        iPhone: 1,
                        iPod: 1
                    },
                    Amazon: {
                        Kindle: 1,
                        "Kindle Fire": 1
                    },
                    Asus: {
                        Transformer: 1
                    },
                    "Barnes & Noble": {
                        Nook: 1
                    },
                    BlackBerry: {
                        PlayBook: 1
                    },
                    Google: {
                        "Google TV": 1
                    },
                    HP: {
                        TouchPad: 1
                    },
                    HTC: {},
                    LG: {},
                    Microsoft: {
                        Xbox: 1,
                        "Xbox One": 1
                    },
                    Motorola: {
                        Xoom: 1
                    },
                    Nintendo: {
                        "Wii U": 1,
                        Wii: 1
                    },
                    Nokia: {
                        Lumia: 1
                    },
                    Samsung: {
                        "Galaxy S": 1,
                        "Galaxy S2": 1,
                        "Galaxy S3": 1,
                        "Galaxy S4": 1
                    },
                    Sony: {
                        "PlayStation 4": 1,
                        "PlayStation 3": 1,
                        "PlayStation Vita": 1
                    }
                }),
                S = W(["Windows Phone ", "Android", "CentOS", "Debian", "Fedora", "FreeBSD", "Gentoo", "Haiku", "Kubuntu", "Linux Mint", "Red Hat", "SuSE", "Ubuntu", "Xubuntu", "Cygwin", "Symbian OS", "hpwOS", "webOS ", "webOS", "Tablet OS", "Linux", "Mac OS X", "Macintosh", "Mac", "Windows 98;", "Windows "]);
            O && (O = [O]), R && !Q && (Q = X([R]));
            if (H = /\bGoogle TV\b/.exec(Q)) Q = H[0];
            /\bSimulator\b/i.test(a) && (Q = (Q ? Q + " " : "") + "Simulator"), P == "Opera Mini" && /\bOPiOS\b/.test(a) && J.push("running in Turbo/Uncompressed mode");
            if (/^iP/.test(Q)) P || (P = "Safari"), S = "iOS" + ((H = / OS ([\d_]+)/i.exec(a)) ? " " + H[1].replace(/_/g, ".") : "");
            else if (P == "Konqueror" && !/buntu/i.test(S)) S = "Kubuntu";
            else if (R && R != "Google" && (/Chrome/.test(P) && !/\bMobile Safari\b/i.test(a) || /\bVita\b/.test(Q))) P = "Android Browser", S = /\bAndroid\b/.test(S) ? S : "Android";
            else if (!P || (H = !/\bMinefield\b|\(Android;/i.test(a) && /\b(?:Firefox|Safari)\b/.exec(P))) P && !Q && /[\/,]|^[^(]+?\)/.test(a.slice(a.indexOf(H + "/") + 8)) && (P = null), (H = Q || R || S) && (Q || R || /\b(?:Android|Symbian OS|Tablet OS|webOS)\b/.test(S)) && (P = /[a-z]+(?: Hat)?/i.exec(/\bAndroid\b/.test(S) ? S : H) + " Browser");
            (H = /\((Mobile|Tablet).*?Firefox\b/i.exec(a)) && H[1] && (S = "Firefox OS", Q || (Q = H[1])), M || (M = Y(["(?:Cloud9|CriOS|CrMo|IEMobile|Iron|Opera ?Mini|OPiOS|OPR|Raven|Silk(?!/[\\d.]+$))", "Version", t(P), "(?:Firefox|Minefield|NetFront)"])), O == "iCab" && parseFloat(M) > 3 ? O = ["WebKit"] : O != "Trident" && (H = /\bOpera\b/.test(P) && (/\bOPR\b/.test(a) ? "Blink" : "Presto") || /\b(?:Midori|Nook|Safari)\b/i.test(a) && "WebKit" || !O && /\bMSIE\b/i.test(a) && (S == "Mac OS" ? "Tasman" : "Trident")) ? O = [H] : /\bPlayStation\b(?! Vita\b)/i.test(P) && O == "WebKit" && (O = ["NetFront"]), P == "IE" && (H = (/; *(?:XBLWP|ZuneWP)(\d+)/i.exec(a) || 0)[1]) ? (P += " Mobile", S = "Windows Phone " + (/\+$/.test(H) ? H : H + ".x"), J.unshift("desktop mode")) : /\bWPDesktop\b/i.test(a) ? (P = "IE Mobile", S = "Windows Phone 8+", J.unshift("desktop mode"), M || (M = (/\brv:([\d.]+)/.exec(a) || 0)[1])) : P != "IE" && O == "Trident" && (H = /\brv:([\d.]+)/.exec(a)) ? (/\bWPDesktop\b/i.test(a) || (P && J.push("identifying as " + P + (M ? " " + M : "")), P = "IE"), M = H[1]) : (P == "Chrome" || P != "IE") && (H = /\bEdge\/([\d.]+)/.exec(a)) && (P = "IE", M = H[1], O = ["Trident"], J.unshift("platform preview"));
            if (L) {
                if (s(d, "global")) {
                    A && (H = A.lang.System, I = H.getProperty("os.arch"), S = S || H.getProperty("os.name") + " " + H.getProperty("os.version"));
                    if (j && s(d, "system") && (H = [d.system])[0]) {
                        S || (S = H[0].os || null);
                        try {
                            H[1] = d.require("ringo/engine").version, M = H[1].join("."), P = "RingoJS"
                        } catch ($) {
                            H[0].global.system == d.system && (P = "Narwhal")
                        }
                    } else typeof d.process == "object" && (H = d.process) ? (P = "Node.js", I = H.arch, S = H.platform, M = /[\d.]+/.exec(H.version)[0]) : B && (P = "Rhino")
                } else r(H = d.runtime) == o ? (P = "Adobe AIR", S = H.flash.system.Capabilities.os) : r(H = d.phantom) == z ? (P = "PhantomJS", M = (H = H.version || null) && H.major + "." + H.minor + "." + H.patch) : typeof E.documentMode == "number" && (H = /\bTrident\/(\d+)/i.exec(a)) && (M = [M, E.documentMode], (H = +H[1] + 4) != M[1] && (J.push("IE " + M[1] + " mode"), O && (O[1] = ""), M[1] = H), M = P == "IE" ? String(M[1].toFixed(1)) : M[0]);
                S = S && p(S)
            }
            M && (H = /(?:[ab]|dp|pre|[ab]\d+pre)(?:\d+\+?)?$/i.exec(M) || /(?:alpha|beta)(?: ?\d)?/i.exec(a + ";" + (L && f.appMinorVersion)) || /\bMinefield\b/i.test(a) && "a") && (K = /b/i.test(H) ? "beta" : "alpha", M = M.replace(RegExp(H + "\\+?$"), "") + (K == "beta" ? D : C) + (/\d+\+?/.exec(H) || "")), P == "Fennec" || P == "Firefox" && /\b(?:Android|Firefox OS)\b/.test(S) ? P = "Firefox Mobile" : P == "Maxthon" && M ? M = M.replace(/\.[\d.]+/, ".x") : P == "Silk" ? (/\bMobi/i.test(a) || (S = "Android", J.unshift("desktop mode")), /Accelerated *= *true/i.test(a) && J.unshift("accelerated")) : /\bXbox\b/i.test(Q) ? (S = null, Q == "Xbox 360" && /\bIEMobile\b/.test(a) && J.unshift("mobile mode")) : (/^(?:Chrome|IE|Opera)$/.test(P) || P && !Q && !/Browser|Mobi/.test(P)) && (S == "Windows CE" || /Mobi/i.test(a)) ? P += " Mobile" : P == "IE" && L && d.external === null ? J.unshift("platform preview") : (/\bBlackBerry\b/.test(Q) || /\bBB10\b/.test(a)) && (H = (RegExp(Q.replace(/ +/g, " *") + "/([.\\d]+)", "i").exec(a) || 0)[1] || M) ? (H = [H, /BB10/.test(a)], S = (H[1] ? (Q = null, R = "BlackBerry") : "Device Software") + " " + H[0], M = null) : this != q && Q != "Wii" && (L && F || /Opera/.test(P) && /\b(?:MSIE|Firefox)\b/i.test(a) || P == "Firefox" && /\bOS X (?:\d+\.){2,}/.test(S) || P == "IE" && (S && !/^Win/.test(S) && M > 5.5 || /\bWindows XP\b/.test(S) && M > 8 || M == 8 && !/\bTrident\b/.test(a))) && !h.test(H = w.call(q, a.replace(h, "") + ";")) && H.name && (H = "ing as " + H.name + ((H = H.version) ? " " + H : ""), h.test(P) ? (/\bIE\b/.test(H) && S == "Mac OS" && (S = null), H = "identify" + H) : (H = "mask" + H, G ? P = p(G.replace(/([a-z])([A-Z])/g, "$1 $2")) : P = "Opera", /\bIE\b/.test(H) && (S = null), L || (M = null)), O = ["Presto"], J.push(H));
            if (H = (/\bAppleWebKit\/([\d.]+\+?)/i.exec(a) || 0)[1]) {
                H = [parseFloat(H.replace(/\.(\d)$/, ".0$1")), H];
                if (P == "Safari" && H[1].slice(-1) == "+") P = "WebKit Nightly", K = "alpha", M = H[1].slice(0, -1);
                else if (M == H[1] || M == (H[2] = (/\bSafari\/([\d.]+\+?)/i.exec(a) || 0)[1])) M = null;
                H[1] = (/\bChrome\/([\d.]+)/i.exec(a) || 0)[1], H[0] == 537.36 && H[2] == 537.36 && parseFloat(H[1]) >= 28 && P != "IE" && (O = ["Blink"]), !L || !k && !H[1] ? (O && (O[1] = "like Safari"), H = (H = H[0], H < 400 ? 1 : H < 500 ? 2 : H < 526 ? 3 : H < 533 ? 4 : H < 534 ? "4+" : H < 535 ? 5 : H < 537 ? 6 : H < 538 ? 7 : H < 601 ? 8 : "8")) : (O && (O[1] = "like Chrome"), H = H[1] || (H = H[0], H < 530 ? 1 : H < 532 ? 2 : H < 532.05 ? 3 : H < 533 ? 4 : H < 534.03 ? 5 : H < 534.07 ? 6 : H < 534.1 ? 7 : H < 534.13 ? 8 : H < 534.16 ? 9 : H < 534.24 ? 10 : H < 534.3 ? 11 : H < 535.01 ? 12 : H < 535.02 ? "13+" : H < 535.07 ? 15 : H < 535.11 ? 16 : H < 535.19 ? 17 : H < 536.05 ? 18 : H < 536.1 ? 19 : H < 537.01 ? 20 : H < 537.11 ? "21+" : H < 537.13 ? 23 : H < 537.18 ? 24 : H < 537.24 ? 25 : H < 537.36 ? 26 : O != "Blink" ? "27" : "28")), O && (O[1] += " " + (H += typeof H == "number" ? ".x" : /[.+]/.test(H) ? "" : "+")), P == "Safari" && (!M || parseInt(M) > 45) && (M = H)
            }
            P == "Opera" && (H = /\bzbov|zvav$/.exec(S)) ? (P += " ", J.unshift("desktop mode"), H == "zvav" ? (P += "Mini", M = null) : P += "Mobile", S = S.replace(RegExp(" *" + H + "$"), "")) : P == "Safari" && /\bChrome\b/.exec(O && O[1]) && (J.unshift("desktop mode"), P = "Chrome Mobile", M = null, /\bOS X\b/.test(S) ? (R = "Apple", S = "iOS 4.3+") : S = null), M && M.indexOf(H = /[\d.]+$/.exec(S)) == 0 && a.indexOf("/" + H + "-") > -1 && (S = v(S.replace(H, ""))), O && !/\b(?:Avant|Nook)\b/.test(P) && (/Browser|Lunascape|Maxthon/.test(P) || /^(?:Adobe|Arora|Breach|Midori|Opera|Phantom|Rekonq|Rock|Sleipnir|Web)/.test(P) && O[1]) && (H = O[O.length - 1]) && J.push(H), J.length && (J = ["(" + J.join("; ") + ")"]), R && Q && Q.indexOf(R) < 0 && J.push("on " + R), Q && J.push((/^on /.test(J[J.length - 1]) ? "" : "on ") + Q), S && (H = / ([\d.+]+)$/.exec(S), N = H && S.charAt(S.length - H[0].length - 1) == "/", S = {
                architecture: 32,
                family: H && !N ? S.replace(H[0], "") : S,
                version: H ? H[1] : null,
                toString: function() {
                    var a = this.version;
                    return this.family + (a && !N ? " " + a : "") + (this.architecture == 64 ? " 64-bit" : "")
                }
            }), (H = /\b(?:AMD|IA|Win|WOW|x86_|x)64\b/i.exec(I)) && !/\bi686\b/i.test(I) && (S && (S.architecture = 64, S.family = S.family.replace(RegExp(" *" + H), "")), P && (/\bWOW64\b/i.test(a) || L && /\w(?:86|32)$/.test(f.cpuClass || f.platform) && !/\bWin64; x64\b/i.test(a)) && J.unshift("32-bit")), a || (a = null);
            var _ = {};
            return _.description = a, _.layout = O && O[0], _.manufacturer = R, _.name = P, _.prerelease = K, _.product = Q, _.ua = a, _.version = P && M, _.os = S || {
                architecture: null,
                family: null,
                version: null,
                toString: function() {
                    return "null"
                }
            }, _.parse = w, _.toString = Z, _.version && J.unshift(M), _.name && J.unshift(P), S && P && (S != String(S).split(" ")[0] || S != P.split(" ")[0] && !Q) && J.push(Q ? "(" + S + ")" : "on " + S), J.length && (_.description = J.join(" ")), _
        }
        var a = {
                "function": !0,
                object: !0
            },
            b = a[typeof window] && window || this,
            c = b,
            d = a[typeof exports] && exports,
            e = a[typeof module] && module && !module.nodeType && module,
            f = d && e && typeof global == "object" && global;
        f && (f.global === f || f.window === f || f.self === f) && (b = f);
        var g = Math.pow(2, 53) - 1,
            h = /\bOpera/,
            i = this,
            j = Object.prototype,
            k = j.hasOwnProperty,
            l = j.toString;
        typeof define == "function" && typeof define.amd == "object" && define.amd ? define("platform", [], function() {
            return w()
        }) : d && e ? q(w(), function(a, b) {
            d[b] = a
        }) : b.platform = w()
    }.call(this), define("amd/env", ["jquery", "platform"], function(a, b) {
        var c, d = a("html"),
            e = a("body"),
            f = {
                englishLang: "en_us",
                spanishLang: "es_us",
                supportedBrowsers: {
                    Firefox: 24,
                    "Firefox Mobile": 24,
                    IE: 10,
                    "IE Mobile": 10,
                    Chrome: 38,
                    "Chrome Mobile": 1,
                    Safari: 6.2,
                    "Android Browser": 4,
                    Silk: 3,
                    "BlackBerry Browser": 7,
                    "Nokia Browser": 8,
                    "Opera Mini": 7,
                    "PlayBook Browser": 7
                },
                areCookiesSupported: function() {
                    var a = !1;
                    return "cookie" in document && (document.cookie = "cookietest=1", a = document.cookie.indexOf("cookietest=") !== -1, document.cookie = "cookietest=1; expires=Thu, 01-Jan-1970 00:00:01 GMT"), a
                },
                device: {
                    name: b.name.toLowerCase(),
                    version: parseFloat(b.version),
                    isUnSupportedBrowser: function() {
                        var a = f.supportedBrowsers[b.name];
                        return !a || a > parseFloat(b.version)
                    },
                    isFirefox: function() {
                        return b.name.toLowerCase() === "firefox"
                    },
                    isIE: function() {
                        return b.name.toLowerCase() === "ie"
                    },
                    isIE8: function() {
                        return this.isIE() && this.version === 8
                    },
                    isIE9: function() {
                        return this.isIE() && this.version === 9
                    }
                },
                page: {
                    isEnglish: function() {
                        return d.attr("lang") === f.englishLang
                    },
                    isSpanish: function() {
                        return d.attr("lang") === f.spanishLang
                    },
                    getLanguage: function() {
                        return d.attr("lang")
                    },
                    isDetailPageType: function() {
                        return e.hasClass("detail")
                    },
                    isStaticPageType: function() {
                        return e.hasClass("static-page")
                    }
                }
            };
        return {
            getInstance: function() {
                return c || (c = {
                    areCookiesSupported: f.areCookiesSupported(),
                    deviceName: f.device.name,
                    deviceVersion: f.device.version,
                    isUnSupportedBrowser: f.device.isUnSupportedBrowser(),
                    isFirefox: f.device.isFirefox(),
                    isIE: f.device.isIE(),
                    isIE8: f.device.isIE8(),
                    isIE9: f.device.isIE9(),
                    isEnglishPage: f.page.isEnglish(),
                    isSpanishPage: f.page.isSpanish(),
                    getPageLanguage: f.page.getLanguage(),
                    isDetailPageType: f.page.isDetailPageType(),
                    isStaticPageType: f.page.isStaticPageType()
                }), c
            }
        }
    }),
    function(a) {
        typeof define == "function" && define.amd ? define("jquery.cookie", ["jquery"], a) : typeof exports == "object" ? a(require("jquery")) : a(jQuery)
    }(function(a) {
        function c(a) {
            return h.raw ? a : encodeURIComponent(a)
        }

        function d(a) {
            return h.raw ? a : decodeURIComponent(a)
        }

        function e(a) {
            return c(h.json ? JSON.stringify(a) : String(a))
        }

        function f(a) {
            a.indexOf('"') === 0 && (a = a.slice(1, -1).replace(/\\"/g, '"').replace(/\\\\/g, "\\"));
            try {
                return a = decodeURIComponent(a.replace(b, " ")), h.json ? JSON.parse(a) : a
            } catch (c) {}
        }

        function g(b, c) {
            var d = h.raw ? b : f(b);
            return a.isFunction(c) ? c(d) : d
        }
        var b = /\+/g,
            h = a.cookie = function(b, f, i) {
                if (arguments.length > 1 && !a.isFunction(f)) {
                    i = a.extend({}, h.defaults, i);
                    if (typeof i.expires == "number") {
                        var j = i.expires,
                            k = i.expires = new Date;
                        k.setTime(+k + j * 864e5)
                    }
                    return document.cookie = [c(b), "=", e(f), i.expires ? "; expires=" + i.expires.toUTCString() : "", i.path ? "; path=" + i.path : "", i.domain ? "; domain=" + i.domain : "", i.secure ? "; secure" : ""].join("")
                }
                var l = b ? undefined : {},
                    m = document.cookie ? document.cookie.split("; ") : [];
                for (var n = 0, o = m.length; n < o; n++) {
                    var p = m[n].split("="),
                        q = d(p.shift()),
                        r = p.join("=");
                    if (b && b === q) {
                        l = g(r, f);
                        break
                    }!b && (r = g(r)) !== undefined && (l[q] = r)
                }
                return l
            };
        h.defaults = {}, a.removeCookie = function(b, c) {
            return a.cookie(b) === undefined ? !1 : (a.cookie(b, "", a.extend({}, c, {
                expires: -1
            })), !a.cookie(b))
        }
    }), define("amd/cookie", ["jquery", "jquery.cookie", "has"], function(a, b, c, d) {
        c.add("cookies", function(a, b, c) {
            var d = !1;
            return "cookie" in b && (b.cookie = "cookietest=1", d = b.cookie.indexOf("cookietest=") !== -1, b.cookie = "cookietest=1; expires=Thu, 01-Jan-1970 00:00:01 GMT"), d
        });
        if (c("cookies")) {
            var e = window.document.domain,
                f = window.location.protocol,
                g = /localhost|127\.0\.0\.1/.test(e),
                h = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/.test(e),
                i = /https/.test(f),
                j = function() {
                    var a;
                    return g || (h ? a = e : e.indexOf(".") !== -1 && (a = "." + e.split(".").slice(-2).join("."))), a
                },
                k = j(),
                l = function(b, c) {
                    l.cookies = l.cookies || {};
                    var d = b && l.cookies[b];
                    return d || (d = {
                        settings: c || {},
                        erase: function(c) {
                            var d = a.extend({}, this.settings, c || {});
                            try {
                                a.removeCookie(b, d)
                            } catch (e) {}
                        },
                        read: function() {
                            var c;
                            try {
                                c = a.cookie(b)
                            } catch (d) {}
                            return c
                        },
                        write: function(c, d) {
                            var e = a.extend({}, this.settings, d || {});
                            try {
                                a.cookie(b, c, e)
                            } catch (f) {}
                        }
                    }, b && (l.cookies[b] = d)), d
                };
            return a.cookie.raw = !0, a.cookie.defaults = a.extend({
                secure: i
            }, k ? {
                domain: k
            } : {}), l
        }
    }), define("amd/timeout-message", ["jquery", "platform", "amd/cookie", "amd/env"], function(a, b, c, d) {
        var e = {
            message: ".timeout-message",
            sessionMessage: "[data-session-message]",
            logoffMessage: "[data-logoff-message]",
            dismissButton: ".timeout-message__dismiss-btn",
            signIn: "#signin-module",
            sideMenu: "#skip-sidemenu",
            browserMessage: ".browser-message",
            timeoutMessageWrapper: ".timeout-message__wrapper",
            logoffCookie: a.proxy(c, this, "_logofftype"),
            readCookie: function() {
                if (d.getInstance().areCookiesSupported && this.logoffCookie().read() !== undefined) return this.logoffCookie().read()
            },
            setMessage: function() {
                var b = e.readCookie();
                b === "session" ? (a(e.sessionMessage).addClass("display"), a(e.textMessage).focus()) : b === "logoff" ? (a(e.logoffMessage).addClass("display"), a(e.textMessage).focus()) : a(e.message).hide()
            },
            deleteCookie: function() {
                d.getInstance().areCookiesSupported && this.logoffCookie().erase({
                    path: "/"
                })
            }
        };
        return {
            init: function() {
                var b = a(window),
                    c = a(e.dismissButton),
                    d = a(".timeout-message__text-msg"),
                    f = a(".timeout-message__dismiss-btn"),
                    g = a("body").attr("data-archetype");
                if (g === "logoff") {
                    e.setMessage(), a(e.message).fadeIn("slow"), a(e.signIn).fadeOut("slow"), e.deleteCookie(), d.focus(), a(document).on("keydown", function(b) {
                        b.keyCode === 9 ? d.is(":focus") ? (f.focus(), b.preventDefault()) : f.is(":focus") && (d.focus(), b.preventDefault()) : b.keyCode === 32 && f.is(":focus") && (a(e.message).hide(), b.preventDefault())
                    });
                    var h = !0;
                    b.on("scroll click", function() {
                        h && (a(e.message).hide(), a(".site-message").hasClass("visible") ? a(".site-message__inner-container").focus() : a(".browser-message").hasClass("visible") ? a(".browser-message__inner-container").focus() : a(e.sideMenu).focus(), h = !1)
                    })
                }
            }
        }
    }), define("amd/persona", ["jquery", "amd/cookie", "has"], function(a, b, c, d) {
        var e, f = {}.toString,
            g = new Date,
            h = "[object Function]";
        c.add("cookies", function(a, b, c) {
            var d = !1;
            return "cookie" in b && (b.cookie = "cookietest=1", d = b.cookie.indexOf("cookietest=") !== -1, b.cookie = "cookietest=1; expires=Thu, 01-Jan-1970 00:00:01 GMT"), d
        }), c.add("date-toisostring", function(a, b, c) {
            return f.call(g.toISOString) == h
        });
        if (c("cookies")) {
            var i = window.document,
                j = window.decodeURIComponent,
                k = window.encodeURIComponent,
                l = window.escape,
                m = window.unescape,
                n = "PC_1_0",
                o = function(a, b) {
                    a = a.split("");
                    for (var c = 0, e = a.length; c < e; c++) b[a[c]] !== d && delete b[a[c]]
                },
                p = function() {
                    var a = new Date,
                        b;
                    if (c("date-toisostring")) b = a.toISOString().split("T")[0];
                    else {
                        var d = function(a, b) {
                                var c = String(a);
                                b = b || 2;
                                for (var d = 0, e = b - c.length; d < e; d++) return c = "0" + c, c
                            },
                            e = a.getFullYear(),
                            f = d(a.getMonth() + 1),
                            g = d(a.getDate());
                        b = [e, f, g].join("-")
                    }
                    return b
                },
                q = function(a) {
                    var b = {};
                    if (a)
                        for (var c = 0, d = a.length; c < d; c++) {
                            var e = a[c];
                            b[e[0]] = {}, b[e[0]].uratc = e[1], b[e[0]].rwdb = e[2]
                        }
                    return b
                },
                r = function(b) {
                    var c = v(m(b), "|"),
                        d = {};
                    for (var e = 0, f = c.length; e < f; e++) {
                        var g = c[e].split("="),
                            h = g[0],
                            i = v(j(g[1]), "&");
                        if (a.isArray(i))
                            for (var k = 0, l = i.length; k < l; k++) {
                                var n = i.shift();
                                n = n.split(","), i.push(n)
                            } else i = v(i, ",");
                        d[h] = i
                    }
                    return d
                },
                s = function(a, b, c) {
                    var d = c[a];
                    if (d)
                        for (var e = 0, f = d.length; e < f; e++)
                            if (b == d[e]) return "Y";
                    return "N"
                },
                t = function(b) {
                    var c = [],
                        d, e, f, g;
                    return a.each(b, function(b, h) {
                        d = a.isArray(h), e = d && !h.length && a.isArray(h[0]), f = w(b, h);
                        if (f) {
                            if (e) {
                                for (var i = 0, j = h.length; i < j; i++) {
                                    var m = h.shift();
                                    m = m.join(","), h.push(m)
                                }
                                h = u(h, "&")
                            }
                            d && (h = u(h, ",")), g = e ? l(b + "=") + h : l(b + "=" + k(h)), c.push(g)
                        }
                    }), u(c, "|")
                },
                u = function(b, c) {
                    return a.isArray(b) ? b.join(c) + c : b
                },
                v = function(a, b) {
                    if (a.indexOf(b) !== -1) {
                        var c = a.charAt(a.length - 1) === b,
                            d = c && a.charAt(a.length - 2) === b;
                        return (c && !d ? a.substring(0, a.length - 1) : a).split(b)
                    }
                    return a
                },
                w = function(b, c) {
                    var d = /^([A-Za-z0-9]{1,5}|,)*$/,
                        e = /^[A-Fa-f0-9]{8}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{4}-[A-Fa-f0-9]{12}$/,
                        f = /^\d{4}-\d{2}-\d{2}$/,
                        g = /^(Y|N)$/,
                        h = /^([A-Za-z0-9]{3,4}|,)*$/,
                        i = /^\d{5}-?(\d{4})?$/,
                        j = function(a, b) {
                            return a.test(b)
                        },
                        k = {
                            AOC: a.proxy(j, this, d),
                            GUID: a.proxy(j, this, g),
                            known: a.proxy(j, this, g),
                            lastSent: a.proxy(j, this, f),
                            lastUpdate: a.proxy(j, this, f),
                            RPC: a.proxy(j, this, h),
                            segment: function(a) {
                                return a.length === 3
                            },
                            source_code_applied: function(a) {
                                return a.length === 4
                            },
                            zip: a.proxy(j, this, i)
                        },
                        l = a.isFunction(k[b]) ? k[b](c) : !0;
                    return l
                },
                x = a.proxy(b, this, n, {
                    path: "/",
                    expires: 365
                });
            e = function() {
                return {
                    erase: function() {
                        x().erase()
                    },
                    read: function(a) {
                        a = a || !1;
                        var b = x().read(),
                            c;
                        if (a) c = b;
                        else try {
                            b = r(b), b.pplr = s("ppl", "A", b), b.fieir = s("fiei", "Y", b), b.fpeir = s("fpei", "Y", b), b.sieir = s("siei", "Y", b), b.tieir = s("tiei", "Y", b), b.accounts = q(b.accts), c = b
                        } catch (d) {}
                        return c
                    },
                    write: function(a) {
                        try {
                            var b = p();
                            typeof a == "string" && (a = r(a)), a.lastUpdate = b, a.lastSent = a.lastSent || a.lastUpdate, a.segment && a.seg && delete a.seg, o("fieir fpeir pplr sieir tieir accounts", a), a = t(a), x().write(a)
                        } catch (c) {}
                    }
                }
            }
        }
        return e
    }), define("amd/dynamic-page-creation", ["jquery", "amd/timeout-message", "amd/cookie", "amd/persona", "amd/env", "jquery.cookie"], function(a, b, c, d, e) {
        var f = {
            SPANISH_LANG_CODE: "es_us",
            ENGLISH_LANG_CODE: "en_us",
            DROPZONE: ".main-content--dropzone",
            layouts: [],
            currentLayout: {},
            archetype: "",
            variant: "",
            analyticsArchetype: "",
            deferredArchetype: a.Deferred(),
            cookieArchetype: "",
            cookieVariant: "",
            cookieLocale: "",
            SetLayouts: function(a) {
                typeof a != "undefined" ? this.layouts = a : window.console && console.error("Dynamic Page Error: Invalid layouts object.")
            },
            GetAllLayoutArchetypes: function(b) {
                var c = [];
                for (var d = 0; d < this.layouts.length; d++) {
                    var e = this.layouts[d].id.split("_")[0];
                    a.inArray(e, c) === -1 && (c[c.length] = e)
                }
                return c
            },
            FindLayout: function(a, b) {
                if (typeof a != "undefined")
                    for (var c = 0; c < this.layouts.length; c++)
                        if (typeof b != "undefined") {
                            if (this.layouts[c].id === a + "_" + b) return this.layouts[c]
                        } else if (this.layouts[c].id.slice(0, a.length) === a) return this.layouts[c];
                return null
            },
            LayoutExists: function(a, b) {
                return this.FindLayout(a, b) !== null
            },
            LogoffCookie: a.proxy(c, this, "_logofftype"),
            LogoffCookieExists: function() {
                return e.getInstance().areCookiesSupported ? typeof this.LogoffCookie().read() != "undefined" : !1
            },
            ReadLogoffCookie: function() {
                var a = "";
                if (e.getInstance().areCookiesSupported) {
                    var b = this.LogoffCookie().read();
                    typeof b != "undefined" ? a = b : window.console && console.log("Logoff Cookie Not Found")
                }
                return a
            },
            LayoutCookie: a.proxy(c, this, "_LayoutVariant", {
                expires: 60
            }),
            LayoutCookieExists: function() {
                return e.getInstance().areCookiesSupported ? typeof this.LayoutCookie().read() != "undefined" : !1
            },
            CreateLayoutCookie: function() {
                e.getInstance().areCookiesSupported && (this.LayoutCookie().write(JSON.stringify({
                    variant: this.variant
                })), window.console && console.log("Created Layout Cookie with Variant [" + this.variant + "]"))
            },
            DeleteLayoutCookie: function() {
                e.getInstance().areCookiesSupported && (this.LayoutCookie().erase(), window.console && console.log("Deleted Layout Cookie"))
            },
            ReadLayoutCookie: function() {
                if (e.getInstance().areCookiesSupported) {
                    var a = this.LayoutCookie().read();
                    if (typeof a != "undefined") {
                        var b;
                        try {
                            typeof a == "string" ? b = JSON.parse(a) : b = a
                        } catch (c) {
                            window.console && console.log("Error Parsing Layout Cookie")
                        }
                        b.variant && (this.cookieVariant = b.variant)
                    } else window.console && console.log("Layout Cookie Not Found")
                }
            },
            SetCurrentLayout: function() {
                this.currentLayout = this.FindLayout(this.archetype, this.variant);
                var c = a("body");
                c.attr("data-archetype", this.archetype), c.attr("data-variant", this.variant), c.trigger("Chase:ArchetypeSet"), f.analyticsArchetype = this.archetype, f.analyticsArchetype === "logoff" && f.LogoffCookieExists() && f.ReadLogoffCookie() === "session" && (f.analyticsArchetype = "timeout"), f.deferredArchetype.resolve(f.archetype), b.init()
            },
            GetAnalyticsLayout: function(a) {
                var b = f.analyticsArchetype,
                    c = f.variant,
                    d = a ? a : "_";
                return b + d + c
            },
            ReadPersonalizationCookie: function() {
                if (e.getInstance().areCookiesSupported) {
                    var a = d().read() || {};
                    if (a.eci || a.ECI) this.cookieArchetype = "returning";
                    a.locale && a.locale.toLowerCase() === "es_us" ? this.cookieLocale = "es_us" : a.locale && a.locale.toLowerCase() === "en_us" && (this.cookieLocale = "en_us")
                }
            },
            PrepareDropZone: function() {
                var b = a(this.DROPZONE);
                b.empty();
                var c = this.currentLayout,
                    d = c.aboveFoldModules.length + c.belowFoldModules.length;
                for (var e = 0; e < d; e++) b.append("<div id='Module" + e + "' class='module-container'></div>")
            },
            RenderAboveTheFoldFeatures: function() {
                var b = this;
                a.each(this.currentLayout.aboveFoldModules, function(a, c) {
                    b.LoadModule(c.url, a)
                })
            },
            RenderBelowTheFoldFeatures: function() {
                var b = this.currentLayout.aboveFoldModules.length,
                    c = this;
                a.each(this.currentLayout.belowFoldModules, function(a, d) {
                    c.LoadModule(d.url, b + a)
                })
            },
            LoadModule: function(b, c) {
                var d = a(this.DROPZONE),
                    e = "#Module" + c;
                b ? a.ajax({
                    url: b
                }).done(function(b) {
                    var c = a(e);
                    c.append(b), d.trigger("Chase:FeatureAppended", [e]), window.picturefill(), c.animate({
                        opacity: 1,
                        visibility: "visible"
                    }, 300)
                }).fail(function() {
                    window.console && console.error("Dynamic Page Error: Error requesting Module [" + b + "]")
                }) : window.console && console.error("Dynamic Page Error: Error with Module URL [" + b + "]")
            }
        };
        return {
            init: function(b) {
                var c = a(window),
                    g = a("html"),
                    h = g.attr("lang"),
                    i = b.overrideArchetype,
                    j = b.overrideVariant,
                    k = !1;
                f.SetLayouts(b.layouts);
                if (typeof i == "undefined" || typeof j == "undefined") {
                    f.ReadPersonalizationCookie();
                    var l = typeof b.languageRedirectDisabled != "undefined" ? b.languageRedirectDisabled : !1;
                    if (!l) {
                        var m = !1;
                        f.cookieLocale === f.ENGLISH_LANG_CODE && h === f.SPANISH_LANG_CODE ? m = !0 : f.cookieLocale === f.SPANISH_LANG_CODE && h === f.ENGLISH_LANG_CODE && (m = !0);
                        if (m && langRedirectURL) {
                            window.location.href = langRedirectURL;
                            return
                        }
                    } else window.console && console.log("Language Redirect Disabled for Authoring, Page Language [" + h + "]");
                    var n = f.GetAllLayoutArchetypes();
                    n.length === 1 ? f.archetype = n[0] : f.LogoffCookieExists() && a.inArray("logoff", n) !== -1 ? f.archetype = "logoff" : f.cookieArchetype === "returning" && a.inArray("returning", n) !== -1 ? f.archetype = "returning" : a.inArray("prospect", n) !== -1 ? f.archetype = "prospect" : a.inArray("returning", n) !== -1 ? f.archetype = "returning" : a.inArray("standalone", n) !== -1 ? f.archetype = "standalone" : f.archetype = n[0];
                    var o = f.LayoutExists(f.archetype, "a"),
                        p = f.LayoutExists(f.archetype, "b"),
                        q = f.LayoutCookieExists();
                    if (!o || !p || typeof b.testing == "undefined" || typeof b.testing[f.archetype] == "undefined") o ? f.variant = "a" : f.variant = "b", q && f.DeleteLayoutCookie();
                    else {
                        q && (f.ReadLayoutCookie(), window.console && console.log("Layout Cookie Exists with Variant [" + f.cookieVariant + "]"));
                        if (f.cookieVariant === "" || f.cookieVariant !== "a" && f.cookieVariant !== "b") {
                            var r = b.testing[f.archetype].b,
                                s = Math.floor(Math.random() * 100) + 1;
                            window.console && console.log("Random Number Generated [" + s + "], B Variant Percentage [" + r + "%]"), s <= r ? f.variant = "b" : f.variant = "a"
                        } else f.variant = f.cookieVariant;
                        q || f.CreateLayoutCookie()
                    }
                    window.console && console.log("Layout set to Archetype [" + f.archetype + "], Variant [" + f.variant + "]")
                } else f.archetype = i.replace(/_/g, ""), f.variant = j, window.console && console.log("Layout Overridden to Archetype [" + f.archetype + "], Variant [" + f.variant + "]");
                f.SetCurrentLayout(), f.PrepareDropZone();
                var t = b.baseAdPageId;
                typeof f.currentLayout != "undefined" ? typeof f.currentLayout.adPageId != "undefined" && f.currentLayout.adPageId !== "" && (t = f.currentLayout.adPageId) : window.console && console.error("Dynamic Page Error: No Layout Definition found for [" + layoutDefinitionId + "]."), require(["adservice"], function() {
                    require(["slotplacement/service"], function(a) {
                        a.init(t, {
                            locale: h,
                            pageLayout: f.GetAnalyticsLayout()
                        })
                    })
                }), f.RenderAboveTheFoldFeatures(), RPT_AddVariables("jp_pet", f.GetAnalyticsLayout(" "));
                if (e.getInstance().areCookiesSupported) {
                    var u = "unknwn",
                        v = d().read() || {},
                        w = a.cookie("_rememberme");
                    if (v.eci || v.ECI) u = "knwn", typeof w == "string" && (u += "_rmbrme");
                    RPT_AddVariables("jp_hpv", u)
                }
                RPT_AddVariables("jp_scdp", 0, "jp_scdr", "D", "jp_scco", window.location.href, "jp_scrp", window.location.href, "jp_ctg", f.GetAnalyticsLayout(), "wa_tp", 14), RPT_RecordEvent(), c.on("scroll", function(a) {
                    k || (f.RenderBelowTheFoldFeatures(), k = !0)
                })
            },
            getArchetype: f.deferredArchetype.promise(),
            getLayout: function() {
                return f.GetAnalyticsLayout()
            }
        }
    }), define("amd/browser-message", ["jquery", "content/conf/appsconfig/clientconfig", "platform", "amd/dynamic-page-creation", "amd/env", "underscore", "jquery.cookie"], function(a, b, c, d, e, f) {
        var g = {
            SiteMessage: {
                message: ".site-message",
                messageTitle: ".site-message__title",
                messageDesc: ".site-message__desc",
                findTargetedMessage: function(b, c) {
                    var d, e, f, g, h = c.split(",");
                    return a.each(b, function(b, c) {
                        g = c, f = c.audiences, a.each(f, function(b, c) {
                            d = c, a.each(h, function(a, b) {
                                if (d === b) return e = g, !1;
                                if (e) return !1
                            });
                            if (e) return !1
                        });
                        if (e) return !1
                    }), e
                },
                filterTargetedMessage: function(a) {
                    return a.targeted ? !0 : !1
                },
                filterNonTargetedMessage: function(a) {
                    return a.targeted ? !1 : !0
                },
                generateServiceURL: function(a) {
                    if (b)
                        if (e.getInstance().isSpanishPage) {
                            if (b.siteMessagingEsURL) return a + b.siteMessagingEsURL;
                            window.console && console.log("[Browser Messaging] Spanish Site Messaging URL not available.")
                        } else {
                            if (b.siteMessagingEnURL) return a + b.siteMessagingEnURL;
                            window.console && console.log("[Browser Messaging] English Site Messaging URL not available.")
                        } else window.console && console.error("[Browser Messaging] ClientConfig not available.")
                },
                init: function(b, c, d) {
                    var e;
                    c ? (e = g.SiteMessage.findTargetedMessage(f.filter(b, g.SiteMessage.filterTargetedMessage), c), e || (e = f.filter(b, g.SiteMessage.filterNonTargetedMessage)[0])) : e = f.filter(b, g.SiteMessage.filterNonTargetedMessage)[0], g.SiteMessage.populateSiteMessage(e, d);
                    if (e) {
                        var h = a(window),
                            i = 0;
                        h.on("scroll", function(b) {
                            var c = h.scrollTop();
                            c > i ? (a(g.SiteMessage.message).removeClass("visible"), i = c) : c <= 0 && (a(g.SiteMessage.message).addClass("visible"), a(".site-message__inner-container").focus(), i = 0)
                        })
                    }
                },
                isEnabled: function() {
                    if (b) return b.siteMessagingEnabled && b.siteMessagingEnabled === "true" ? !0 : (window.console && console.log("[Browser Messaging] Site Messaging is disabled."), !1);
                    window.console && console.error("[Browser Messaging] ClientConfig not available.")
                },
                populateSiteMessage: function(b, c) {
                    if (b) {
                        var d = a(g.SiteMessage.message);
                        b.title && d.find(g.SiteMessage.messageTitle).append("<p>" + b.title + "</p>");
                        if (b.summary) {
                            var e = "",
                                f = b.summary;
                            b.publicLink && b.detailsToggleText && (b.altText && (e = "<span class='accessible-text'>" + b.altText + "</span>"), f += " <a class='chaseanalytics-track-link' href='" + b.publicLink + "'" + "data-pt-name='" + (b.trackerId || "") + "'>" + b.detailsToggleText + e + "</a>"), d.find(g.SiteMessage.messageDesc).append("<p>" + f + "</p>")
                        }
                        d.addClass("visible"), a(".site-message__inner-container").focus()
                    } else window.console && console.log("[Browser Messaging] Error Populating Site Message.")
                }
            },
            UnSupportedMessage: {
                cookie: "_unsupportedbrowser",
                dismissButton: ".browser-message__dismiss-btn",
                message: ".browser-message",
                init: function(b) {
                    if (e.getInstance().isUnSupportedBrowser) {
                        var c = a(window),
                            d = a(g.UnSupportedMessage.message),
                            f = a(g.UnSupportedMessage.dismissButton),
                            h = 0;
                        g.UnSupportedMessage.openMessage(b);
                        if (e.getInstance().isIE && e.getInstance().deviceVersion < 9) {
                            var i = f.find("span").clone();
                            f.find("span").remove(), f.append(i)
                        }
                        f.on("click", function(b) {
                            e.getInstance().areCookiesSupported && a.cookie(g.UnSupportedMessage.cookie, !0, {
                                expires: 1,
                                path: "/"
                            }), g.UnSupportedMessage.closeMessage(), b.preventDefault()
                        }), c.on("scroll", function(a) {
                            var b = c.scrollTop();
                            b > h ? (g.UnSupportedMessage.closeMessage(), h = b) : b <= 0 && (g.UnSupportedMessage.openMessage(), h = 0)
                        })
                    }
                },
                closeMessage: function() {
                    a(g.UnSupportedMessage.message).removeClass("visible")
                },
                openMessage: function(b) {
                    if (e.getInstance().areCookiesSupported) {
                        var c = a.cookie(g.UnSupportedMessage.cookie);
                        if (c === null || c === undefined) a(g.UnSupportedMessage.message).addClass("visible"), b !== "logoff" && a(".browser-message__inner-container").focus(), g.UnSupportedMessage.message
                    }
                }
            }
        };
        return {
            init: function(b) {
                b.url || window.console && console.log("[Browser Messaging] Service Endpoint URL Not Present."), b.audienceIds || window.console && console.log("[Browser Messaging] Empty List of Audience Ids.");
                if (e.getInstance().isDetailPageType || e.getInstance().isStaticPageType) {
                    g.UnSupportedMessage.init();
                    return
                }
                a.when(d.getArchetype).then(function(c) {
                    c !== "standalone" && b.url && g.SiteMessage.isEnabled() ? a.ajax({
                        url: g.SiteMessage.generateServiceURL(b.url)
                    }).done(function(a) {
                        a && a.result && a.result.siteMessages ? g.SiteMessage.init(a.result.siteMessages, b.audienceIds, c) : (window.console && console.log("[Browser Message] Unable to Find Site Messages."), g.UnSupportedMessage.init(c))
                    }).fail(function(a, b, d) {
                        window.console && console.log("[Browser Messaging] Unable to Retrieve Site Messages."), g.UnSupportedMessage.init(c)
                    }) : g.UnSupportedMessage.init(c)
                })
            }
        }
    }), define("amd/scroll-event-tracker", ["jquery", "amd/dynamic-page-creation"], function(a, b) {
        var c = {
            DocumentHeight: 0,
            FeatureCount: 0,
            HomePageURL: window.location.href,
            Execute_RPT_AddVariables: function(a, d) {
                RPT_AddVariables("jp_scdp", a, "jp_scdr", d, "jp_scco", c.HomePageURL, "jp_scrp", c.HomePageURL, "jp_ctg", b.getLayout(), "wa_tp", 14), RPT_RecordEvent()
            },
            Throttle: function(a, b) {
                b || (b = 100);
                var c = !1;
                return function() {
                    if (c) return;
                    c = setTimeout(function() {
                        c = !1
                    }, b), a.apply(this, arguments)
                }
            }
        };
        return {
            init: function() {
                var b = a(window),
                    d = a(document),
                    e = a("body"),
                    f = 0,
                    g = 10,
                    h = b.scrollTop();
                b.on("scroll", function(i) {
                    c.FeatureCount === 0 && (c.FeatureCount = e.attr("data-features")), f === 0 && (f = a(".main-content--dropzone .module:first-child").height());
                    var j = b.scrollTop(),
                        k = 0,
                        l = "D";
                    j > h ? l = "D" : l = "U", h = j;
                    if (j > f || c.DocumentHeight > 0) {
                        c.DocumentHeight === 0 && (c.DocumentHeight = d.height()), c.DocumentHeight !== d.height() && (c.DocumentHeight = d.height()), j <= 0 ? k = 0 : j >= c.DocumentHeight - b.height() ? k = 100 : k = Math.floor(j / (c.DocumentHeight - b.height()) * 100);
                        var m = Math.ceil((k + 1) / 10) * 10;
                        m > g && l === "D" || m < g && l === "U" ? (g = m, c.Execute_RPT_AddVariables(k, l)) : j === 0 ? c.Execute_RPT_AddVariables(k, l) : m < g && (g = m, c.Execute_RPT_AddVariables(k, l))
                    }
                })
            }
        }
    }), define("amd/login", ["jquery", "amd/persona", "amd/env"], function(a, b, c) {
        function d(b, c, d, e, f) {
            this.context = b, this.loginWithRandomizationValue = c, this.isRoutableLogin = d, this.baseLandingPageUrl = e, this.overrideBaseURL = f, this.varDOMAIN = ".chase.com", this.varLOB = "RBGLogon", this.varAjaxError = "<div id='ajaxerror'><a href='https://chaseonline.chase.com/online/home/sso_co_home.jsp' class='outageLink'>this link</a></div>", this.vEditableOptionIndex_A = 0, this.userIdText = a("input#usr_name").attr("placeholder") || a("input#usr_name_home").attr("placeholder") || a("input#interstitial_usr_name").attr("placeholder"), this.passwordText = a("input#usr_password").attr("placeholder") || a("input#usr_password_home").attr("placeholder") || a("input#interstitial_usr_password").attr("placeholder"), this.tokenText = a("input#usr_tokencode").attr("placeholder"), this.myarr = null, this._userId = "", this._password = "", this._token = "", this._password_org = "", this._lob = "", this._cookieDomain = "", this._reTryInterval = 1e3, this._maxReTryCount = 5, this.reTryCount = 0, this.vEditableOptionText_A = "--?--", this.vPreviousSelectIndex_A = 0, this.vSelectIndex_A = 0, this.vSelectChange_A = "MANUAL_CLICK"
        }
        return d.prototype = {
            init: function(d) {

                var e = this,
                    f = a(this.context),
                    g = f.find(".user-name"),
                    h = f.find(".user-password"),
                    i = f.find(".user-token"),
                    j = g.val(),
                    k = h.val(),
                    l = i.val(),
                    m = f.find(".loginBtn .chase-button");
                m[0] || (m = f.find(".loginBtn input")), f.find(".field input").bind("keypress", function(a) {
                    if (a && a.which === 13) return m.trigger("click"), !1
                });
                var n = 0;
                m.bind("click submit", function(j) {
                    ++n;
                    if (n <= 1) {
                        setTimeout(function() {
                            n = 0
                        }, 200), j.preventDefault();
                        if (a("html").attr("lang") === "es_us") {
                            window.console && console.log("Sign In - Spanish Sign In Detected");
                            if (c.getInstance().areCookiesSupported) {
                                var k = b().read(!0);
                                k ? (k += "locale=es_us|", b().erase(), b().write(k), window.console && console.log("Sign In - Updating Persona locale=[es_us]")) : (b().write("locale=es_us|"), window.console && console.log("Sign In - Creating Persona locale=[es_us]"))
                            }
                        }
                        e.clickTarget = j.target;
                        var l = g.val(),
                            m = h.val(),
                            o = typeof i.val() == "undefined" ? "" : i.val(),
                            p = f.find(".user-remember").prop("checked");
                        return m = m === e.passwordText ? "" : m, e.validateandsetcookie(l, m, o, p, ".chase.com", d, f)
                    }
                }), e.initPlaceholder(), e.checkUserRemember()
            },
            initPlaceholder: function() {
                function d(a, b) {
                    a.show(), b.hide()
                }
                var b = this,
                    c = a(this.context),
                    e = "placeholder" in document.createElement("input");
                e || c.find("input.input-text").each(function() {
                    var b = a(this),
                        c = b.attr("placeholder");
                    if (c) {
                        (b.val() === "" || b.val() == c) && b.val(c);
                        if (b.is(":password")) {
                            var e = a("<input />", {
                                "class": b.attr("class"),
                                value: c,
                                name: b.attr("name"),
                                maxlength: b.attr("maxlength")
                            });
                            e.bind("focus.placehold", function() {
                                d(b, e), b.focus()
                            }), b.bind("blur.placehold", function() {
                                b.val() === "" && d(e, b)
                            }), b.hide().after(e)
                        }
                        b.hasClass("user-name") && b.bind({
                            "focusin.placehold": function() {
                                (b.val() == "" || b.val() == c) && b.addClass("hasInput").val("")
                            },
                            "focus.placehold": function() {
                                (b.val() == "" || b.val() == c) && b.addClass("hasInput").val("")
                            },
                            "blur.placehold": function() {
                                (b.val() == "" || b.val() == c) && b.removeClass("hasInput").val(c)
                            }
                        }), b.hasClass("user-password") && b.bind({
                            "focus.placehold": function() {
                                b.val() == c ? b.addClass("hasInput").val("") : b.select()

                            },
                            "blur.placehold": function() {
                                b.val() == "" || b.val() == c ? b.removeClass("hasInput").val(c) : b.val(b.val())
                            }
                        }), b.hasClass("user-token") && b.bind({
                            "focusin.placehold": function() {
                                (b.val() == "" || b.val() == c) && b.addClass("hasInput").val("")
                            },
                            "focus.placehold": function() {
                                (b.val() == "" || b.val() == c) && b.addClass("hasInput").val("")
                            },
                            "blur.placehold": function() {
                                (b.val() == "" || b.val() == c) && b.removeClass("hasInput").val(c)
                            }
                        })
                    }
                })
            },
            validateAndSubmitFrame: function() {
                var b = this;
                this.reTryCount++;
                var c, d, e, f = "COL",
                    g = "https://chaseonline.chase.com";
                this._token != "" && (f = "CCR", g = "https://chaseonline.chase.com", document.cookie = "_tmprsauser=1;path=/;domain=" + this._cookieDomain), document.domain = this._cookieDomain.substring(1, this._cookieDomain.length), this._cookieDomain == ".cardmemberservices.com" && (f = "CMS", g = "https://online.cardmemberservices.com");
                try {
                    var h = a(this.context),
                        i = a(this.clickTarget).attr("data-pt-name");
                    !!window.CHASE && !!window.CHASE.analytics && !!window.CHASE.analytics.trackCustomLink && i && CHASE.analytics.trackCustomLink(i), document.all ? (c = document.getElementById("loginframe"), d = c.contentDocument || c.contentWindow && c.contentWindow.document, e = d.getElementById("login")) : (c = window.frames.loginframe, d = c.document, e = d.login);
                    var j = "true";
                    j == "true" || j != "false" && b.loginWithRandomizationValue == "true" ? (this._password = this.escapeBadJSONCharacters(this._password), this._password_org = this.escapeBadJSONCharacters(this._password_org), this.sendSubmitFrameMessage(f)) : (e.auth_siteId.value = f, e.auth_userId.value = this._userId, e.auth_passwd.value = this._password, e.auth_passwd_org.value = this._password_org, e.auth_tokencode.value = this._token, e.LOB.value = this._lob, e.auth_externalData.value = "LOB=" + this._lob, e.submit())
                } catch (k) {
                    var l = k.message.toLowerCase();
                    l.indexOf("denied") >= 0 ? this.sendSubmitFrameMessage(f) : this.handleValidateAndSubmitFrameError()
                }
                return !1
            },
            validateandsetcookie: function(a, b, c, d) {
                var e = this.varDOMAIN,
                    f = this.varLOB;
                validateandsetcookie(a, b, c, d, e, f)
            },
            setRoutableLoginCookie: function() {
                var a = location.href,
                    b = URL(a),
                    c = this.getQueryObj(b.query(), "&"),
                    d = this.getRoutableLoginCookieValue(c);
                this.setCookie("preredirect", d)
            },
            getRoutableLoginCookieValue: function(a) {
                var b = "";
                return this.overrideBaseURL == "true" ? a.dest != "" && a.dest != undefined ? b = a.dest : this.baseLandingPageUrl != "" && this.baseLandingPageUrl != undefined && (b = this.baseLandingPageUrl) : (this.baseLandingPageUrl != "" && this.baseLandingPageUrl != undefined && (b = this.baseLandingPageUrl), a.dest != "" && a.dest != undefined && (b.indexOf("?") != -1 ? b = b + "&" + "DEST=" + a.dest : b = b + "?" + "DEST=" + a.dest)), a.ARN != "" && a.ARN != undefined && b != "" && (b.indexOf("?") != -1 ? b = b + "&" + "ARN=" + a.ARN : b = b + "?" + "ARN=" + a.ARN), a.sig != "" && a.sig != undefined && b != "" && (b.indexOf("?") != -1 ? b = b + "&" + "sig=" + a.sig : b = b + "?" + "sig=" + a.sig), b
            },
            setCookie: function(a, b) {
                var c = Bind(Cookie, this, a)();
                c.erase(), c.write(b)
            },
            getQueryObj: function(a, b) {
                var c = {},
                    d, e;
                queryParts = a.split(b);
                for (var f = 0; f < queryParts.length; f++) {
                    queryPart = queryParts[f];
                    var g = queryPart.split("=");
                    d = g[0], e = g[1], c[d] = e
                }
                return c
            },
            tokenValidation: function(a, b) {
                var c = "0123456789";
                if (a === b) this._token = "";
                else {
                    for (i = 0; i < a.length; i++)
                        if (!(c.indexOf(a.substring(i, i + 1)) >= 0)) return alert("Error Message LO114:\nThe User ID, Password, and/or token you entered is not valid.\nYour User ID and Password must consist only of letters and numbers.\nYour token must consist only of numbers."), !1;
                    this._token = a
                }
                return !0
            },
            validateandsetcookie: function(a, b, c, d, e, f, g) {
                var h = 0,
                    i = "abcdefghijklmnopqrstuvwxyz0123456789_";
                e == null && (e = this.varDOMAIN);
                if (this.reTryCount == 0) {
                    if ((a.length === 0 || a === this.userIdText) && b.length === 0) return alert("Error Message LO001:\nPlease enter both your User ID and Password."), g.find(".user-name").focus(), !1;
                    if (a.length === 0 || a === this.userIdText) return alert("Error Message LO001:\nPlease enter your User ID."), g.find(".user-name").focus(), !1;
                    if (a === b) return alert("Error Message LO001:\nPlease enter a Password that is different from your User ID."), g.find(".user-password").focus(), !1;
                    if (a.length > 32) return alert("Error Message LO001:\nThe User ID you entered is not valid. \nYour User ID needs to be less than 32 characters long."), g.find(".user-name").focus(), !1;
                    if (a.length <= 32)
                        for (var j = 0; j < a.length; j++)
                            if (!(i.indexOf(a.substring(j, j + 1).toLowerCase()) >= 0)) return alert("Error Message LO001:\nThe User ID you entered is not valid. \nYour User ID can consist of only alphabets, numbers and the underscore (_) character."), g.find(".user-name").focus(), !1;
                    if (b.length === 0) return alert("Error Message LO001:\nPlease enter your Password."), g.find(".user-password").focus(), !1;
                    if (b.length > 32) return alert("Error Message LO001:\nThe Password you entered is not valid. \nYour Password needs to be less than 32 characters long."), g.find(".user-password").focus(), !1;
                    if (c != "") {
                        var k = this.tokenValidation(c, this.tokenText);
                        if (!k) return !1
                    }
                    this.setRememberMeCookie(d, e), this._userId = a.toLowerCase(), this._password = b, this._password_org = b, this._lob = f, this._cookieDomain = e, this.isRoutableLogin == "true" && this.baseLandingPageUrl != "" && this.baseLandingPageUrl != undefined && this.setRoutableLoginCookie(), this.validateAndSubmitFrame()
                }
                return !1
            },
            sendSubmitFrameMessage: function(a) {
                try {
                    var b = '[{"siteId": "' + a + '", "userId": "' + this._userId + '", "password": "' + this._password + '", "password_org": "' + this._password_org + '", "token": "' + this._token + '", "lob": "' + this._lob + '", "auth_externalData": "LOB=' + this._lob + '", "parentWindowLocation": "' + document.location + '"}]',
                        c = document.getElementById("loginframe").contentWindow,
                        d = document.getElementById("loginframe").src;
                    c.postMessage(b, d)
                } catch (e) {
                    this.handleValidateAndSubmitFrameError()
                }
            },
            escapeBadJSONCharacters: function(a) {
                var b = a.replace(/\\/g, "\\\\");
                return b = b.replace(/\"/g, '\\"'), b
            },
            handleValidateAndSubmitFrameError: function() {
                var a = this,
                    b = "https://chaseonline.chase.com";
                document.domain = this._cookieDomain.substring(1, this._cookieDomain.length), this._cookieDomain == ".cardmemberservices.com" && (siteId = "CMS", b = "https://online.cardmemberservices.com"), this.reTryCount >= this._maxReTryCount ? (b = b + "/Logon.aspx?error=L009&LOB=" + this._lob + "&src=" + encodeURIComponent(window.location.href), window.location.href = b) : setTimeout(function() {
                    a.validateAndSubmitFrame()
                }, this._reTryInterval)
            },
            setRememberMeCookie: function(a, b) {
                a == 1 ? document.cookie = "_tmprememberme=1;path=/;domain=" + b : document.cookie = "_tmprememberme=0;expires=0;path=/;domain=" + b
            },
            readCookie: function(a) {
                var b = a;
                if (document.cookie.length > 0) {
                    begin = document.cookie.indexOf(b + "=");
                    if (begin != -1) return begin += b.length + 1, end = document.cookie.lastIndexOf("|"), end == -1 && (end = document.cookie.length), unescape(document.cookie.substring(begin, end))
                }
                return null
            },
            loadHomePageHeroSection: function(b, c) {
                var d = "",
                    d;
                this.isKnownUser() ? d = b : d = c, ContentProvider.loadSnippetContent(d, function(b) {
                    a(".hero-section").html(b)
                }, function(a) {})
            },
            isKnownUser: function() {
                var a = PersonaCookie().read() || {},
                    b = a.pfid || null,
                    c = b ? !0 : !1;
                return c
            },
            isKnownUserRemember: function() {
                var b = a(this.context),
                    c = 0,
                    d = "";
                if (document.cookie.match("_rememberme")) {
                    d = this.readCookie("_rememberme");
                    if (d == null || d.substr(0, 1) == ";") d = "";
                    c = d === "" ? 0 : 1;
                    var e = d.split("|");
                    this.myarr = e[0]
                }
                return this.myarr != null && c == 1 ? !0 : !1
            },
            checkUserRemember: function() {
                var b = a(this.context),
                    c = 0,
                    d = "";
                if (document.cookie.match("_rememberme")) {
                    d = this.readCookie("_rememberme");
                    if (d == null || d.substr(0, 1) == ";") d = "";
                    c = d === "" ? 0 : 1;
                    var e = d.split("|");
                    this.myarr = e[0]
                }
                this.myarr != null ? (b.find(".forgotpass").css("display", "block"), b.find(".forgotuidpass").css("display", "none")) : (b.find(".forgotuidpass").css("display", "block"), b.find(".forgotpass").css("display", "none")), this.myarr != null && c == 1 ? (b.find(".user-name").val(this.myarr).addClass("hasInput"), b.find(".user-remember").prop("checked", !0), a("#usr_remember_home").addClass("checked"), this.doFocus()) : this.myarr == null && (b.find(".user-remember").prop("checked", !1), b.find(".user-name").removeClass("hasInput"), a("#usr_remember_home").removeClass("checked"));
                try {
                    if (this.myarr == null || this.myarr == "") b.find(".user-remember").prop("checked", !1), a("#usr_remember_home").removeClass("checked")
                } catch (f) {
                    b.find(".user-remember").prop("checked", !1), a("#usr_remember_home").removeClass("checked")
                }
            },
            doFocus: function() {
                var b = this,
                    c = a(this.context);
                this.myarr == null ? c.find(".user-name").focus() : this.myarr !== null && c.find(".user-password").focus()
            },
            bolInfoIconPopup: function(a) {
                var b = window.open(a, "bol", "scrollbars=yes,screenX=0,screenY=0,directories=0,height=300,width=500,location=no,menubar=no,resizable=yes,status=no,toolbar=no");
                b.focus()
            }
        }, d
    }), define("amd/language", ["jquery", "amd/persona", "amd/env"], function(a, b, c) {
        var d = {
            ENGLISH_LANGUAGE_CODE: "en_us",
            SPANISH_LANGUAGE_CODE: "es_us",
            ToggleElement: ".language-toggle",
            ToggleLanguageCode: function(a) {
                return a === this.SPANISH_LANGUAGE_CODE ? this.ENGLISH_LANGUAGE_CODE : this.SPANISH_LANGUAGE_CODE
            },
            SetPersonilizationCookieLocaleIfPresent: function() {
                if (c.getInstance().areCookiesSupported) {
                    var a = b().read(!0);
                    a && (a += "locale=" + this.ToggleLanguageCode(b().read().locale) + "|", b().erase(), b().write(a))
                }
            }
        };
        return {
            init: function() {
                a(d.ToggleElement).on("click", function(b) {
                    b.preventDefault(), d.SetPersonilizationCookieLocaleIfPresent(), window.location.href = a(this).attr("href")
                })
            }
        }
    }), define("amd/voc", ["jquery", "amd/env", "amd/persona"], function(a, b, c) {
        var d = {
            className: ".voc",
            dataUrl: "data-voc-url",
            dataReferer: "data-voc-referer",
            constructURL: function(a) {
                var b = a.attr(d.dataUrl);
                if (b) return b + "?" + d.populateParams(a);
                console.log("[VOC] Empty 'data-voc-url' attribute.")
            },
            generatePopupSettings: function() {
                var b = a(window),
                    c = parseInt((b.width() - 545) / 2, 10),
                    d = parseInt((b.height() - 325) / 2, 10),
                    e = ["resizable=yes", "location=no", "status=no", "scrollbars=1", "width=545", "height=325", "top=" + d, "left=" + c];
                return e.join(",")
            },
            populateParams: function(e) {
                var f = a("body").attr(d.dataReferer),
                    g = {
                        currentURL: location.href || "",
                        prev: document.referrer || "",
                        referer: f || ""
                    };
                if (b.getInstance().areCookiesSupported) {
                    var h = c().read() || {};
                    if (h.pfid || h.PFID) g.customVars = "{profileId:'" + (h.pfid || h.PFID) + "'}"
                }
                return a.param(g)
            }
        };
        return {
            init: function(c) {
                var e = a(d.className);
                if (e.length > 0) {
                    var f, g = d.constructURL(e);
                    e.on("click", function(a) {
                        f = f || window.open(g, "VOC", d.generatePopupSettings()), b.isIE !== "ie" ? f !== null && f.closed && (console.info("voc is " + f), window.open(g, "VOC", d.generatePopupSettings())) : f && f.focus(), a.preventDefault()
                    })
                }
            }
        }
    }), define("amd/geo-image", ["jquery", "amd/persona", "amd/env", "jquery.cookie"], function(a, b, c) {
        var d = {
            ErrorPrefixInfo: "Chase Geo Service Error: ",
            ContentPath: "/content/geo-images/images",
            FileExtension: ".jpeg",
            ConstructRequestURL: function(a, b) {
                return a + this.ContentPath + "/" + (b ? b : "background") + "." + this.GetDeviceType() + "." + this.GetDayOrNight() + "." + this.GetFreshness() + this.FileExtension + this.GetZipCode()
            },
            GetDayOrNight: function() {
                var a = (new Date).getHours();
                return a >= 4 && a < 18 ? "day" : "night"
            },
            GetDeviceType: function() {
                var b = a("body").data("device");
                return b !== "mobile" && b !== "tablet" && b !== "mega" && (b = "desktop"), b
            },
            GetFreshness: function() {
                var b = Math.floor(Math.random() * 10) + 1;
                return c.getInstance().areCookiesSupported && a.cookie("_geoFreshness", b, {
                    path: "/"
                }), b
            },
            GetZipCode: function() {
                if (c.getInstance().areCookiesSupported) {
                    var d = b().read();
                    if (d && d.zip && d.zip.length >= 5) {
                        var e = d.zip.substr(0, 5);
                        if (/^[0-9]+$/.test(e)) return a.cookie("_geoZip", e, {
                            path: "/"
                        }), "/" + e + this.FileExtension
                    }
                }
                return ""
            }
        };
        return {
            init: function(a, b, c) {
                a !== undefined && a.length > 0 ? b !== undefined && b.length > 0 ? document.getElementsByTagName("html")[0].className.indexOf("lt-ie9") > 0 ? document.getElementById(a).setAttribute("style", "filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='" + d.ConstructRequestURL(b, c) + "', sizingMethod='scale')") : document.getElementById(a).setAttribute("style", "background-image: url(" + d.ConstructRequestURL(b, c) + ")") : console.log(d.ErrorPrefixInfo + "Error with environment URL (" + b + ").") : console.log(d.ErrorPrefixInfo + "Error with id (" + a + ").")
            }
        }
    }), define("sendMessageClient", ["require", "jquery"], function(a) {
        var b = a("jquery"),
            c = "[sendMessageClient] ",
            d = null,
            e, f = {},
            g = !1,
            h = !1,
            i = [],
            j = !1,
            k = null,
            l = null,
            m = null,
            n = "1.0",
            o = {},
            p = [],
            q = function(a) {
                return (a.location.protocol + "//" + a.location.hostname + (a.location.port ? ":" + a.location.port : "")).toLowerCase()
            },
            r = function() {
                var a;
                try {
                    window.postMessage({
                        toString: function() {
                            a = !1
                        }
                    }, "*")
                } catch (b) {
                    a = !0
                }
                return a
            }(),
            s = window.console || {
                log: function() {},
                debug: function() {},
                error: function() {}
            },
            t = {
                log: function(a) {
                    s.log(c + a)
                },
                debug: function(a) {
                    s.debug ? s.debug(c + a) : s.log(c + a)
                },
                error: function(a) {
                    s.error(c + a)
                }
            },
            u = function(a) {
                return b.type(a) === "string"
            },
            v = function(a, c, d) {
                d || (d = window);
                var e = b(d);
                e.on(a, c), p.push({
                    type: a,
                    node: e
                })
            },
            w = function(a, b) {
                b.off(a)
            },
            x = function() {
                t.debug("Activating listeners..."), v("message onmessage", function(a) {
                    F(a.originalEvent)
                }), v("resize", A(B, e)), v("unload", y)
            },
            y = function() {
                t.debug("Removing listeners...");
                var a;
                for (var b = 0, c = p.length; b < c; b++) a = p[b], w(a.type, a.node);
                p = []
            },
            z = function(a) {
                if (i.length > 0) {
                    t.debug("[sendMessageClient] Got <" + a + ">, draining queue of " + i.length + " items");
                    while (i.length > 0) {
                        var b = i.shift();
                        H(b)
                    }
                }
            },
            A = function(a, b, c) {
                var d;
                return function() {
                    var e = this,
                        f = arguments,
                        g = function() {
                            d = null, c || a.apply(e, f)
                        },
                        h = c && !d;
                    clearTimeout(d), d = setTimeout(g, b), h && a.apply(e, f)
                }
            },
            B = function() {
                var a = b(window);
                H({
                    protocol: "displayEvent",
                    command: "resize",
                    context: {
                        height: a.height(),
                        width: a.width()
                    }
                })
            },
            C = function(a) {
                var c = b(d),
                    e;
                if (!c) {
                    t.error("FATAL iframe not located in document");
                    return
                }
                if (c.length > 0) {
                    t.debug("Found the iframe with id = " + d), e = c.attr("src");
                    if (!e) {
                        t.error("FATAL iframe source not set");
                        return
                    }
                    k = c[0].contentWindow;
                    var f = e.split("/");
                    f[0] === "" ? l = q(k) : l = (f[0] + "//" + f[2]).toLowerCase(), document.location.origin ? m = document.location.origin : m = q(document), t.debug("Found domains | Child domain: " + l + " | Parent domain: " + m), g = !0, a || (x(), t.debug("Initialized OK"), H({
                        command: "ready",
                        domain: m,
                        message: "Parent ready"
                    }))
                } else {
                    var h = 1;
                    setTimeout(C, h)
                }
            },
            D = function(a) {
                var b = null;
                if (!a) return;
                u(a) ? b = a : a.data && a.data.url && u(a.data.url) && (b = a.data.url);
                if (!b) {
                    t.error("No URL found in navigate command.");
                    return
                }
                window.location.href = b
            },
            E = function(a) {
                var c = {
                    iframeId: null,
                    debounceInterval: 150,
                    eventMap: {
                        navigate: D
                    }
                };
                a = b.extend(!0, {}, c, a || {});
                if (!a.iframeId) {
                    t.error("FATAL iframe id not specified");
                    return
                }
                d = a.iframeId, e = a.debounceInterval, o = a.eventMap, t.debug("File version " + n), setTimeout(C, 0)
            },
            F = function(a) {
                if (a.origin !== l) {
                    t.error("Message received from unrecognized origin " + a.origin);
                    return
                }
                if (a && a.data) {
                    var b = r ? a.data : JSON.parse(a.data);
                    G(b)
                } else t.debug("Missing event or event data, ignoring")
            },
            G = function(a) {
                t.debug("Got <" + a.command + "> command from domain " + a.domain);
                switch (a.command) {
                    case "ready":
                        h && j && (h = !1, j = !1, C(!0)), h = !0, z("ready"), j || (H({
                            protocol: "handshake",
                            command: "ack",
                            ackCommand: "ready",
                            domain: m,
                            message: "Parent ready"
                        }), j = !0);
                        break;
                    case "ack":
                        h = !0, z("ack")
                }
                b.type(o[a.command]) === "function" && o[a.command](a)
            },
            H = function(a) {
                var b = typeof a == "object" && a.command;
                if (!b) {
                    t.debug("Message in invalid format, ignoring");
                    return
                }
                if (g && h) z("init");
                else {
                    if (!g) {
                        t.debug("Attempt to post message <" + a.command + "> when initialization incomplete or failed!");
                        return
                    }
                    if (a.command !== "ready") {
                        t.debug("Attempt to post message <" + a.command + "> when parent not loaded - storing"), i.push(a);
                        return
                    }
                }
                t.debug("Sending command <" + a.command + ">"), a = r ? a : JSON.stringify(a), k.postMessage(a, l)
            };
        return f.init = function(a) {
            b(function() {
                t.debug("Initializing client"), E(a)
            })
        }, f.sendMessage = function(a) {
            H(a)
        }, f
    }), define("amd/signin", ["jquery", "content/conf/appsconfig/clientconfig", "sendMessageClient", "amd/dynamic-page-creation", "amd/login", "amd/persona", "platform", "amd/speedbump", "amd/utils", "amd/env", "jquery.cookie"], function(a, b, c, d, e, f, g, h, i, j) {
        var k = {
            element: ".signin",
            module: "#signin-module",
            checkMark: ".signin--checkmark",
            checkMarkBox: "#usr_remember_home",
            checkMarkLabel: ".signin--remember-me.checkbox",
            classicSignInContainer: ".classic-signin-container",
            classicSignIn: ".classic-signin",
            cpoSignInContainer: ".cpo-signin-container",
            cpoSignIn: ".cpo-signin",
            cpoIframe: "#logonbox",
            cpoSettings: {
                resolved: !1,
                startTime: 0,
                timeout: 3e3
            },
            cpoCookie: "_iscpo",
            signInAnimationDuration: 1e3,
            initCPO: function() {
                if (!k.cpoSettings.resolved) {
                    k.loadCPOIframe(), c.init({
                        iframeId: k.cpoIframe,
                        eventMap: {
                            navigate: k.navigate,
                            ready: k.ready
                        }
                    }), k.cpoSettings.startTime = (new Date).getTime();
                    var a = k.cpoSettings.timeout;
                    b && b.cpoSignInTimeout && (a = b.cpoSignInTimeout);
                    var d = setInterval(function() {
                        if (k.cpoSettings.resolved) clearInterval(d), k.hideClassicSignIn(), window.console && console.log("[CPO] Frame Resolved");
                        else {
                            var a = (new Date).getTime();
                            a > k.cpoSettings.startTime + k.cpoSettings.timeout && (k.cpoSettings.resolved = !0, clearInterval(d), k.hideCPOSignIn(), window.console && console.log("[CPO] Frame Timed Out...Loading Classic"))
                        }
                    }, 100)
                }
            },
            hideClassicSignIn: function() {
                a(k.classicSignInContainer).addClass("hide").removeClass("show").attr("aria-hidden", !0), a(k.cpoSignInContainer).removeAttr("aria-hidden").removeClass("hide").addClass("show"), a(k.cpoSignIn).animate({
                    opacity: 1
                }, k.signInAnimationDuration)
            },
            hideCPOSignIn: function() {
                a(k.cpoSignInContainer).addClass("hide").removeClass("show").attr("aria-hidden", !0), a(k.classicSignInContainer).removeAttr("aria-hidden").removeClass("hide").addClass("show");
                var b = k.currentArchetype === "returning" ? "" : "false",
                    c = new e(".chase-home-login .login-user", "true", "false", "", b);
                c.init("RBGLogon"), a(k.classicSignIn).animate({
                    opacity: 1
                }, k.signInAnimationDuration)
            },
            isCPO: function(c) {
                var d = !1;
                if (b && b.cpoSignInEnabled && b.cpoSignInEnabled === "false") return window.console && console.log("[CPO] CPO Sign In has been disabled."), !1;
                if (j.getInstance().areCookiesSupported) {
                    var e = a.cookie(k.cpoCookie);
                    e == "1" && k.isCPOSupportedBrowser() && k.isSignInBoxDisplayed(c) && (d = !0)
                }
                return d
            },
            isCPOSupportedBrowser: function() {
                var a = {
                        Chrome: 38,
                        Firefox: 24,
                        IE: 8,
                        Safari: 6.2
                    },
                    b, c = !1;
                return k.isSignInDesktopView() && (b = a[g.name], b && b <= parseFloat(g.version) && (c = !0)), c
            },
            isSignInBoxDisplayed: function(b) {
                var c = !0,
                    d = a("body"),
                    e = d.hasClass("system-outage"),
                    f = d.hasClass("system-disabled"),
                    g = b === "logoff",
                    h = b === "standalone";
                if (e || f || g || h) c = !1;
                return c
            },
            isSignInDesktopView: function() {
                return typeof window.matchMedia == "undefined" || typeof window.matchMedia == "function" && window.matchMedia("(min-width: 992px)").matches ? !0 : !1
            },
            isSpanish: function() {
                var a = !1;
                if (j.getInstance().areCookiesSupported) {
                    var b = f().read().locale;
                    /es_us/i.test(b) && (a = !0)
                }
                return a
            },
            loadCPOIframe: function() {
                var b = a(k.cpoIframe);
                b.data("src") ? b.attr("src", b.data("src")) : window.console && console.log("[CPO] The CPO iFrame data-src was not found.")
            },
            navigate: function(a) {
                window.console && console.log("[CPO] Navgiate Callback Executed.");
                var c = "unknwn",
                    d = null;
                j.getInstance().areCookiesSupported && (f().read().eci || f().read().ECI ? c = "knwn" : c = "unknwn");
                if (!a) return;
                i.isString(a) ? d = a : a.data && a.data.url && i.isString(a.data.url) && (a.data.key === "forgotPasswordNavigation" ? (window.console && console.log("[CPO] Navigate for 'Forgot user name/password?'."), c += "forgot", d = a.data.url) : a.data.key === "requestEnrollment" ? (window.console && console.log("[CPO] Navigate for 'Not enrolled? Sign up now.'."), c += "enroll", d = a.data.url, k.isSpanish() && (window.console && console.log("[CPO] Display Spanish Speedbump for 'Not enrolled? Sign up now.'"), b.spanishInterstitialSpeedbumpURL ? d = b.spanishInterstitialSpeedbumpURL + "?url=" + encodeURIComponent(a.data.url) : window.console && console.log("[CPO] Client Config is missing spanish interstitial speedbump url."))) : (window.console && console.log("[CPO] Navigate for sign in."), c += "login", d = a.data.url));
                if (!d) {
                    window.console && console.log("[CPO] no URL found in navigate command.");
                    return
                }
                d && (RPT_AddVariables("wa_uri", location.protocol + "//" + location.hostname, "wa_pt", document.title, "wa_lnk", c), RPT_RecordEvent()), window.location.href = d
            },
            ready: function() {
                window.console && console.log("[CPO] Initialized and Ready."), k.cpoSettings.resolved = !0, c.sendMessage({
                    protocol: "displayEvent",
                    command: "focus"
                })
            },
            setupClassicSignIn: function(b) {
                var c = a(document),
                    d = a(k.checkMark),
                    e = a(k.checkMarkBox),
                    f = a(k.checkMarkLabel),
                    g = a(k.element);
                k.currentArchetype !== "returning" ? (g.find(".signin--welcome-prospect").show(), g.find(".signin--primary-link-2").show(), g.find(".signin--button").attr("data-pt-name", "unknwnlogin"), g.find(".signin--primary-link-1").attr("data-pt-name", "unknwnforgot")) : g.find(".signin--welcome-returning").show(), c.on("click", function(c) {
                    var d = a(c.target);
                    if (d.is(k.checkMarkLabel) || d.parents(k.checkMarkLabel).length === 1) e.is(":checked") ? (e.prop("checked", !1), b && (e.removeClass("checked"), c.preventDefault()), e.focus(), c.preventDefault()) : (e.prop("checked", !0), b && (e.addClass("checked"), c.preventDefault()), e.focus(), c.preventDefault())
                })
            }
        };
        return {
            init: function(b) {
                a.when(d.getArchetype).then(function(c) {
                    var d = !1;
                    k.currentArchetype = c, k.isSignInDesktopView() && (k.setupClassicSignIn(b), k.isCPO(c) ? k.initCPO() : k.hideCPOSignIn()), a(window).on("resize", function(a) {
                        !j.getInstance().isIE8 && !j.getInstance().isIE9 && k.isSignInDesktopView() && (d || (k.isCPO(c) ? k.initCPO() : k.hideCPOSignIn(), d = !0))
                    })
                })
            }
        }
    }), define("amd/hide", ["jquery", "amd/env"], function(a, b) {
        var c = {
            mobile: "[data-hide-mobile]",
            tablet: "[data-hide-tablet]",
            desktop: "[data-hide-desktop]",
            firefoxOverrideClass: "ff-manual-hide",
            toggleManualHide: function() {
                a(c.mobile + "," + c.tablet + "," + c.desktop).removeClass(c.firefoxOverrideClass);
                var b = window.innerWidth;
                b <= 480 ? a(c.mobile).addClass(c.firefoxOverrideClass) : b >= 481 && b <= 1199 ? a(c.tablet).addClass(c.firefoxOverrideClass) : a(c.desktop).addClass(c.firefoxOverrideClass)
            }
        };
        return {
            init: function() {
                b.getInstance().isFirefox && (c.toggleManualHide(), a(window).on("load resize", function(a) {
                    c.toggleManualHide()
                }))
            }
        }
    }), define("amd/left-nav", ["jquery"], function(a) {
        var b = {
            button: ".left-nav--mobile-btn",
            element: ".left-nav",
            links: ".left-nav--links",
            wrapper: ".left-nav--wrapper",
            closeDropDownMenu: function() {
                var c = a(b.element),
                    d = a(b.links);
                c.hasClass("open") && d.slideUp(300, "linear", function() {
                    c.removeClass("open"), a(this).attr("style", "")
                })
            },
            viewSize: function() {
                return typeof window.matchMedia == "function" && window.matchMedia("(min-width: 768px)").matches ? !1 : !0
            },
            clearDimensions: function() {
                a(b.wrapper).attr("style", ""), a(b.links).attr("style", "")
            },
            setHeight: function() {
                var c = a(".detail__content"),
                    d = c.height();
                d > 0 && a(b.wrapper).height(d)
            },
            setWidth: function() {
                var c = a(b.element).width();
                c > 0 && a(b.links).width(c)
            },
            slideNav: function() {
                var c = a(b.links),
                    d = a(b.wrapper),
                    e = Math.round(d.offset().top),
                    f = d.innerHeight() - a(".left-nav").outerHeight() - c.outerHeight(),
                    g = a(".header.header-version-b").height() + a(".sub-header__nav-wrapper").height(),
                    h = a(b.wrapper).innerHeight() + g,
                    i = a(window).scrollTop() + g,
                    j = i - e,
                    k;
                i > h ? k = "bottom" : i < e ? k = "top" : k = "fixed", j > f && (k = "end");
                switch (k) {
                    case "end":
                        c.removeClass("sticky").css("top", f + "px");
                        break;
                    case "bottom":
                        c.removeClass("sticky").css("top", j + "px");
                        break;
                    case "fixed":
                        c.addClass("sticky").css("top", g + "px");
                        break;
                    case "top":
                        c.removeClass("sticky").css("top", "");
                        break;
                    default:
                        c.removeClass("sticky").css("top", "")
                }
            },
            toggleDropDownMenu: function() {
                var c = a(b.element),
                    d = a(b.links);
                c.hasClass("open") ? d.slideUp(300, "linear", function() {
                    c.removeClass("open"), a(this).attr("style", "")
                }) : d.slideDown(300, "linear", function() {
                    c.addClass("open")
                })
            }
        };
        return {
            init: function() {
                var c = a(document),
                    d = a(window);
                b.viewSize() || (b.setHeight(), b.setWidth(), b.slideNav()), c.on("click", function(c) {
                    var d = a(c.target);
                    d.is(b.button) || d.parent().is(b.button) ? (b.toggleDropDownMenu(), c.preventDefault()) : b.closeDropDownMenu()
                }), d.on("scroll", function(a) {
                    b.viewSize() || b.slideNav()
                }), d.on("resize", function(a) {
                    b.closeDropDownMenu(), b.viewSize() ? b.clearDimensions() : (b.clearDimensions(), b.setHeight(), b.setWidth(), b.slideNav())
                })
            }
        }
    }), define("amd/signin-btn", ["jquery", "content/conf/appsconfig/clientconfig", "amd/persona", "underscore", "amd/env", "jquery.cookie"], function(a, b, c, d, e) {
        var f = {
            element: ".signInBtn",
            container: ".header__section--link.login",
            cpoRoutingCookie: "_iscpo",
            displayOrNotDisplaySignInBtnLink: function() {
                var b = a("body"),
                    c = a(f.container),
                    d = f.hasArchetype("returning"),
                    e = f.hasArchetype("prospect"),
                    g = f.hasArchetype("standalone"),
                    h = f.hasArchetype("logoff"),
                    i = b.hasClass("system-disabled"),
                    j = b.hasClass("system-outage");
                !g && !h && !i && !j && (d || e) && (f.matchesBreakpoint("(min-width: 992px)") ? c.removeClass("show").addClass("hide") : c.addClass("show").removeClass("hide"))
            },
            getSignInType: function() {
                var a;
                return f.isCPO() ? a = "cpo" : f.isSpanish() ? a = "classic-es" : a = "classic-en", window.console && console.log("Sign In Button Log: Sign In Type [" + a + "]"), a
            },
            hasArchetype: function(b) {
                return a("[data-archetype=" + b + "]").length
            },
            isCPO: function() {
                if (e.getInstance().areCookiesSupported) {
                    var b = a.cookie(f.cpoRoutingCookie);
                    return b == 1
                }
                return !1
            },
            isSpanish: function() {
                var b = a("html"),
                    c = b.attr("lang");
                return /es_us/i.test(c) ? !0 : !1
            },
            matchesBreakpoint: function(a) {
                return typeof window.matchMedia == "function" && window.matchMedia(a).matches ? !0 : !1
            },
            updateSignInBtnLink: function() {
                var c = a(f.element),
                    d = f.getSignInType(),
                    e = "";
                b ? (d === "cpo" ? b.cpoSignInBtnUrl ? e = b.cpoSignInBtnUrl : window.console && console.error("Sign In Button Error: CPO Sign In URL not present.") : d === "classic-es" ? b.classicEsSignInBtnUrl ? e = b.classicEsSignInBtnUrl : window.console && console.error("Sign In Button Error: CPO Sign In URL not present.") : b.classicEnSignInBtnUrl ? e = b.classicEnSignInBtnUrl : window.console && console.error("Sign In Button Error: CPO Sign In URL not present."), c.attr("href", e)) : window.console && console.error("Sign In Button Error: ClientConfig not available.")
            }
        };
        return {
            init: function() {
                var b = a(window);
                f.updateSignInBtnLink(), f.displayOrNotDisplaySignInBtnLink();
                var c = d.debounce(function() {
                    f.updateSignInBtnLink(), f.displayOrNotDisplaySignInBtnLink()
                }, 250);
                b.on("resize", c)
            }
        }
    }), require(["jquery", "amd/polyfills", "amd/dynamic-page-creation", "amd/env", "amd/oldie", "amd/carousel", "amd/hero", "amd/header", "amd/hide", "amd/sidemenu", "amd/mosaic", "amd/left-nav", "amd/login", "amd/video", "amd/sub-header", "vendor/fastclick", "amd/browser-message", "amd/speedbump", "amd/scroll-event-tracker", "amd/signin", "amd/signin-btn", "amd/ada", "amd/language", "amd/persona", "amd/cookie", "amd/xfs", "amd/voc", "jquery.cookie"], function(a, b, c, d, e, f, g, h, i, j, k, l, m, n, o, p, q, r, s, t, u, v, w, x, y, z, A) {
        var B = {
            setBodyDataDevice: function() {
                var b = window.getComputedStyle(document.body, ":after").getPropertyValue("content").replace(/"/g, "");
                a("body").attr("data-device", b.indexOf("'") === 0 ? b.replace(/'/g, "") : b)
            }
        };
        a(function() {
            var b = a("body"),
                c = a("html"),
                m = a(window),
                q = b.hasClass("detail"),
                x = b.hasClass("topic"),
                y = b.hasClass("spanish-interstitial-page"),
                z = !1;
            a.cookie.raw = !0, d.getInstance().isIE && (d.getInstance().deviceVersion < 9 ? (c.addClass("lt-ie9"), z = !0) : d.getInstance().deviceVersion === 9 && c.addClass("lt-ie10")), z ? e.init() : (B.setBodyDataDevice(), m.on("resize", B.setBodyDataDevice)), f.init(), g.init(), h.init(z), i.init(), j.init(z), k.init(), n.init(), (q || x) && o.init(z), q && l.init(), v.init(), y ? r.initInterstitial() : r.init(), s.init(), t.init(z), u.init(), w.init(), A.init(), p.attach(document.body);
            var C = a(".main-content--dropzone");
            C.on("Chase:FeatureAppended", function(b, c) {
                var d = a(c),
                    e = d.children(".topic__wrapper");
                if (e.length > 0) {
                    d.animate({
                        opacity: 1
                    }, 400);
                    var h = e.find(".carousel"),
                        i = e.find(".hero__img"),
                        j = e.find(".mosaic.mosaic-version-b");
                    h.each(function() {
                        f.setupCarousels(a(this))
                    }), j.each(function() {
                        k.checkForImageDownloadBeforeEqualizeHeights(a(this))
                    }), i.each(function() {
                        g.checkForImageDownload(a(this))
                    }), o.lazyInit(z)
                }
            }), m.on("load", function(b) {
                a(".main-content__inner").height() < m.height() && a(".main-content").css({
                    "min-height": "initial"
                })
            })
        })
    }), define("main", function() {})